import org.jetbrains.kotlin.utils.addToStdlib.cast

plugins {
    id("com.android.library")
    id("kotlin-android")
    id("kotlin-kapt")
}

android {

    var android_ex = rootProject.ext["android"] as MutableMap<String, String>
    compileSdkVersion(android_ex["compileSdkVersion"].toString())

    defaultConfig {
        minSdkVersion(android_ex["minSdkVersion"].toString())
        targetSdkVersion(android_ex["targetSdkVersion"].toString())
        versionCode(android_ex["versionCode"].toString().toInt())
        versionName(android_ex["versionName"].toString())
    }

}


dependencies {
    val kotlinVersion = rootProject.ext["kotlin_version"].toString()
    var dependencies_ex =  rootProject.ext["dependencies"] as MutableMap<String, String>
    api ("org.jetbrains.kotlin:kotlin-stdlib:$kotlinVersion")
    api (dependencies_ex["appcompat"].toString())
    api (dependencies_ex["core-ktx"].toString())
    api (dependencies_ex["fragment-ktx"].toString())
    api (dependencies_ex["material"].toString())
    api (dependencies_ex["gson"].toString())
    api (dependencies_ex["xutils"].toString())
    api (dependencies_ex["retrofit2"].toString())
    api (dependencies_ex["converter-scalars"].toString())
    api (dependencies_ex["logging-interceptor"].toString())

}

apply(from = "config.gradle")

buildscript {

    rootProject.extra.apply {
        set("hilt_version", "2.28-alpha")
        set("kotlin_version", "1.5.0")
    }

    repositories {
        google()
//        jcenter()
    }

    dependencies {
        classpath("com.android.tools.build:gradle:4.2.1")
        classpath("org.jetbrains.kotlin:kotlin-gradle-plugin:1.5.20")
    }
}

allprojects {

    repositories {

        google()
//        jcenter()
        maven("https://jitpack.io")
        maven("https://maven.aliyun.com/repository/public")
        maven("https://maven.aliyun.com/repository/google")
        maven("https://maven.google.com")
        maven("https://www.jitpack.io")
        mavenCentral()

    }

}

tasks.register<Delete>("clean") {

    delete(rootProject.buildDir)

}
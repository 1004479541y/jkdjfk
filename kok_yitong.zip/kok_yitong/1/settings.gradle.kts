include("app")

rootProject.name = "yitong"

include("adaptivelayout")
project(":adaptivelayout").projectDir=  File("library/adaptivelayout")

include("common")
project(":common").projectDir=  File("library/common")

include("banner")
project(":banner").projectDir= File("library/banner")

include("recorderlib")
project(":recorderlib").projectDir=  File("library/recorderlib")



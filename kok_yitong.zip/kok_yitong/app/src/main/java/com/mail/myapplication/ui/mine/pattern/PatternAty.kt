package com.mail.myapplication.ui.mine.pattern

import android.os.Bundle
import android.util.Log
import android.view.View
import com.andrognito.patternlockview.PatternLockView
import com.andrognito.patternlockview.PatternLockView.Dot
import com.andrognito.patternlockview.listener.PatternLockViewListener
import com.andrognito.patternlockview.utils.PatternLockUtils
import com.mail.comm.utils.JSONUtils
import com.mail.comm.utils.MyUtils
import com.mail.comm.utils.PreferencesUtils
import com.mail.myapplication.BaseXAty
import com.mail.myapplication.R
import com.mail.myapplication.databinding.AtyPatternBinding
import com.mail.myapplication.interfaces.Lar
import org.xutils.common.util.LogUtil
import java.lang.StringBuilder

class PatternAty:BaseXAty() {

    var type =""
    var pass_set=""
    var pass_pattern=""
    var lar = Lar()
    lateinit var mBinding: AtyPatternBinding

    override fun getLayoutId(): Int = 0

    override fun getLayoutView(): View {
        mBinding = AtyPatternBinding.inflate(layoutInflater);
        return mBinding.root
    }

    override fun initView() {
        type = intent.getStringExtra("type").toString()
        if (type=="reset_pattern"){
            pass_pattern = PreferencesUtils.getString(this, "pattern_pass")
        }
    }

    override fun requestData() {}

    fun mainClick(v: View) {
        when (v.id) {
            R.id.relay_back -> {
                finish()
            }
        }
    }

    override fun onComplete(var2: String?, type: String?) {
        super.onComplete(var2, type)
        if (type=="pwd/edit"){
            stopProgressDialog()
            var map = JSONUtils.parseKeyAndValueToMap(var2)
            LogUtil.e("========="+var2)
            if (map["code"] == "200") {
                setPattern(true)
                PreferencesUtils.putString(this,"pattern_pass",pass_set)
                startActivity(PatternSwichAty::class.java)
                finish()
            }else{
                showToastS(map["message"])
            }
        }
    }

    override fun onExceptionType(type: String?) {
        super.onExceptionType(type)
        if (type=="pwd/edit"){
            stopProgressDialog()
        }
    }

    private val mPatternLockViewListener: PatternLockViewListener = object : PatternLockViewListener {

            override fun onStarted() {}

            override fun onProgress(progressPattern: List<Dot>) {
                Log.d(javaClass.name, "Pattern progress: " + MyUtils.patternToString(mBinding.patterLockView, progressPattern))
            }

            override fun onComplete(pattern: List<Dot>) {

                when(this@PatternAty.type){

                    "set_pattern"->{
                         pass_set = MyUtils.patternToString(mBinding.patterLockView, pattern)
                         if (pass_set.length<5){
                             showToastS("手势图案不能小于五个！")
                             return
                         }
                        type = "set_pattern_sure"
                        initLayout()
                    }

                    "set_pattern_sure"->{
                       var  pass =  MyUtils.patternToString(mBinding.patterLockView, pattern)

                        if (pass_set!=pass){
                            showToastS("两次绘制图案不一致！")
                            mBinding.patterLockView.clearPattern()

                        }else{
                            startProgressDialog()
                            lar.b21(pass_set,pass_pattern,this@PatternAty)
                        }
                    }

                    "reset_pattern"->{
                        var pass =  MyUtils.patternToString(mBinding.patterLockView, pattern)

                        if (pass_pattern!=pass){
                            showToastS("旧手势图案绘制错误！")
                        }else{
                            type = "set_pattern"
                            initLayout()
                        }
                    }

                }
                mBinding.patterLockView.clearPattern()
            }

            override fun onCleared() {}
        }


    fun initLayout(){
        when(type){
            "set_pattern"->{
                mBinding.tvDes.text = "請繪製新手勢图案"
            }
            "set_pattern_sure"->{
                mBinding.tvDes.text = "確認解鎖圖案"
            }
            "reset_pattern"->{
                mBinding.tvDes.text = "請繪製旧手勢图案"
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        initTopview2(mBinding.include.relayTopBg, resources.getString(R.string.c_4))
        mBinding.include.tvTitle.text = "手势設置"
        initLayout()
        with(mBinding) {
            patterLockView.setAspectRatioEnabled(true)
            patterLockView.setAspectRatio(PatternLockView.AspectRatio.ASPECT_RATIO_HEIGHT_BIAS)
            patterLockView.setViewMode(PatternLockView.PatternViewMode.CORRECT)
            patterLockView.setDotAnimationDuration(150)
            patterLockView.setPathEndAnimationDuration(100)
            patterLockView.setInStealthMode(false)
            patterLockView.setTactileFeedbackEnabled(true)
            patterLockView.setInputEnabled(true)
            patterLockView.addPatternLockListener(mPatternLockViewListener)
        }
    }
}
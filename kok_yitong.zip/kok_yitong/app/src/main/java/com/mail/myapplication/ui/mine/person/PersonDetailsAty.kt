package com.mail.myapplication.ui.mine.person

import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.text.TextUtils
import android.util.TypedValue
import android.view.View
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.lifecycle.Lifecycle
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.adapter.FragmentStateAdapter
import androidx.viewpager2.widget.ViewPager2
import com.google.android.material.appbar.AppBarLayout
import com.google.android.material.appbar.CollapsingToolbarLayout
import com.mail.comm.app.AppConfig
import com.mail.comm.app.BaseApp
import com.mail.comm.image.ImageLoader
import com.mail.comm.net.AESCBCCrypt
import com.mail.comm.utils.*
import com.mail.comm.view.load.XLoadTip
import com.mail.myapplication.BaseXAty
import com.mail.myapplication.R
import com.mail.myapplication.databinding.AtyPerDetailsBinding
import com.mail.myapplication.interfaces.Lar
import com.mail.myapplication.ui.home.HomeListFrg
import com.mail.myapplication.ui.mine.EditInfoAty
import com.mail.myapplication.ui.mine.EditInfoBannerAdapter
import com.mail.myapplication.ui.mine.daresquare.DarenSquareBannerAdapter
import com.mail.myapplication.ui.mine.fans.FansGroupDetailsAty
import com.mail.myapplication.ui.mine.fans.FansGroupMyJoinAty
import com.mail.myapplication.ui.mine.person.cp.PersonCpAty
import com.mail.myapplication.ui.mine.person.cp.PersonCpPreListAty
import com.mail.myapplication.ui.mine.person.giftwall.GiftWallAty
import com.mail.myapplication.ui.mine.post.PostSendAty
import com.mail.myapplication.ui.mine.shop.ShopAty
import com.mail.myapplication.ui.msg.FansAty
import com.mail.myapplication.ui.utils.MyUtils3
import com.mail.myapplication.ui.wallet.ShareAty
import com.yhz.adaptivelayout.utils.AutoUtils
import com.youth.banner.indicator.CircleIndicator
import org.xutils.common.util.LogUtil
import kotlin.math.abs

class PersonDetailsAty : BaseXAty() {

    lateinit var mBinding: AtyPerDetailsBinding
    lateinit var list_tv: Array<TextView>
    lateinit var list_v: Array<View>
    var typePage = "my"
    var info_code=""
    var lar = Lar()
    var avatar_log =""
    var map_info:MutableMap<String,String>?=null

    var mPersonMoreDg:PersonMoreDg?=null

    override fun getLayoutId(): Int = 0

    override fun getLayoutView(): View {
        mBinding = AtyPerDetailsBinding.inflate(layoutInflater);
        return mBinding.root
    }

    override fun initView() {
        info_code =PreferencesUtils.getString(this@PersonDetailsAty,"info_code")
        typePage =intent.getStringExtra("typePage").toString()

        with(mBinding){
            list_tv = arrayOf(tv00,tv01,tv02, tv03,tv04)
            list_v = arrayOf(v00,v01,v02, v03,v04)
        }
        initLayout()
    }

    override fun requestData() {
        mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.loading)
        lar.b6(this)
    }

    override fun onResume() {
        super.onResume()
//        initMyInfo()
    }

    override fun onComplete(var2: String?, type: String?) {
        super.onComplete(var2, type)

        if (type == "user/info") {
            var map = JSONUtils.parseKeyAndValueToMap(var2)
            if (map["code"] == "200") {
                mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.finish)
                var str_info = AESCBCCrypt.aesDecrypt(map["data"])
                 map_info = JSONUtils.parseKeyAndValueToMap(str_info)
                MyUtils.saveMyInfo(this, map_info as java.util.HashMap<String, String>)
                initMyInfo()


                var info_is_creator = map_info!!["is_creator"]
                var is_add_fans_group = map_info!!["is_add_fans_group"]


                var list_head = ArrayList<MutableMap<String,String>>()

                var map_1 = HashMap<String,String>()
                map_1["avatar"] = map_info!!["avatar"].toString()
                list_head.add(map_1)
                avatar_log = map_info!!["avatar_log"].toString()
                var avatar_log_list = JSONUtils.parseKeyAndValueToMapList(avatar_log)
                if (avatar_log_list!=null &&avatar_log_list.size>0){
                    list_head.addAll(avatar_log_list)
                }

                var adapterImg = EditInfoBannerAdapter(list_head,this@PersonDetailsAty)

                mBinding.banner1.setAdapter(adapterImg)

                var cp_user_avatar = map_info!!["cp_user_avatar"]
                var maxW = AutoUtils.getPercentWidthSizeBigger(300)
                if (!TextUtils.isEmpty(cp_user_avatar)){
                    ImageLoader.loadImageAes(this, cp_user_avatar, mBinding.ivHeadCp, maxW, maxW)
                    mBinding.imgvCp.setImageResource(R.drawable.ia_55)
                }

                var user_frame_avatar = map_info!!["user_frame_avatar"]
                if (!TextUtils.isEmpty(user_frame_avatar)&&user_frame_avatar != "null"){
                    ImageLoader.loadImageAes(this@PersonDetailsAty,map_info!!["user_frame_avatar"],mBinding.ivCover,maxW,maxW)
                }

                if (is_add_fans_group =="1"){
                    mBinding.imgvIsAddFansGroup.visibility = View.VISIBLE
                }else{
                    mBinding.imgvIsAddFansGroup.visibility = View.GONE
                }

                if (info_is_creator=="1"){
                    LogUtil.e("info_is_creator="+info_is_creator)
                    mBinding.imgvCreator.visibility = View.VISIBLE
                    var maxW_head = AutoUtils.getPercentWidthSizeBigger(400)
                    ImageLoader.loadImageAes(this@PersonDetailsAty, map_info!!["creator_icon"], mBinding.imgvCreator,maxW_head,maxW_head)
                }else{
                    mBinding.imgvCreator.visibility = View.GONE
                }

            }else{
                mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.error)
            }
        }
    }

    override fun onExceptionType(type: String?) {
        super.onExceptionType(type)
        if (type == "user/info"){
            mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.error)
        }
    }


   fun initMyInfo(){
       with(mBinding){

           var info_nick =PreferencesUtils.getString(this@PersonDetailsAty,"info_nick")
           var info_flow =PreferencesUtils.getString(this@PersonDetailsAty,"info_flow")
           var info_fans =PreferencesUtils.getString(this@PersonDetailsAty,"info_fans")
           var info_avatar =PreferencesUtils.getString(this@PersonDetailsAty,"info_avatar")
           var info_intro =PreferencesUtils.getString(this@PersonDetailsAty,"info_intro")
           var info_city =PreferencesUtils.getString(this@PersonDetailsAty,"info_city")
           var info_years =PreferencesUtils.getString(this@PersonDetailsAty,"info_years")
           var info_job =PreferencesUtils.getString(this@PersonDetailsAty,"info_job")
           var info_gender =PreferencesUtils.getString(this@PersonDetailsAty,"info_gender")
           var info_vip_level =PreferencesUtils.getString(this@PersonDetailsAty,"info_vip_level")
           var info_is_creator =PreferencesUtils.getString(this@PersonDetailsAty,"info_is_creator")
           var info_vip_expired =PreferencesUtils.getString(this@PersonDetailsAty,"info_vip_expired")
           var has_fans_group = BaseApp.instance?.getOneMapData("has_fans_group")
           var fans_count_num = BaseApp.instance?.getOneMapData("fans_count_num")
           var jon_group_num = BaseApp.instance?.getOneMapData("join_group_num")

           var maxW = AutoUtils.getPercentWidthSizeBigger(500)

           ImageLoader.loadImageAes(this@PersonDetailsAty,info_avatar,ivHead,maxW,maxW)
           mBinding.tvName.text = info_nick
           mBinding.tvName2.text = info_nick
           mBinding.tvAttenNum.text =info_flow
           mBinding.tvFansNum.text =info_fans
           mBinding.tvId.text = "${info_code}"
           mBinding.tvFanstuanNum.text = jon_group_num


           when (info_gender) {

               "1" -> {
                   mBinding.imgvGender.setImageResource(R.drawable.ia_74)
               }

               "0" -> {
                   mBinding.imgvGender.setImageResource(R.drawable.ia_75)
               }

               "10" -> {
                   mBinding.imgvGender.setImageResource(R.drawable.ia_73)
               }

               else -> {
                   mBinding.imgvGender.visibility = View.GONE
               }

           }

           if (info_is_creator== "1") {
               mBinding.imgvCreator.visibility = View.VISIBLE
           } else {
               mBinding.imgvCreator.visibility = View.GONE
           }

//           if(!TextUtils.isEmpty(info_vip_expired)&&info_vip_level!="0"){
//               var time =  (TimeUtils.getTime(info_vip_expired).toDouble()
//                       - TimeUtils.getBeijinTime().toDouble())/1000
//               mBinding.tvVipTime.text = TimeUtils.formatSecond3(time).replace("前","后")+"到期"
//           }

           MyUtils3.setVipLevel(info_vip_level,  mBinding.imgvVipLevel,0)




       }

   }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setTranslanteBar()
        if (AppConfig.model == "wanou"){
            setAndroidNativeLightStatusBar(false)
        }else{
            setAndroidNativeLightStatusBar(true)
        }
        initMyInfo()
        with(mBinding){

            banner1.addBannerLifecycleObserver(this@PersonDetailsAty)
            banner1.isAutoLoop(true)

            var mLayoutManager2 = GridLayoutManager(this@PersonDetailsAty,1)
            mLayoutManager2.orientation = RecyclerView.VERTICAL

            var list =  ArrayList<String>()
            list.add("")
            list.add("mine_like")
            list.add("mine_my")
            list.add("mine_buy")
            list.add("fans")

            viewPager.adapter = PersonListAdataper(supportFragmentManager, this@PersonDetailsAty.lifecycle, list)


            appbar.addOnOffsetChangedListener(AppBarLayout.OnOffsetChangedListener { appBarLayout, verticalOffset ->
                val Offset = abs(verticalOffset).toFloat()
                val totalScrollRange = appBarLayout?.totalScrollRange
                var a =(Offset/ totalScrollRange!!)
                linlayName.alpha= a
//                if (AppConfig.model != "wanou"){
                    relayBack2.alpha= a
                    relayMore2.alpha = a
//                }

//                relayReport.alpha= a
//                imgvAddAttention.alpha= a
            })

            linlay00.setOnClickListener {
                viewPager.setCurrentItem(0,true)
            }
            linlay01.setOnClickListener {
                viewPager.setCurrentItem(1,true)
            }
            linlay02.setOnClickListener {
                viewPager.setCurrentItem(2,true)
            }

            linlay03.setOnClickListener {
                viewPager.setCurrentItem(3,true)
            }
            linlay04.setOnClickListener {
                viewPager.setCurrentItem(4,true)
            }
            viewPager.offscreenPageLimit = list.size

            viewPager.registerOnPageChangeCallback(object: ViewPager2.OnPageChangeCallback() {
                override fun onPageSelected(position: Int) {
                    when(position){
                        0 -> {
                            setSelector(tv00)
                        }
                        1 -> {
                            setSelector(tv01)
                        }
                        2 -> {
                            setSelector(tv02)
                        }
                        3 -> {
                            setSelector(tv03)
                        }
                        4 -> {
                            setSelector(tv04)
                        }
                    }
                }
            })

            when(typePage){
                "my"->{
                    linlay02.performClick()
                }
            }

            mBinding.loading.setLoadingTipXReloadCallback(object : XLoadTip.LoadingTipXReloadCallback {
                override fun reload() {
                    requestData()
                }
            })
        }


    }

    inner class PersonListAdataper(fa: FragmentManager, lifecycle: Lifecycle, val docs : MutableList<String>) :

        FragmentStateAdapter(fa, lifecycle) {

        override fun getItemCount(): Int =docs.size

        override fun createFragment(position: Int): Fragment {

            if (TextUtils.isEmpty(docs[position])){
                return PersonDetailsFrg()
            }
            return  HomeListFrg.create2(docs[position],info_code)
        }
    }

    private fun setSelector(tv: TextView) {
        for (i in list_tv.indices) {
            if (tv === list_tv[i]) {
                list_tv[i].setTextColor(Color.parseColor(getString(R.string.c_01)))
                list_tv[i].setTypeface(Typeface.defaultFromStyle(Typeface.BOLD));//加粗

                list_tv[i].setTextSize(TypedValue.COMPLEX_UNIT_PX, AutoUtils.getPercentWidthSizeBigger(55).toFloat())
                list_v[i].visibility = View.VISIBLE
            } else {
                list_tv[i].setTextColor(Color.parseColor(getString(R.string.c_02)))
                list_tv[i].setTypeface(Typeface.defaultFromStyle(Typeface.NORMAL));//加粗
                list_tv[i].setTextSize(TypedValue.COMPLEX_UNIT_PX, AutoUtils.getPercentWidthSizeBigger(45).toFloat())
                list_v[i].visibility = View.INVISIBLE
            }
        }
    }

    fun initLayout(){
        with(mBinding){
            var params =toolbar.layoutParams  as CollapsingToolbarLayout.LayoutParams
            var StatusBarHeight = MyUtils2.getStateBar(this@PersonDetailsAty)
            if (StatusBarHeight <= 0) {
                StatusBarHeight = MyUtils2.dip2px(this@PersonDetailsAty, 20F)
            }
            params.topMargin = StatusBarHeight
            params.height = AutoUtils.getPercentHeightSizeBigger(120)
            toolbar.setPadding(0,0,0,0)
            toolbar.layoutParams =params
        }
        initLayout2()
    }

    fun initLayout2(){
//        with(mBinding){
//            var params =linlayTop.layoutParams  as RelativeLayout.LayoutParams
//            var StatusBarHeight = MyUtils2.getStateBar(this@PersonDetailsAty)
//            if (StatusBarHeight <= 0) {
//                StatusBarHeight = MyUtils2.dip2px(this@PersonDetailsAty, 20F)
//            }
//            params.topMargin = StatusBarHeight+AutoUtils.getPercentHeightSizeBigger(150)
//            linlayTop.layoutParams =params
//        }
    }

    fun mainClick(v: View) {

        when (v.id) {

            R.id.tv_atten_num,R.id.tv_atten_1 ->{
                var bundle = Bundle()
                bundle.putString("type","favorite")
                startActivity(FansAty::class.java,bundle)
            }

            R.id.tv_fanstuan_1,R.id.tv_fanstuan_num ->{
                var bundle = Bundle()
                bundle.putString("type","fans")
                startActivity(FansAty::class.java,bundle)
            }

            R.id.imgv_shop ->{
                startActivity(ShopAty::class.java)
            }

            R.id.relay_cp ->{
                var bundle = Bundle()
                bundle.putString("user_code",info_code)
                startActivity(PersonCpAty::class.java,bundle)
            }

//            R.id.imgv_cp ->{
//                var bundle = Bundle()
//                bundle.putString("user_code",info_code)
//                startActivity(PersonCpAty::class.java,bundle)
//            }

//            R.id.imgv_fans_group ->{
//                var info_code = BaseApp.instance?.getOneMapData("info_code")
//                var info_nick = BaseApp.instance?.getOneMapData("info_nick")
//                var bundle = Bundle()
//                bundle.putString("user_id",info_code)
//                bundle.putString("user_name",info_nick)
//                startActivity(FansGroupDetailsAty::class.java,bundle)
//            }


            R.id.relay_create_fans_group ->{
                var info_code = BaseApp.instance?.getOneMapData("info_code")
                var info_nick = BaseApp.instance?.getOneMapData("info_nick")
                var bundle = Bundle()
                bundle.putString("user_id",info_code)
                bundle.putString("user_name",info_nick)
                startActivity(FansGroupDetailsAty::class.java,bundle)
            }

            R.id.relay_back,R.id.relay_back2 -> {
                finish()
            }

            R.id.relay_edit -> {
                var bundle = Bundle()
                bundle.putString("avatar_log",avatar_log)
                startActivityForResult(EditInfoAty::class.java,bundle,190)
            }

            R.id.framlay_head -> {
            }

            R.id.imgv_post -> {
                startActivity(PostSendAty::class.java)
            }

            R.id.tv_fans_group ,R.id.tv_fanstuan_num->{
                startActivity(FansGroupMyJoinAty::class.java)
            }

            R.id.relay_fans_group ->{
                var info_code = BaseApp.instance?.getOneMapData("info_code")
                var info_nick = BaseApp.instance?.getOneMapData("info_nick")
                var bundle = Bundle()
                bundle.putString("user_id",info_code)
                bundle.putString("user_name",info_nick)
                startActivity(FansGroupDetailsAty::class.java,bundle)
            }

            R.id.relay_gift_wall ->{
                var bundle = Bundle()
                bundle.putString("user_code",info_code)
                startActivity(GiftWallAty::class.java,bundle)
            }

            R.id.relay_more2 ,R.id.relay_more->{

                if(mPersonMoreDg == null){
                    mPersonMoreDg = PersonMoreDg(this)
                }
                mPersonMoreDg?.setPersonMoreDgListen(object : PersonMoreDg.PersonMoreDgListen{
                    override fun onClickShare() {
                        startActivity(ShareAty::class.java)
                    }

                    override fun onClickCpPre() {
                        startActivity(PersonCpPreListAty::class.java)
                    }

                })
                mPersonMoreDg?.show()


            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (resultCode != RESULT_OK) {
            return
        }
        when (requestCode) {

            190 -> {
                var type = data?.getStringExtra("edit_type")!!
                if (type == "edit_ok"){
                    requestData()
                }
            }

        }
    }





}
package com.mail.myapplication.ui.mine.shop

import android.annotation.SuppressLint
import android.app.Dialog
import android.os.Bundle
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.mail.comm.base.BaseAty
import com.mail.comm.image.ImageLoader
import com.mail.comm.net.AESCBCCrypt
import com.mail.comm.utils.JSONUtils
import com.mail.comm.utils.PreferencesUtils
import com.mail.comm.view.load.XLoadTip
import com.mail.comm.view.refresh.XRefreshInterface
import com.mail.myapplication.BaseXFrg
import com.mail.myapplication.R
import com.mail.myapplication.databinding.FrgGiftWall1Binding
import com.mail.myapplication.databinding.FrgShopBinding
import com.mail.myapplication.databinding.ItemFrgShopBinding
import com.mail.myapplication.databinding.ItemGiftWall1Binding
import com.mail.myapplication.interfaces.Home
import com.mail.myapplication.ui.MainWalletAty
import com.yhz.adaptivelayout.utils.AutoUtils

class ShopFrg : BaseXFrg() {

    var home = Home()
    lateinit var mBinding: FrgShopBinding
    var list = ArrayList<MutableMap<String, String>>()
    var mAdapter: GoldRecyclerAdapter? = null

    var mShopDg: ShopDg? = null
    var mShopDg2: Shop2Dg? = null
    var type_frg = ""
    var info_avatar = ""
    var index_click = -1

    override fun getLayoutId() = 0

    override fun initView() {
        type_frg = arguments?.getString("type").toString()
        info_avatar = PreferencesUtils.getString(requireActivity(), "info_avatar")
    }

    companion object {

        fun create(type: String): ShopFrg {
            val fragment = ShopFrg()
            val bundle = Bundle()
            bundle.putString("type", type)
            fragment.arguments = bundle
            return fragment
        }

    }

    override fun getLayoutView(): View {
        mBinding = FrgShopBinding.inflate(layoutInflater);
        return mBinding.root
    }

    override fun requestData() {
        mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.loading)

        when (type_frg) {

            "1" -> {
                home?.a71("", "1", this)
            }

            "2" -> {
                home?.a71("2", "", this)
            }
        }
    }

    fun requestData2(){
        when (type_frg) {

            "1" -> {
                home?.a71("", "1", this)
            }

            "2" -> {
                home?.a71("2", "", this)
            }
        }
    }

    override fun onComplete(var2: String?, type: String?) {
        super.onComplete(var2, type)
        if (type == "shop/list") {

            mBinding.swipeRefreshLayout.finishRefreshing()
            mBinding.swipeRefreshLayout.finishLoadmore()
            var map = JSONUtils.parseKeyAndValueToMap(var2)
            if (map["code"] == "200") {
                mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.finish)
                var str = AESCBCCrypt.aesDecrypt(map["data"])
                list = JSONUtils.parseKeyAndValueToMapList(str)
                mAdapter?.notifyDataSetChanged()

                if (list.size == 0) {
                    mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.empty)
                }

            } else {
                mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.error)
            }
        }

        if (type == "shop/purchase") {
            stopProgressDialog()
            var map = JSONUtils.parseKeyAndValueToMap(var2)
            showToastS(map["message"])

            if (map["code"] == "200") {
                requestData()
            }
        }

        if (type == "select/frame") {
            stopProgressDialog()
            var map = JSONUtils.parseKeyAndValueToMap(var2)
            showToastS(map["message"])
            if (map["code"] == "200") {
                requestData()
//                mAdapter?.notifyItemChanged(index_click)
            }else{

            }
        }
    }

    override fun onExceptionType(type: String?) {
        super.onExceptionType(type)
        stopProgressDialog()
        if (type == "shop/list") {
            mBinding.swipeRefreshLayout.finishRefreshing()
            mBinding.swipeRefreshLayout.finishLoadmore()
            mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.error)
        }
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)

        var mLayoutManager = GridLayoutManager(requireContext(), 3)
        mLayoutManager.orientation = RecyclerView.VERTICAL
        mBinding.recyclerview.layoutManager = mLayoutManager
        mAdapter = GoldRecyclerAdapter()
        mBinding.recyclerview.adapter = mAdapter

        mBinding.loading.setLoadingTipXReloadCallback(object : XLoadTip.LoadingTipXReloadCallback {
            override fun reload() {
                requestData()
            }
        })

        mBinding.swipeRefreshLayout.setEnableLoadmore(true)
        mBinding.swipeRefreshLayout.setEnableRefresh(true)
        mBinding.swipeRefreshLayout.setXRefreshAndLoadListen(object : XRefreshInterface {
            override fun refreshStart() {
                requestData2()
            }

            override fun loadMoreStart() {
                requestData2()
            }
        })

    }

    inner class GoldRecyclerAdapter : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
            return fGoldViewHolder(ItemFrgShopBinding.inflate(LayoutInflater.from(context)))
        }

        override fun getItemCount(): Int = list.size

        override fun getItemViewType(position: Int): Int {
            return position
        }

        override fun onBindViewHolder(holder: RecyclerView.ViewHolder, @SuppressLint("RecyclerView") position: Int) {

            if (holder is fGoldViewHolder) {

                with(holder) {

                    with(mBinding) {

                        var maxW = AutoUtils.getPercentWidthSizeBigger(400)
                        ImageLoader.loadImageAes(requireActivity(),
                            list[position]["cover"],
                            ivCover,
                            maxW,
                            maxW)
                        tvName.text = list[position]["title"]

                        if (type_frg == "2"){
                            tvCoins.text = "专属头像框"
                        }else{
                            tvCoins.text = list[position]["coins"] + "金币"
                        }

                        if (list[position]["has_frame"] == "1"){
                            tvHasFrame.visibility = View.VISIBLE

                            if (list[position]["is_select"] == "1"){
                                tvHasFrame.text = "已佩戴"
                            }else{
                                tvHasFrame.text = "已拥有"
                            }

                        }else{
                            tvHasFrame.visibility = View.GONE
                        }

                        itemView.setOnClickListener {

                            if (type_frg == "2"){
                                showBuilder(list[position]["title"].toString(),list[position]["cover"].toString())
                                return@setOnClickListener
                            }

                            index_click = position
                            if (list[position]["has_frame"] == "1"){
                                if (mShopDg2 == null){
                                    mShopDg2 = Shop2Dg(this@ShopFrg.requireActivity() as BaseAty)
                                }
                                mShopDg2?.show()
                                mShopDg2?.setShop2DgListen(object : Shop2Dg.Shop2DgListen{
                                    override fun click() {

                                        if (index_click == -1){
                                            return
                                        }

                                        var is_select =""
                                        if (list[position]["is_select"] == "1"){
                                            is_select ="0"
                                        }else{
                                            is_select ="1"
                                        }

                                        startProgressDialog()
                                        home.a87(list[index_click]["id"].toString(),is_select,this@ShopFrg)

                                    }
                                })

                                mShopDg2?.setData(
                                    list[position]["is_select"].toString(),
                                    list[position]["title"].toString(),
                                    list[position]["cover"].toString(),
                                    info_avatar)

                            }else{
                                if (mShopDg == null){
                                    mShopDg = ShopDg(this@ShopFrg.requireActivity() as BaseAty)
                                }

                                mShopDg?.setShopDgListen(object : ShopDg.ShopDgListen{
                                    override fun buyFrame(frame_id: String, price_id: String) {
                                        startProgressDialog()
                                        home.a86(frame_id,price_id,this@ShopFrg)
                                    }
                                })

                                mShopDg?.show()
                                mShopDg?.setData(
                                    list[position]["id"].toString(),
                                    list[position]["title"].toString(),
                                    list[position]["cover"].toString(),
                                    info_avatar)
                            }

                        }

                    }

                }

            }

        }

        inner class fGoldViewHolder(binding: ItemFrgShopBinding) :
            RecyclerView.ViewHolder(binding.root) {

            var mBinding: ItemFrgShopBinding = binding

            init {
                AutoUtils.autoSize(binding.root)

            }
        }

    }

    fun showBuilder(content:String,head_frame:String) {
        val view = View.inflate(requireActivity(), R.layout.dg_shop_vip, null)
        val ivHead = view.findViewById<View>(R.id.ivHead) as ImageView
        val ivCover = view.findViewById<View>(R.id.ivCover) as ImageView
        val tv_name= view.findViewById<View>(R.id.tv_name) as TextView
        val tv_vip= view.findViewById<View>(R.id.tv_vip) as TextView

        var dialogUpdate = Dialog(requireActivity()!!, R.style.dialogFullscreen3)

        val dialogWindow = dialogUpdate.window

        dialogWindow!!.setBackgroundDrawable(null)
        dialogWindow.setGravity(Gravity.BOTTOM)
        dialogUpdate.setCanceledOnTouchOutside(true)
        val m = requireActivity().windowManager
        val d = m.defaultDisplay// 获取屏幕宽、高
        val p = dialogWindow.attributes
        dialogWindow?.getDecorView()?.setPadding(0, 0, 0, 0)
        p.width = (d.width * 1) // 宽度设置为屏幕的0.85
        dialogWindow.attributes = p

        tv_name.text = content
        var maxW = AutoUtils.getPercentWidthSizeBigger(500)
        ImageLoader.loadImageAes(requireActivity(),head_frame,ivCover,maxW,maxW)
        ImageLoader.loadImageAes(requireActivity(),info_avatar,ivHead,maxW,maxW)

        tv_vip.setOnClickListener { v: View? ->
            dialogUpdate.dismiss()
            var bundle = Bundle()
            bundle.putString("page_type","pay")
            startActivity(MainWalletAty::class.java,bundle)
        }

        dialogUpdate.setContentView(view)
        dialogUpdate.setCancelable(true)
        dialogUpdate.show()
    }


}
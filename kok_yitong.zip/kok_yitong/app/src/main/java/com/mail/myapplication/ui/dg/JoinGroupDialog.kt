package com.mail.myapplication.ui.dg

import android.app.Dialog
import android.os.Bundle
import android.view.*
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.lzy.okgo.utils.HttpUtils.runOnUiThread
import com.mail.comm.base.BaseAty
import com.mail.comm.base.BaseDgFrg
import com.mail.comm.utils.MyUtils
import com.mail.comm.utils.ToastUitl
import com.mail.comm.view.WheelView.OnWheelViewListener
import com.mail.myapplication.R
import com.mail.myapplication.databinding.DgBindPhoneBinding
import com.mail.myapplication.databinding.DgJoinGroupBinding


class JoinGroupDialog(context: BaseAty) : Dialog(context) {

    var baseAty = context
    var listener :RechargeListen? =null
    lateinit var mBinding: DgJoinGroupBinding
    var info = ""
    var type_pay = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        mBinding = DgJoinGroupBinding.inflate(layoutInflater);
        setContentView(mBinding.root)
        window?.setWindowAnimations(R.style.dialogFullscreen2)

        window!!.setBackgroundDrawable(null)
        window!!.setGravity(Gravity.CENTER)
        setCanceledOnTouchOutside(false)
        val m = baseAty.windowManager
        val d = m.defaultDisplay// 获取屏幕宽、高
        val p = window!!.attributes
        window?.getDecorView()?.setPadding(0, 0, 0, 0)
//        p.height =  (d.height * 1) // 高度设置为屏幕的0.6
        p.width = (d.width * 1) // 宽度设置为屏幕的0.85
        window!!.attributes = p

        mBinding.tv01.setOnClickListener {

            dismiss()
            listener?.onclik01()
        }
        mBinding.tv02.setOnClickListener {
            dismiss()
            listener?.onclik02(type_pay)
        }
    }

    interface  RechargeListen{
        fun onclik01()
        fun onclik02(type:String)
    }

    fun setRechargeListen(listener:RechargeListen){
        this.listener =listener
    }

    fun setData(gold:String,nick:String,type:String){
        if (isShowing){
            this.type_pay = type
            with(mBinding){
                tvContent.text = "你确定要花费${gold}金币加入${nick}的私密團吗？"
            }
        }

    }


}
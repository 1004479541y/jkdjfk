package com.mail.myapplication.ui.mine.post

import android.content.Intent
import android.os.Bundle
import android.view.View
import com.mail.myapplication.BaseXAty
import com.mail.myapplication.R
import com.mail.myapplication.databinding.AtyPostSendPerBinding

class PostSendPerAty:BaseXAty() {

    lateinit var mBinding: AtyPostSendPerBinding

    override fun getLayoutId(): Int = 0

    override fun initView() {
    }

    override fun requestData() {
    }

    override fun getLayoutView(): View {
        mBinding = AtyPostSendPerBinding.inflate(layoutInflater);
        return mBinding.root
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        with(mBinding) {
            initTopview2(include.relayTopBg)
            include.tvTitle.text = "选择人群"
        }
    }

    fun mainClick(v: View) {

        when (v.id) {

            R.id.relay_back -> {
                finish()
            }

            R.id.relay_01 ->{
                var intent = Intent()
                intent.putExtra("personType","1")
                setResult(RESULT_OK,intent)
                finish()
            }

            R.id.relay_02 ->{
                var intent = Intent()
                intent.putExtra("personType","0")
                setResult(RESULT_OK,intent)
                finish()
            }
        }
    }
}
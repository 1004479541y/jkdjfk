package com.mail.myapplication.ui.mine.daresquare

import android.os.Bundle
import android.view.View
import com.mail.myapplication.BaseXAty
import com.mail.myapplication.R
import com.mail.myapplication.databinding.*
import com.mail.myapplication.ui.mine.apply.AuthAty
import com.mail.myapplication.ui.wallet.IncomeAty

class DarenSquareMakeOriginalAty : BaseXAty() {

    lateinit var mBinding: AtyDarenSquareMakeOriginalBinding

    override fun getLayoutId(): Int = 0

    override fun getLayoutView(): View {
        mBinding = AtyDarenSquareMakeOriginalBinding.inflate(layoutInflater);
        return mBinding.root
    }

    override fun initView() {
    }

    override fun requestData() {
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        initTopview2(mBinding.include.relayTopBg, resources.getString(R.string.c_4))
        mBinding.include.tvTitle.text = "創作公約"
    }

    fun mainClick(v: View) {

        when (v.id) {

            R.id.relay_back -> {
                finish()
            }

            R.id.linlay_auth -> {
                startActivity(AuthAty::class.java)
            }

            R.id.linlay_income -> {
                startActivity(IncomeAty::class.java)
            }
        }
    }



}
package com.mail.myapplication.interfaces

import android.text.TextUtils
import com.mail.comm.app.AppConfig
import com.mail.comm.net.ApiTool
import com.mail.comm.netretrofit.ApiRetrofit
import com.mail.comm.utils.MyUtils2
import com.yhz.adaptivelayout.abs.ApiListener
import org.xutils.http.RequestParams

class Home {

    fun a2(page: Int, apiListener: ApiListener) {
        val params = RequestParams(AppConfig.Host_Url + "/app/api/message/like/lists")
        params.addBodyParameter("page", page.toString())
        params.addBodyParameter("page_size", "20")
        ApiTool().postApi2(params, apiListener, "zan/lists")
    }

    fun a3(page: Int, apiListener: ApiListener) {
        val params = RequestParams(AppConfig.Host_Url + "/app/api/message/comment/lists")
        params.addBodyParameter("page", page.toString())
        params.addBodyParameter("page_size", "5")
        ApiTool().postApi2(params, apiListener, "comment/lists")
    }

    fun a4(page: Int, type: String, apiListener: ApiListener) {
        val params = RequestParams(AppConfig.Host_Url + "/app/api/relation/list")
        params.addBodyParameter("page", page.toString())
        params.addBodyParameter("page_size", "20")
        params.addBodyParameter("type", type)
        ApiTool().postApi2(params, apiListener, "fans/lists")
    }

    fun a400(page: Int, type: String, apiListener: ApiListener) {
        val params = RequestParams(AppConfig.Host_Url + "/app/api/user/official/notice")
        params.addBodyParameter("page", page.toString())
        params.addBodyParameter("page_size", "20")
        ApiTool().postApi2(params, apiListener, "notice/lists")
    }

    //兑换码信息
    fun a5(code: String, apiListener: ApiListener) {
        val params = RequestParams(AppConfig.Host_Url + "/app/api/code/info")
        params.addBodyParameter("code", code)
        ApiTool().postApi2(params, apiListener, "code/info")
    }

    //兑换
    fun a6(code: String, apiListener: ApiListener) {
        val params = RequestParams(AppConfig.Host_Url + "/app/api/code/exchange")
        params.addBodyParameter("code", code)
        ApiTool().postApi2(params, apiListener, "code/exchange")
    }

    //用户喜欢的帖子
    fun a8(page: Int, user_id: String, apiListener: ApiListener) {
        val params = RequestParams(AppConfig.Host_Url + "/app/api/user/list/forum/like")
        params.addBodyParameter("page", page.toString())
        params.addBodyParameter("page_size", "20")
        if (!TextUtils.isEmpty(user_id)) {
            params.addBodyParameter("user_id", user_id)
        }
        ApiTool().postApi2(params, apiListener, "home/list")
    }

    //首页帖子列表
    fun a7(
        page: Int, topic_id: String, is_new: String, is_hot: String,
        keywords: String, is_recommend: String, is_follow: String, apiListener: ApiListener,
    ) {
        val params = RequestParams(AppConfig.Host_Url + "/app/api/forum/lists")
        params.addBodyParameter("page", page.toString())
        params.addBodyParameter("page_size", "20")

        //话题ID
        if (!TextUtils.isEmpty(topic_id)) {
            params.addBodyParameter("topic_id", topic_id)
        }

        //是否最新 1是0否
        if (!TextUtils.isEmpty(is_new)) {
            params.addBodyParameter("is_new", is_new)
        }

        //是否最火  1是0否
        if (!TextUtils.isEmpty(is_hot)) {
            params.addBodyParameter("is_hot", is_hot)
        }

        //关键字  搜索时传参
        if (!TextUtils.isEmpty(keywords)) {
            params.addBodyParameter("keywords", keywords)
        }

        //是否推荐 1是0否
        if (!TextUtils.isEmpty(is_recommend)) {
            params.addBodyParameter("is_recommend", is_recommend)
        }

        //是否关注 1是0否
        if (!TextUtils.isEmpty(is_follow)) {
            params.addBodyParameter("is_follow", is_follow)
        }

        ApiTool().postApi2(params, apiListener, "home/list")
    }

//    //帖子详情(鉴权)-详情页面
//    fun a11(id: String, apiListener: ApiListener) {
//        val params = RequestParams(AppConfig.Host_Url + "/app/api/forum/info")
//        params.addBodyParameter("id", id)
//        ApiTool().postApi2(params, apiListener, "post/details_${id}_details_0")
//    }

    //帖子详情(鉴权)-非详情页面
    fun a10(id: String, apiListener: ApiListener) {
        val params = RequestParams(AppConfig.Host_Url + "/app/api/forum/info")
        params.addBodyParameter("id", id)
        ApiTool().postApi2(params, apiListener, "post/details")
    }

    //推荐用户列表
    fun a9(apiListener: ApiListener) {
        val params = RequestParams(AppConfig.Host_Url + "/app/api/user/recommend")
        ApiTool().postApi2(params, apiListener, "home/user/list")
    }

    //用户帖子
    fun a12(user_id: String, page: Int, is_fans: String, apiListener: ApiListener) {
        val params = RequestParams(AppConfig.Host_Url + "/app/api/user/list/forum")
        params.addBodyParameter("page", page.toString())
        params.addBodyParameter("page_size", "20")
        if (!TextUtils.isEmpty(user_id)) {
            params.addBodyParameter("user_id", user_id)
        }
        if (!TextUtils.isEmpty(is_fans)) {
            params.addBodyParameter("is_fans", is_fans)
        }
        ApiTool().postApi2(params, apiListener, "home/list")
    }

    //已购帖子
    fun a122(user_id: String, page: Int, apiListener: ApiListener) {
        val params = RequestParams(AppConfig.Host_Url + "/app/api/user/list/forum/buy")
        params.addBodyParameter("page", page.toString())
        params.addBodyParameter("page_size", "20")
        if (!TextUtils.isEmpty(user_id)) {
            params.addBodyParameter("user_id", user_id)
        }
        ApiTool().postApi2(params, apiListener, "home/list")
    }


    //评论列表
    fun a13(page: Int, id: String, apiListener: ApiListener) {
        val params = RequestParams(AppConfig.Host_Url + "/app/api/comment/lists")
        params.addBodyParameter("page", page)
        params.addBodyParameter("page_size", "20")
        params.addBodyParameter("module", "forum")
        params.addBodyParameter("svalue", id)
        params.addBodyParameter("parent_id", "0")
        ApiTool().postApi2(params, apiListener, "comment/list")
    }

    //回复列表
    fun a132(page: Int, id: String, parent_id: String, apiListener: ApiListener) {
        val params = RequestParams(AppConfig.Host_Url + "/app/api/comment/lists")
        params.addBodyParameter("page", page)
        params.addBodyParameter("page_size", "20")
        params.addBodyParameter("module", "forum")
        params.addBodyParameter("svalue", id)
        params.addBodyParameter("parent_id", parent_id)
        ApiTool().postApi2(params, apiListener, "relay/list")
    }

    fun a14(svalue: String, content: String, parent_id: String, apiListener: ApiListener) {
        val params = RequestParams(AppConfig.Host_Url + "/app/api/comment/write")
        params.addBodyParameter("module", "forum")
        params.addBodyParameter("svalue", svalue)
        params.addBodyParameter("content", content)
        params.addBodyParameter("parent_id", parent_id)
        ApiTool().postApi2(params, apiListener, "comment/write")
    }


    //帖子点赞
    fun a15(id: String, apiListener: ApiListener) {
        val params = RequestParams(AppConfig.Host_Url + "/app/api/forum/support")
        params.addBodyParameter("id", id)
        ApiTool().postApi2(params, apiListener, "post/zan")
    }


    //评论点赞
    fun a16(id: String, apiListener: ApiListener) {
        val params = RequestParams(AppConfig.Host_Url + "/app/api/comment/support")
        params.addBodyParameter("id", id)
        ApiTool().postApi2(params, apiListener, "comment/zan")
    }

    //用户资料(查看别人的)
    fun a17(code: String, apiListener: ApiListener) {
        val params = RequestParams(AppConfig.Host_Url + "/app/api/user/data")
        params.addBodyParameter("code", code)
        ApiTool().postApi2(params, apiListener, "other/info")
    }

    //用户资料(查看别人的)
    fun a173(code: String, apiListener: ApiListener) {
        val params = RequestParams(AppConfig.Host_Url + "/app/api/user/data")
        params.addBodyParameter("code", code)
        ApiTool().postApi2(params, apiListener, "other/info/atten")
    }

    //用户资料(查看别人的)
    fun a172(code: String, apiListener: ApiListener) {
        val params = RequestParams(AppConfig.Host_Url + "/app/api/user/data")
        params.addBodyParameter("code", code)
        ApiTool().postApi2(params, apiListener, "other/info2")
    }

    //话题列表
    fun a18(keywords: String, apiListener: ApiListener, page: Int = 1) {
        val params = RequestParams(AppConfig.Host_Url + "/app/api/topic/lists")
        params.addBodyParameter("page", page.toString())
        params.addBodyParameter("page_size", "10")
        if (!TextUtils.isEmpty(keywords)) {
            params.addBodyParameter("keywords", keywords)
        }
        ApiTool().postApi2(params, apiListener, "topic/list")
    }

    //话题搜索列表
    fun a182(keywords: String, apiListener: ApiListener, page: Int = 1) {
        val params = RequestParams(AppConfig.Host_Url + "/app/api/topic/lists")
        params.addBodyParameter("page", page.toString())
        params.addBodyParameter("page_size", "20")
        if (!TextUtils.isEmpty(keywords)) {
            params.addBodyParameter("keywords", keywords)
        }
        ApiTool().postApi2(params, apiListener, "topic/search/list")
    }

    //兑换
    fun a19(code: String, apiListener: ApiListener) {
        val params = RequestParams(AppConfig.Host_Url + "/app/api/code/exchange")
        params.addBodyParameter("code", code)
        ApiTool().postApi2(params, apiListener, "code/exchange")
    }

    //热门搜索推荐用户
    fun a20(apiListener: ApiListener) {
        val params = RequestParams(AppConfig.Host_Url + "/app/api/search/list/user")
        ApiTool().postApi2(params, apiListener, "user/list")
    }

    //热门搜索推荐关键字
    fun a21(apiListener: ApiListener) {
        val params = RequestParams(AppConfig.Host_Url + "/app/api/search/keywords/list")
        ApiTool().postApi2(params, apiListener, "keywords/list")
    }

    //热门搜索推荐帖子
    fun a22(apiListener: ApiListener) {
        val params = RequestParams(AppConfig.Host_Url + "/app/api/forum/recommend")
        ApiTool().postApi2(params, apiListener, "home/list")
    }

    //热门搜索-搜索用户结果
    fun a23(page: Int, keywords: String, apiListener: ApiListener) {
        val params = RequestParams(AppConfig.Host_Url + "/app/api/user/list/search")
        params.addBodyParameter("page", page.toString())
        params.addBodyParameter("page_size", "20")
        params.addBodyParameter("keywords", keywords)
        ApiTool().postApi2(params, apiListener, "search/list")
    }

    //历史活动
    fun a24(page: Int, keywords: String, from: String, apiListener: ApiListener) {
        val params = RequestParams(AppConfig.Host_Url + "/app/api/topic/lists")
        params.addBodyParameter("page", page.toString())
        params.addBodyParameter("page_size", "20")
        params.addBodyParameter("keywords", keywords)
        params.addBodyParameter("from", from)
        ApiTool().postApi2(params, apiListener, "topic/list")
    }

    //历史活动
    fun a25(id: String, apiListener: ApiListener) {
        val params = RequestParams(AppConfig.Host_Url + "/app/api/topic/info")
        params.addBodyParameter("id", id)
        ApiTool().postApi2(params, apiListener, "topic/info")
    }

    //邀请规则
    fun a26(apiListener: ApiListener) {
        val params = RequestParams(AppConfig.Host_Url + "/app/api/invite/rule")
        ApiTool().postApi2(params, apiListener, "invite/rule")
    }

    //帖子举报
    fun a27(id: String, apiListener: ApiListener) {
        val params = RequestParams(AppConfig.Host_Url + "/app/api/forum/report")
        params.addBodyParameter("id", id)
        ApiTool().postApi2(params, apiListener, "post/report")
    }

    //用户拉黑/屏蔽
    fun a28(type: String, to_user_id: String, apiListener: ApiListener) {
        val params = RequestParams(AppConfig.Host_Url + "/app/api/relation/do/block")
        params.addBodyParameter("type", type)
        params.addBodyParameter("to_user_id", to_user_id)
        ApiTool().postApi2(params, apiListener, "post/block")
    }

    //用户拉黑/屏蔽
    fun a29(page: Int, apiListener: ApiListener) {
        val params = RequestParams(AppConfig.Host_Url + "/app/api/relation/block/list")
        params.addBodyParameter("page", page.toString())
        params.addBodyParameter("page_size", "20")
        ApiTool().postApi2(params, apiListener, "block/list")
    }

    //用户拉黑/屏蔽
    fun a30(to_user_id: String, apiListener: ApiListener) {
        val params = RequestParams(AppConfig.Host_Url + "/app/api/relation/user/delete")
        params.addBodyParameter("to_user_id", to_user_id)
        ApiTool().postApi2(params, apiListener, "user/delete")
    }

    //用户拉黑/屏蔽
    fun a31(id: String, apiListener: ApiListener) {
        val params = RequestParams(AppConfig.Host_Url + "/app/api/forum/delete")
        params.addBodyParameter("id", id)
        ApiTool().postApi2(params, apiListener, "post/delete")
    }

    //认证info
    fun a32(apiListener: ApiListener) {
        val params = RequestParams(AppConfig.Host_Url + "/app/api/creator/info")
        ApiTool().postApi2(params, apiListener, "creator/info")
    }

    //去认证
    fun a33(selfie: String, video_selfie: String, apiListener: ApiListener) {
        val params = RequestParams(AppConfig.Host_Url + "/app/api/creator/auth")
        params.addBodyParameter("selfie", selfie)
        params.addBodyParameter("video_selfie", video_selfie)
        params.addBodyParameter("type", "1")
        ApiTool().postApi2(params, apiListener, "creator/auth")
    }

    //提现
    fun a34(
        withdraw_num: String,
        type: String,
        bank_address: String,
        bank_name: String,
        bank_no: String,
        real_name: String,
        usdt_name: String,
        usdt_address: String,
        apiListener: ApiListener,
    ) {
        val params = RequestParams(AppConfig.Host_Url + "/app/api/user/withdraw")

        params.addBodyParameter("withdraw_num", withdraw_num)
        params.addBodyParameter("type", type)

        if (!TextUtils.isEmpty(bank_address)) {
            params.addBodyParameter("bank_address", bank_address)
        }
        if (!TextUtils.isEmpty(bank_name)) {
            params.addBodyParameter("bank_name", bank_name)
        }
        if (!TextUtils.isEmpty(bank_no)) {
            params.addBodyParameter("bank_no", bank_no)
        }
        if (!TextUtils.isEmpty(real_name)) {
            params.addBodyParameter("real_name", real_name)
        }
        if (!TextUtils.isEmpty(usdt_name)) {
            params.addBodyParameter("usdt_name", usdt_name)
        }
        if (!TextUtils.isEmpty(usdt_address)) {
            params.addBodyParameter("usdt_address", usdt_address)
        }
        ApiTool().postApi2(params, apiListener, "withdraw")
    }


    //充值列表
    fun a35(page: Int, apiListener: ApiListener) {
        val params = RequestParams(AppConfig.Host_Url + "/app/api/log/list/recharge")
        params.addBodyParameter("page", page.toString())
        params.addBodyParameter("page_size", "20")
        ApiTool().postApi2(params, apiListener, "recharge/list")
    }

    //收益记录
    fun a36(page: Int, apiListener: ApiListener) {
        val params = RequestParams(AppConfig.Host_Url + "/app/api/log/list/profit")
        params.addBodyParameter("page", page.toString())
        params.addBodyParameter("page_size", "20")
        ApiTool().postApi2(params, apiListener, "profit/list")
    }

    //收益记录
    fun a37(page: Int, apiListener: ApiListener) {
        val params = RequestParams(AppConfig.Host_Url + "/app/api/log/list/withdraw")
        params.addBodyParameter("page", page.toString())
        params.addBodyParameter("page_size", "20")
        ApiTool().postApi2(params, apiListener, "withdraw/list")
    }

    //收益记录
    fun a377(page: Int, apiListener: ApiListener) {
        val params = RequestParams(AppConfig.Host_Url + "/app/api/log/list/expend")
        params.addBodyParameter("page", page.toString())
        params.addBodyParameter("page_size", "20")
        ApiTool().postApi2(params, apiListener, "expend/list")
    }

    //私信设置
    fun a38(message_type: String, apiListener: ApiListener) {
        val params = RequestParams(AppConfig.Host_Url + "/app/api/user/message/update")
        params.addBodyParameter("message_type", message_type)
        ApiTool().postApi2(params, apiListener, "message/update")
    }

    //兑换码信息
    fun a39(code: String, apiListener: ApiListener) {
        val params = RequestParams(AppConfig.Host_Url + "/app/api/user/bindcode")
        params.addBodyParameter("code", code)
        ApiTool().postApi2(params, apiListener, "bind/yqm")
    }

    //搜索用户列表
    fun a40(page: Int, keywords: String, apiListener: ApiListener) {
        val params = RequestParams(AppConfig.Host_Url + "/app/api/user/list/search")
        params.addBodyParameter("page", page.toString())
        params.addBodyParameter("keywords", keywords)
        params.addBodyParameter("page_size", "20")
        ApiTool().postApi2(params, apiListener, "search/user/list")
    }

    //模糊搜索 搜索用户列表
    fun a41(keywords: String, apiListener: ApiListener) {
        val params = RequestParams(AppConfig.Host_Url + "/app/api/search/by/elastic")
        params.addBodyParameter("keywords", keywords)
        ApiTool().postApi2(params, apiListener, "search/elastic")
    }

    fun a42(apiListener: ApiListener) {
        val params = RequestParams(AppConfig.Host_Url + "/app/api/site/version")
        params.addQueryStringParameter("device_type", "A")
        params.addQueryStringParameter("version_code", MyUtils2.getAppVersionName())
        ApiTool().getApi(params, apiListener, "version/update")
    }

    // 
    fun a43(
        to_user_code: String,
        user_code: String,
        msg: String,
        time: String,
        message_id: String,
        apiListener: ApiListener,
    ) {
        val params = RequestParams(AppConfig.Host_Url + "/app/api/message/create")
        params.addBodyParameter("dst", to_user_code)
        params.addBodyParameter("src", user_code)
        params.addBodyParameter("payload", msg)
        params.addBodyParameter("ms", time)
        params.addBodyParameter("message_id", message_id)
        ApiTool().postApi2(params, apiListener, "message/create")
    }

    //
    fun a432(
        to_user_code: String,
        user_code: String,
        msg: String,
        time: String,
        message_id: String,
        match_id: String,
        apiListener: ApiListener,
    ) {
        val params = RequestParams(AppConfig.Host_Url + "/app/api/message/create")
        params.addBodyParameter("dst", to_user_code)
        params.addBodyParameter("src", user_code)
        params.addBodyParameter("payload", msg)
        params.addBodyParameter("ms", time)
        params.addBodyParameter("message_id", message_id)
        if (!TextUtils.isEmpty(match_id)) {
            params.addBodyParameter("match_id", match_id)
        }
        ApiTool().postApi2(params, apiListener, "message/create/gift")
    }

    //聊天用户列表记录
    fun a44(apiListener: ApiListener) {
        val params = RequestParams(AppConfig.Host_Url + "/app/api/message/history/list")
        ApiTool().postApi2(params, apiListener, "message/history/list")
    }

    //聊天用户列表记录
    fun a45(page: Int, to_user_code: String, ms: String, apiListener: ApiListener) {
        val params = RequestParams(AppConfig.Host_Url + "/app/api/message/user/list")
        params.addBodyParameter("page", page)
        params.addBodyParameter("page_size", "10")
        params.addBodyParameter("dst", to_user_code)
        if (!TextUtils.isEmpty(ms)) {
            params.addBodyParameter("ms", ms)
        }
        ApiTool().postApi2(params, apiListener, "/app/api/message/user/list")
    }

    //用户举报
    fun a46(to_user_id: String, content: String, img: String, apiListener: ApiListener) {
        val params = RequestParams(AppConfig.Host_Url + "/app/api/user/report")
        params.addBodyParameter("to_user_id", to_user_id)
        params.addBodyParameter("content", content)
        if (!TextUtils.isEmpty(img)) {
            params.addBodyParameter("img", img)
        }
        ApiTool().postApi2(params, apiListener, "user/report")
    }

    //私信鉴权
    fun a47(to_user_id: String, apiListener: ApiListener) {
        val params = RequestParams(AppConfig.Host_Url + "/app/api/message/auth")
        params.addBodyParameter("dst", to_user_id)
        ApiTool().postApi2(params, apiListener, "message/auth")
    }

    //官方通知列表
    fun a48(page: Int, apiListener: ApiListener) {
        val params = RequestParams(AppConfig.Host_Url + "/app/api/message/official/notice")
        params.addBodyParameter("page", page.toString())
        params.addBodyParameter("page_size", "10")
        ApiTool().postApi2(params, apiListener, "/app/api/message/official/notice")
    }

    //统计帖子分享数
    fun a49(id: String, apiListener: ApiListener) {
        val params = RequestParams(AppConfig.Host_Url + "/app/api/forum/share")
        params.addBodyParameter("id", id)
        ApiTool().postApi2(params, apiListener, "forum/share")
    }

    //随机在线人数
    fun a50(apiListener: ApiListener) {
        val params = RequestParams(AppConfig.Host_Url + "/app/api/site/random/people")
        ApiTool().postApi2(params, apiListener, "random/people")
    }

    //客戶问答
    fun a51(apiListener: ApiListener) {
        val params = RequestParams(AppConfig.Host_Url + "/app/api/message/question/answer")
        ApiTool().postApi2(params, apiListener, "question/answer")
    }


    fun a52(apiListener: ApiListener) {
        val params = RequestParams(AppConfig.Host_Url + "/app/api/message/home")
        ApiTool().postApi2(params, apiListener, "find")
    }

    //匹配
    fun a53(type: String, match_id: String, apiListener: ApiListener) {
        val params = RequestParams(AppConfig.Host_Url + "/app/api/message/match")
        params.addBodyParameter("type", type)
        if (!TextUtils.isEmpty(match_id)) {
            params.addBodyParameter("match_id", match_id)
        }
        ApiTool().postApi2(params, apiListener, "match")
    }

    //取消匹配
    fun a54(match_id: String, apiListener: ApiListener) {
        val params = RequestParams(AppConfig.Host_Url + "/app/api/message/end/chat")
        params.addBodyParameter("match_id", match_id)
        ApiTool().postApi2(params, apiListener, "match/cancel")
    }

    //进入聊天
    fun a55(match_id: String, apiListener: ApiListener) {
        val params = RequestParams(AppConfig.Host_Url + "/app/api/message/chat")
        params.addBodyParameter("match_id", match_id)
        ApiTool().postApi2(params, apiListener, "match/details")
    }

    //进入聊天
    fun a552(match_id: String, apiListener: ApiListener) {
        val params = RequestParams(AppConfig.Host_Url + "/app/api/message/chat")
        params.addBodyParameter("match_id", match_id)
        ApiTool().postApi2(params, apiListener, "match/details/to")
    }

    //礼物列表
    fun a56(type:String,apiListener: ApiListener) {
        val params = RequestParams(AppConfig.Host_Url + "/app/api/gift/list")
        params.addBodyParameter("type", type)
        ApiTool().postApi2(params, apiListener, "gift/list")
    }

    //礼物帖子打赏
    fun a57(gift_id: String, related_id: String, apiListener: ApiListener) {
        val params = RequestParams(AppConfig.Host_Url + "/app/api/gift/reward")
        params.addBodyParameter("gift_id", gift_id)
        params.addBodyParameter("related_id", related_id)
        params.addBodyParameter("module", "forum")
        ApiTool().postApi2(params, apiListener, "gift/reward")
    }

    //取消匹配
    fun a58(match_id: String, apiListener: ApiListener) {
        val params = RequestParams(AppConfig.Host_Url + "/app/api/message/cancle/match")
        params.addBodyParameter("match_id", match_id)
        ApiTool().postApi2(params, apiListener, "cancle/match")
    }

    //时长列表
    fun a59(apiListener: ApiListener) {
        val params = RequestParams(AppConfig.Host_Url + "/app/api/message/time/list")
        ApiTool().postApi2(params, apiListener, "time/list")
    }

    //时长列表
    fun a60(match_id: String, time_id: String, apiListener: ApiListener) {
        val params = RequestParams(AppConfig.Host_Url + "/app/api/message/buy/time")
        params.addBodyParameter("match_id", match_id)
        params.addBodyParameter("time_id", time_id)
        ApiTool().postApi2(params, apiListener, "buy/time")
    }

    //正则
    fun a61(apiListener: ApiListener) {
        val params = RequestParams(AppConfig.Host_Url + "/app/api/site/filter/data")
        ApiTool().postApi2(params, apiListener, "filter/data")
    }

    //首页广告
    fun a62(apiListener: ApiListener) {
        val params = RequestParams(AppConfig.Host_Url + "/app/api/ad/list")
        params.addBodyParameter("position", "index_ad")
        ApiTool().postApi2(params, apiListener, "ad/home")
    }

    fun a63(apiListener: ApiListener) {
        val params = RequestParams(AppConfig.Host_Url + "/app/api/site/getBgImage")
        ApiTool().postApi2(params, apiListener, "getBgImage")
    }

    fun a64(id: String, apiListener: ApiListener) {
        val params = RequestParams(AppConfig.Host_Url + "/app/api/ad/count")
        params.addBodyParameter("id", id)
        ApiTool().postApi2(params, apiListener, "ad/count")
    }

    fun a65(apiListener: ApiListener) {
        val params = RequestParams(AppConfig.Host_Url + "/app/api/share/image/list")
        ApiTool().postApi2(params, apiListener, "image/bg")
    }

    fun a66(to_user_id: String, apiListener: ApiListener) {
        val params = RequestParams(AppConfig.Host_Url + "/app/api/gift/user/receive")
        params.addBodyParameter("to_user_id", to_user_id)
        ApiTool().postApi2(params, apiListener, "gift/wall")
    }

    fun a67(to_user_id: String, apiListener: ApiListener) {
        val params = RequestParams(AppConfig.Host_Url + "/app/api/gift/wall")
        params.addBodyParameter("to_user_id", to_user_id)
        ApiTool().postApi2(params, apiListener, "gift/wall/all")
    }


    fun a68(to_user_id: String, apiListener: ApiListener) {
        val params = RequestParams(AppConfig.Host_Url + "/app/api/gift/contribute/rate")
        params.addBodyParameter("to_user_id", to_user_id)
        ApiTool().postApi2(params, apiListener, "gift/rate")
    }

    fun a69(avatar: String, id: String, apiListener: ApiListener) {
        val params = RequestParams(AppConfig.Host_Url + "/app/api/user/update/avatar")
        if (!TextUtils.isEmpty(avatar)) {
            params.addBodyParameter("avatar", avatar)
        }
        if (!TextUtils.isEmpty(id)) {
            params.addBodyParameter("id", id)
        }
        ApiTool().postApi2(params, apiListener, "update/avatar/wall")
    }

    fun a70(avatar: String, id: String, apiListener: ApiListener) {
        val params = RequestParams(AppConfig.Host_Url + "/app/api/user/update/avatar")
        if (!TextUtils.isEmpty(avatar)) {
            params.addBodyParameter("avatar", avatar)
        }
        if (!TextUtils.isEmpty(id)) {
            params.addBodyParameter("id", id)
        }
        ApiTool().postApi2(params, apiListener, "update/avatar/wall/del")
    }

    fun a71(type: String, is_recommend: String, apiListener: ApiListener) {
        val params = RequestParams(AppConfig.Host_Url + "/app/api/frame/shop/list")
        if (!TextUtils.isEmpty(type)) {
            params.addBodyParameter("type", type)
        }
        if (!TextUtils.isEmpty(is_recommend)) {
            params.addBodyParameter("is_recommend", is_recommend)
        }
        ApiTool().postApi2(params, apiListener, "shop/list")
    }


    fun a72(to_user_id: String, apiListener: ApiListener) {
        val params = RequestParams(AppConfig.Host_Url + "/app/api/cp/list")
        params.addBodyParameter("to_user_id", to_user_id)
        ApiTool().postApi2(params, apiListener, "cp/list")
    }

    fun a73( apiListener: ApiListener) {
        val params = RequestParams(AppConfig.Host_Url + "/app/api/cp/order")
        ApiTool().postApi2(params, apiListener, "cp/order")
    }

    fun a74( id:String,to_user_code:String,apiListener: ApiListener) {
        val params = RequestParams(AppConfig.Host_Url + "/app/api/cp/purchase")
        params.addBodyParameter("id", id)
        params.addBodyParameter("to_user_code", to_user_code)
        ApiTool().postApi2(params, apiListener, "cp/purchase")
    }

    fun a75( room_id:String,to_user_id:String,apiListener: ApiListener) {
        val params = RequestParams(AppConfig.Host_Url + "/app/api/cp/info")
        if (!TextUtils.isEmpty(room_id)){
            params.addBodyParameter("room_id", room_id)
        }
        if (!TextUtils.isEmpty(to_user_id)){
            params.addBodyParameter("to_user_id", to_user_id)
        }
        ApiTool().postApi2(params, apiListener, "cp/info")
    }

    fun a76( page:Int,apiListener: ApiListener) {
        val params = RequestParams(AppConfig.Host_Url + "/app/api/cp/former/list")
        params.addBodyParameter("page", page.toString())
        params.addBodyParameter("page_size", "20")
        ApiTool().postApi2(params, apiListener, "former/list")
    }

    fun a77( merage_user_id:String,apiListener: ApiListener) {
        val params = RequestParams(AppConfig.Host_Url + "/app/api/cp/delete/former")
        if (!TextUtils.isEmpty(merage_user_id)){
            params.addBodyParameter("merage_user_id", merage_user_id)
        }
        ApiTool().postApi2(params, apiListener, "delete/former")
    }

    fun a78(from_user_code: String, type: String, apiListener: ApiListener) {
        val params = RequestParams(AppConfig.Host_Url + "/app/api/cp/feedback")
        params.addBodyParameter("from_user_code", from_user_code)
        params.addBodyParameter("type", type)
        ApiTool().postApi2(params, apiListener, "cp/feedback")
    }

    fun a79(room_id: String, cover: String, apiListener: ApiListener) {
        val params = RequestParams(AppConfig.Host_Url + "/app/api/cp/update/cover")
        params.addBodyParameter("room_id", room_id)
        params.addBodyParameter("cover", cover)
        ApiTool().postApi2(params, apiListener, "update/cover")
    }

    fun a80( page:Int,room_id:String,apiListener: ApiListener) {
        val params = RequestParams(AppConfig.Host_Url + "/app/api/gift/get/list/by/type")
        params.addBodyParameter("page", page.toString())
        params.addBodyParameter("page_size", "20")
        params.addBodyParameter("module", "room")
        params.addBodyParameter("related_id", room_id)
        ApiTool().postApi2(params, apiListener, "gift/list")
    }

    fun a81(gift_id: String, room_id: String, apiListener: ApiListener) {
        val params = RequestParams(AppConfig.Host_Url + "/app/api/gift/reward")
        params.addBodyParameter("gift_id", gift_id)
        params.addBodyParameter("related_id", room_id)
        params.addBodyParameter("module", "gift_room")
        ApiTool().postApi2(params, apiListener, "gift/reward")
    }

    fun a82( page:Int,room_id:String,apiListener: ApiListener) {
        val params = RequestParams(AppConfig.Host_Url + "/app/api/comment/lists")
        params.addBodyParameter("page", page.toString())
        params.addBodyParameter("page_size", "20")
        params.addBodyParameter("module", "room")
        params.addBodyParameter("parent_id", "0")
        params.addBodyParameter("svalue", room_id)
        ApiTool().postApi2(params, apiListener, "former/list")
    }

    fun a83(room_id: String, content: String, apiListener: ApiListener) {
        val params = RequestParams(AppConfig.Host_Url + "/app/api/comment/write")
        params.addBodyParameter("module", "room")
        params.addBodyParameter("svalue", room_id)
        params.addBodyParameter("content", content)
        params.addBodyParameter("parent_id", "0")
        ApiTool().postApi2(params, apiListener, "comment/write")
    }

   fun a84(room_id: String, apiListener: ApiListener) {
        val params = RequestParams(AppConfig.Host_Url + "/app/api/cp/broken")
        params.addBodyParameter("room_id", room_id)
        ApiTool().postApi2(params, apiListener, "cp/broken")
    }

    fun a85(frame_id: String, apiListener: ApiListener) {
        val params = RequestParams(AppConfig.Host_Url + "/app/api/frame/shop/order")
        params.addBodyParameter("frame_id", frame_id)
        ApiTool().postApi2(params, apiListener, "shop/order")
    }

    fun a86(frame_id: String,price_id:String, apiListener: ApiListener) {
        val params = RequestParams(AppConfig.Host_Url + "/app/api/frame/shop/purchase")
        params.addBodyParameter("frame_id", frame_id)
        params.addBodyParameter("price_id", price_id)
        ApiTool().postApi2(params, apiListener, "shop/purchase")
    }

    fun a87(frame_id: String,is_select:String, apiListener: ApiListener) {
        val params = RequestParams(AppConfig.Host_Url + "/app/api/frame/shop/select/frame")
        params.addBodyParameter("frame_id", frame_id)
        params.addBodyParameter("is_select", is_select)
        ApiTool().postApi2(params, apiListener, "select/frame")
    }

    fun a88(apiListener: ApiListener) {
        val params = RequestParams(AppConfig.Host_Url + "/app/api/user/package")
        ApiTool().postApi2(params, apiListener, "user/package")
    }

    fun a89(apiListener: ApiListener) {
        val params = RequestParams(AppConfig.Host_Url + "/app/api/creator/level/detail")
        ApiTool().postApi2(params, apiListener, "level/detail")
    }

    fun a90(gift_id:String,apiListener: ApiListener) {
        val params = RequestParams(AppConfig.Host_Url + "/app/api/gift/order")
        params.addBodyParameter("gift_id", gift_id)
        ApiTool().postApi2(params, apiListener, "gift/order")
    }

    fun a91(gift_id:String,price_id:String,apiListener: ApiListener) {
        val params = RequestParams(AppConfig.Host_Url + "/app/api/gift/purchase")
        params.addBodyParameter("gift_id", gift_id)
        params.addBodyParameter("price_id", price_id)
        ApiTool().postApi2(params, apiListener, "gift/purchase")
    }

    fun a92(guarantee:String,des_level:String,remark:String,apiListener: ApiListener) {
        val params = RequestParams(AppConfig.Host_Url + "/app/api/creator/pay/guarantee")
        params.addBodyParameter("guarantee", guarantee)
        params.addBodyParameter("des_level", des_level)
        params.addBodyParameter("remark", remark)
        ApiTool().postApi2(params, apiListener, "pay/guarantee")
    }

    fun a93(coins:String,to_user_id:String,apiListener: ApiListener) {
        val params = RequestParams(AppConfig.Host_Url + "/app/api/message/unlock/follow")
        params.addBodyParameter("coins", coins)
        params.addBodyParameter("to_user_id", to_user_id)
        ApiTool().postApi2(params, apiListener, "unlock/follow")
    }

    fun a94(match_id:String,to_user_code:String,apiListener: ApiListener) {
        val params = RequestParams(AppConfig.Host_Url + "/app/api/message/chat/like")
        params.addBodyParameter("match_id", match_id)
        params.addBodyParameter("to_user_code", to_user_code)
        ApiTool().postApi2(params, apiListener, "chat/like")
    }

    fun a95(gift_id: String, to_user_id:String,apiListener: ApiListener) {
        val params = RequestParams(AppConfig.Host_Url + "/app/api/gift/reward")
        params.addBodyParameter("gift_id", gift_id)
        params.addBodyParameter("module", "user")
        params.addBodyParameter("to_user_id", to_user_id)
        ApiTool().postApi2(params, apiListener, "gift/reward/cp")
    }

    fun a96(message_id: String, type:String,apiListener: ApiListener) {
        val params = RequestParams(AppConfig.Host_Url + "/app/api/gift/accept")
        params.addBodyParameter("message_id", message_id)
        params.addBodyParameter("type", type)
        ApiTool().postApi2(params, apiListener, "gift/accept/voice")
    }

    fun a97(message_id:String,to_user_id: String, is_satisfy:String,content:String,apiListener: ApiListener) {
        val params = RequestParams(AppConfig.Host_Url + "/app/api/gift/feedback")
        params.addBodyParameter("message_id", message_id)
        params.addBodyParameter("to_user_id", to_user_id)
        params.addBodyParameter("is_satisfy", is_satisfy)
        params.addBodyParameter("is_display", "0")
        params.addBodyParameter("content", content)
        ApiTool().postApi2(params, apiListener, "gift/feedback")
    }


}
package com.mail.myapplication.ui.mine.person.cp

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.mail.comm.image.ImageLoader
import com.mail.comm.net.AESCBCCrypt
import com.mail.comm.utils.JSONUtils
import com.mail.comm.view.load.XLoadTip
import com.mail.comm.view.refresh.XRefreshInterface
import com.mail.myapplication.BaseXAty
import com.mail.myapplication.R
import com.mail.myapplication.databinding.*
import com.mail.myapplication.interfaces.Home
import com.mail.myapplication.ui.mine.person.PersonOtherDetailsAty
import com.mail.myapplication.ui.utils.MyUtils3
import com.yhz.adaptivelayout.utils.AutoUtils

class PersonCpPreListAty : BaseXAty() {

    var home = Home()
    var page = 1
    var list = ArrayList<MutableMap<String, String>>()

    var index_check = -1
    lateinit var mBinding: AtyPersonCpPreListBinding
    lateinit var mAdapter2: GoldRecyclerAdapter2

    override fun getLayoutId(): Int = 0

    override fun initView() {
    }

    override fun requestData() {
        mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.loading)
        home.a76(page,this)
    }

    fun requestData2() {
        home.a76(page,this)
    }

    override fun getLayoutView(): View {
        mBinding = AtyPersonCpPreListBinding.inflate(layoutInflater);
        return mBinding.root
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        with(mBinding){
            initTopview2(include.relayTopBg, resources.getString(R.string.c_4))
            include.tvTitle.text = "前任"
            include.tvRight.text = "抹除記憶"
            include.tvRight.visibility = View.VISIBLE

            var mLayoutManager2 = GridLayoutManager(this@PersonCpPreListAty,1)
            mLayoutManager2.orientation = RecyclerView.VERTICAL
            recyclerview2.layoutManager =mLayoutManager2
            mAdapter2 = GoldRecyclerAdapter2()
            recyclerview2.adapter = mAdapter2

            swipeRefreshLayout.setEnableLoadmore(true)
            swipeRefreshLayout.setEnableRefresh(true)
            swipeRefreshLayout.setXRefreshAndLoadListen(object : XRefreshInterface {
                override fun refreshStart() {
                    page =1
                    requestData2()
                }

                override fun loadMoreStart() {
                    page++
                    requestData2()
                }

            })

            loading.setLoadingTipXReloadCallback(object: XLoadTip.LoadingTipXReloadCallback{
                override fun reload() {
                    requestData()
                }
            })

        }
    }

    fun mainClick(v: View) {

        when (v.id) {

            R.id.relay_back -> {
                finish()
            }

            R.id.tv_right ->{
                startProgressDialog()
                home.a77("",this)
            }

        }
    }

    override fun onComplete(var2: String?, type: String?) {
        super.onComplete(var2, type)

        if (type == "delete/former") {
            stopProgressDialog()
            var map = JSONUtils.parseKeyAndValueToMap(var2)
            if (map["code"] == "200") {
                requestData()
            }else{
                showToastS(map["message"])
            }
        }

        if (type== "former/list"){

            mBinding.swipeRefreshLayout.finishRefreshing()
            mBinding.swipeRefreshLayout.finishLoadmore()
            mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.finish)
            var map = JSONUtils.parseKeyAndValueToMap(var2)
            if(map["code"]=="200"){
                var str = AESCBCCrypt.aesDecrypt(map["data"])
                var mList = JSONUtils.parseKeyAndValueToMapList(str)
                if (page == 1){
                    list.clear()
                    list.addAll(mList)

                }else{
                    list.addAll(mList)
                }

                if (page==1&&mList.size==0){
                    mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.empty)
                }else{
                    if (mList!=null&&mList.size>0){
                        mAdapter2?.notifyDataSetChanged()
                    }
                }
            }else{
                if (page==1){
                    mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.error)
                }
            }
        }
    }

    override fun onExceptionType(type: String?) {
        super.onExceptionType(type)
        stopProgressDialog()
        if (type== "block/list"){
            mBinding.swipeRefreshLayout.finishRefreshing()
            mBinding.swipeRefreshLayout.finishLoadmore()
            if (page==1&&list.size==0){
                mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.error)
            }else{
                mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.finish)
            }
        }
    }

    inner class GoldRecyclerAdapter2 : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {

            return fGoldViewHolder(ItemPersonCpPreListBinding.inflate(LayoutInflater.from(this@PersonCpPreListAty)))

        }

        override fun getItemCount(): Int = list.size

        override fun getItemViewType(position: Int): Int {
            return position
        }

        override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {

            if (holder is fGoldViewHolder) {

                with(holder) {

                    var maxW = AutoUtils.getPercentWidthSizeBigger(400)
                    ImageLoader.loadImageAes(this@PersonCpPreListAty, list[position]["cp_user_avatar"], mBinding.ivHead,maxW,maxW)
                    mBinding.tvName.text = list[position]["cp_user_nick"]
                    mBinding.tvContent.text = "在一起${list[position]["love_days"]}天(分手時間${list[position]["end_at"].toString().substring(0,10)})"

                    mBinding.tvOk.setOnClickListener {
                        var bundle = Bundle()
                        bundle.putString("user_code",list[position]["cp_user_code"])
                        startActivity(PersonCpAty::class.java,bundle)
//                      var bundle = Bundle()
//                      bundle.putString("user_code",user_id)
//                      startActivity(PersonCpAty::class.java,bundle)
                    }
                }
            }

        }

        inner class fGoldViewHolder(binding: ItemPersonCpPreListBinding) : RecyclerView.ViewHolder(binding.root) {
            var mBinding: ItemPersonCpPreListBinding = binding

            init {
                AutoUtils.autoSize(binding.root)
            }
        }

    }




}
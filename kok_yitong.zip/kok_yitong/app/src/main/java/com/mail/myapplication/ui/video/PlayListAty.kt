package com.mail.myapplication.ui.video

import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import androidx.viewpager2.widget.ViewPager2
import com.mail.comm.utils.JSONUtils
import com.mail.comm.view.refresh.XRefreshInterface
import com.mail.myapplication.BaseXAty
import com.mail.myapplication.R
import com.mail.myapplication.databinding.AtyPlayListBinding
import com.mail.myapplication.ui.video.PlayListAdataper

class PlayListAty : BaseXAty() {

    lateinit var mBinding: AtyPlayListBinding

    var index = 0

    var list = ArrayList<MutableMap<String, String>>()

    override fun getLayoutId(): Int = 0

    override fun initView() {

        var data = intent.getStringExtra("data")
        var map = JSONUtils.parseKeyAndValueToMap(data)
        list = JSONUtils.parseKeyAndValueToMapList(map!!["img_data"])

        for (index in list.indices){
            if (list[index].containsKey("is_voice")&&list[index]["is_voice"]=="1"){
                list.removeAt(index)
                break
            }
        }

        if (intent.hasExtra("index")){
            index = intent.getStringExtra("index")!!.toInt()
        }

    }

    override fun requestData() {}

    override fun getLayoutView(): View {
        mBinding = AtyPlayListBinding.inflate(layoutInflater);
        return mBinding.root
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON, WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setTranslanteBar()
        window.navigationBarColor = Color.parseColor("#dd000000")

        initTopview2(mBinding.include.relayTopBg)

        with(mBinding) {
            viewPager.adapter = PlayListAdataper(supportFragmentManager, this@PlayListAty.lifecycle, list)
            viewPager.setCurrentItem(index,false)
            include.tvTitle.text = "${index+1}/${list.size}"
            viewPager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
                override fun onPageSelected(position: Int) {
                    include.tvTitle.text = "${position+1}/${list.size}"
                }
            })
        }
    }

    fun mainClick(v: View) {
        when (v.id) {
            R.id.relay_back -> {
                finshPage("3")
            }
        }
    }

    override fun onBackPressed() {
//        super.onBackPressed()
        finshPage("3")

    }

}
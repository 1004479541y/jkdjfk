package com.mail.myapplication.ui.mine.set

import android.os.Bundle
import android.text.TextUtils
import android.view.View
import android.widget.Toast
import com.mail.comm.app.AppManager
import com.mail.comm.app.BaseApp
import com.mail.comm.utils.JSONUtils
import com.mail.comm.utils.MyUtils2
import com.mail.comm.utils.PreferencesUtils
import com.mail.comm.utils.ToastUitl
import com.mail.myapplication.BaseXAty
import com.mail.myapplication.R
import com.mail.myapplication.databinding.AtySetBinding
import com.mail.myapplication.interfaces.Home
import com.mail.myapplication.interfaces.Lar
import com.mail.myapplication.ui.dg.ClearCacheDgFrg
import com.mail.myapplication.ui.dg.QuitLoginDgFrg
import com.mail.myapplication.ui.dg.UpdateDialog
import com.mail.myapplication.ui.lar.LarAty
import com.mail.myapplication.ui.mine.BlackListAty
import com.mail.myapplication.ui.mine.pattern.PatternSetAty
import com.mail.myapplication.ui.mine.pattern.PatternSwichAty

class SetAty:BaseXAty() {

    lateinit var mBinding: AtySetBinding
    var home = Home()
    var lar = Lar()
    var updateDialog: UpdateDialog?=null
    var pass = ""

    override fun getLayoutId(): Int = 0

    override fun initView() {
        pass =PreferencesUtils.getString(this,"pattern_pass")
    }

    override fun requestData() {
    }

    override fun getLayoutView(): View {
        mBinding = AtySetBinding.inflate(layoutInflater);
        return mBinding.root
    }

//  var array = arrayOf("微信","wx","Wx","WX","wX","QQ","qq","Qq","qQ","扣扣")
    var array = arrayOf("qq")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        with(mBinding){
            initTopview2(include.relayTopBg, resources.getString(R.string.c_4))
            include.tvTitle.text = "設置"
            var v_code = MyUtils2.getAppVersionCode()
            var v_name = MyUtils2.getAppVersionName()
            mBinding.tvCode.text = "v${v_name}/${v_code}"

            if (TextUtils.isEmpty(pass)||pass=="null"){
                tvPattern.text = "未设置"
            }else{
                tvPattern.text = "修改"
            }

           var  isVibrate =BaseApp.instance?.getOneMapData("isVibrate")
//            VirateUtil.vibrate(longArrayOf(1000, 1000, 1000, 1000), -1)
            switch3.isChecked = TextUtils.isEmpty(isVibrate) || isVibrate == "1"
        }

    }

    override fun onDestroy() {
        super.onDestroy()
        var isVibrate ="0"
        if (mBinding.switch3.isChecked){
            isVibrate ="1"
        }
        BaseApp.instance?.saveOneMapData("isVibrate",isVibrate)
    }

    fun clearFinish(){
        ToastUitl.showToast("清除緩存成功",Toast.LENGTH_SHORT)
    }

    fun quitFinish(){
        startProgressDialog()
        lar.b17(this)
    }

    fun mainClick(v: View) {

        when (v.id) {

            R.id.relay_back -> {
                finish()
            }

            R.id.relay_black -> {
                startActivity(BlackListAty::class.java)
            }

            R.id.relay_clear -> {
                var dg = ClearCacheDgFrg()
                dg.show(supportFragmentManager,"ClearCacheDgFrg")
            }

            R.id.relay_quit -> {
                var dg = QuitLoginDgFrg()
                dg.show(supportFragmentManager,"QuitLoginDgFrg")
            }

            R.id.relay_private -> {
                startActivity(PrivateSetAty::class.java)
            }

            R.id.relay_update ->{
                startProgressDialog()
                home.a42(this)
            }

            R.id.relay_ss -> {
                if (TextUtils.isEmpty(pass)||pass=="null"){
                    startActivity(PatternSetAty::class.java)
                }else{
                    startActivity(PatternSwichAty::class.java)
                }
            }
        }
    }

    override fun onComplete(var2: String?, type: String?) {
        super.onComplete(var2, type)
        stopProgressDialog()

        if (type == "login/out"){
            AppManager.getInstance().killAllActivity()
            startActivity(LarAty::class.java)
            setPattern(false)
        }

        if (type == "version/update"){
            var map = JSONUtils.parseKeyAndValueToMap(var2)
            if (map["code"]=="200"){
                var map = JSONUtils.parseKeyAndValueToMap(map["data"])
                if (updateDialog == null){
                    updateDialog = UpdateDialog(this)
                }
                updateDialog?.show()
                updateDialog?.setData(map["remark"]!!,map["force"]!!,map["package_path"]!!)
            }else{
                showToastS(map["message"])
            }
        }


    }

    override fun onExceptionType(type: String?) {
        super.onExceptionType(type)
         stopProgressDialog()

    }

}
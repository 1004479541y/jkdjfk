//package com.mail.myapplication.ui.download
//
//import android.content.Intent
//import android.os.Bundle
//import android.text.TextUtils
//import android.util.Log
//import android.view.View
//import android.view.ViewGroup
//import android.widget.ImageView
//import androidx.recyclerview.widget.RecyclerView.OnChildAttachStateChangeListener
//import cn.jzvd.JZDataSource
//import cn.jzvd.Jzvd
//import com.blankj.utilcode.util.ToastUtils
//import com.by.net.JSONUtils
//import com.bytedance.tiktok.utils.OnVideoControllerListener
//import com.echofeng.common.config.AppConfig
//import com.echofeng.common.inter.CustomCallback
//import com.echofeng.common.ui.widget.view.LikeView
//import com.echofeng.common.ui.widget.view.jzplayer.JzvdStdTikTok
//import com.echofeng.common.ui.widget.view.viewpagerlayoutmanager.OnViewPagerListener
//import com.echofeng.common.ui.widget.view.viewpagerlayoutmanager.ViewPagerLayoutManager
//import com.echofeng.common.utils.AESCBCCrypt
//import com.lianzhihui.minitiktok.adapter.MainVideoAdapter
//import com.lianzhihui.minitiktok.base.BaseFrg
//import com.lianzhihui.minitiktok.base.ImageLoader.Companion.loadImageAes
//import com.lianzhihui.minitiktok.base.XLoadTip
//import com.lianzhihui.minitiktok.bean.hot.AlbumVideoResponse
//import com.lianzhihui.minitiktok.bean.hot.HotClassResponse
//import com.lianzhihui.minitiktok.bean.hot.VideoResponse
//import com.lianzhihui.minitiktok.interfaces.Home
//import com.lianzhihui.minitiktok.presenter.HomePresnterImp
//import com.lianzhihui.minitiktok.ui.MainActivity
//import com.lianzhihui.minitiktok.ui.download.DownVideoUtils
//import com.lianzhihui.minitiktok.ui.main.HomeOneFragment
//import com.lianzhihui.minitiktok.ui.main.comment.CommentAty
//import com.lianzhihui.minitiktok.ui.main.four.GoldRechargeAty
//import com.lianzhihui.minitiktok.ui.main.four.VipRechargeAty
//import com.lianzhihui.minitiktok.view.HomeView
//import com.lianzhihui.minitiktok.widget.dialog.*
//import com.lianzhihui.minitiktok.widget.view.ControllerView
//import com.lianzhihui.onlyleague.R
//import com.scwang.smartrefresh.layout.api.RefreshLayout
//import com.scwang.smartrefresh.layout.listener.OnRefreshLoadMoreListener
//import kotlinx.android.synthetic.main.fragment_video_page.*
//import kotlinx.android.synthetic.main.view_controller.view.*
//import org.jzvd.jzvideo.JZMediaIjk
//import org.xutils.common.util.LogUtil
//import org.xutils.http.RequestParams
//
//
//class VideoPageFragment : BaseFrg(),HomeView,OnViewPagerListener,OnRefreshLoadMoreListener{
//
//    /** 将要播放视频位置  */
//    private var mCheckPosition: Int = 0
//    private val initPos: Int = 0
//    private var player: JzvdStdTikTok? = null
//    private lateinit var homePresnterImp: HomePresnterImp
//    private var adapter: MainVideoAdapter? = null
//    private var checkVideoDialog: CustomConfirmDialog? = null
//    private var viewPagerLayoutManager: ViewPagerLayoutManager? = null
//    var data:VideoResponse?=null
//    var pageNum =1
//    var home = Home()
//    var mDownVideoUtils: DownVideoUtils?=null
//
//    override fun getLayoutId(): Int =  R.layout.fragment_video_page
//
//    override fun initView() {
//        homePresnterImp = HomePresnterImp(context, this)
//
//        mSmartRefreshLayout!!.setOnRefreshLoadMoreListener(this)
//        adapter = MainVideoAdapter(ArrayList())
//        viewPagerLayoutManager = ViewPagerLayoutManager(activity)
//        recyclerView!!.setAdapter(adapter)
//        recyclerView!!.setLayoutManager(viewPagerLayoutManager)
//        recyclerView!!.scrollToPosition(initPos)
//        viewPagerLayoutManager!!.setOnViewPagerListener(this)
//        recyclerView.addOnChildAttachStateChangeListener(object : OnChildAttachStateChangeListener {
//            override fun onChildViewAttachedToWindow(view: View) {}
//            override fun onChildViewDetachedFromWindow(view: View) {
//                val jzvd: Jzvd = view.findViewById(R.id.videoPlayer)
//                if (jzvd != null && Jzvd.CURRENT_JZVD != null && jzvd.jzDataSource != null &&
//                        jzvd.jzDataSource.containsTheUrl(Jzvd.CURRENT_JZVD.jzDataSource.currentUrl)) {
//                    if (Jzvd.CURRENT_JZVD != null && Jzvd.CURRENT_JZVD.screen != Jzvd.SCREEN_FULLSCREEN) {
//                        Jzvd.releaseAllVideos()
//                    }
//                }
//            }
//        })
//    }
//
//    override fun onPause() {
//        super.onPause()
//        try {
//            stopProgressDialog()
//            Jzvd.releaseAllVideos()
//        } catch (e: Exception) {
//        }
//    }
//
//
//    override fun onComplete(var1: RequestParams?, var2: String?, type: String?) {
//        super.onComplete(var1, var2, type)
//
//        if (type =="video/like"){
//            stopProgressDialog()
//
//            var map = JSONUtils.parseKeyAndValueToMap(var2)
//            if (map["code"] == "200") {
//                var str = AESCBCCrypt.aesDecrypt(map["data"])
//                var mapT = JSONUtils.parseKeyAndValueToMap(str)
//
//                val itemView = viewPagerLayoutManager!!.findViewByPosition(mCheckPosition) ?: return
//                val rootView = itemView.findViewById<ViewGroup>(R.id.rl_container)
//                val controllerView: ControllerView = rootView.findViewById(R.id.mControllerView)
//                controllerView.like()
//                if (mapT["status"]=="1"){
//                    controllerView.like("1")
//                }else{
//                    controllerView.like("0")
//                }
//
//            }else{
//                ToastUtils.showShort(map["message"])
//            }
//        }
//    }
//
//    override fun onExceptionType(var1: Throwable?, params: RequestParams?, type: String?) {
//        super.onExceptionType(var1, params, type)
//        stopProgressDialog()
//    }
//
//
//    override fun onResume() {
//        super.onResume()
//        LogUtil.e("onResume=="+"VideoPageFragment onResume")
//        var f1 = getActivity()?.supportFragmentManager?.findFragmentByTag(HomeOneFragment::class.java.toString())
//        var mainAty =getActivity() as MainActivity
//
//        if (mainAty.getCurrentPage()!=0){
//            return
//        }
//
//        if (f1 is HomeOneFragment){
//            LogUtil.e("onResume=="+"VideoPageFragment onResume ||"+f1.getCurrentPage())
//            if (f1.getCurrentPage()==0){
//                LogUtil.e("onResume=="+"VideoPageFragment onResume 0")
//                try {
//                    if (player!=null&& adapter?.getItem(mCheckPosition)?.isCanPlay == true) {
//                        player!!.state = Jzvd.STATE_PLAYING
//                        player!!.startVideoAfterPreloading()
//                        player!!.updateStartImage()
//                    }
//                }catch (e:Exception){
//
//                }
//            }
//        }
//    }
//
//    override fun onInitComplete() {
//        //自动播放第一条
//        var videoData = adapter?.getItem(0)
//        if (videoData != null) {
//            autoPlayVideo(0,videoData.is_ad)
//        }
//        homePresnterImp.doVideoCheck(videoData?.id)
//    }
//
//    override fun onPageRelease(isNext: Boolean, position: Int) {
//        if (0 == position) {
//            Jzvd.releaseAllVideos()
//        }
//    }
//
//    override fun onPageSelected(position: Int, isBottom: Boolean) {
//        checkVideoDialog?.dismiss()
//        mCheckPosition = position
//        var data = adapter?.getItem(mCheckPosition)
//        if (data?.is_ad==0) {
////            if (!AppConfig.debug){
////                startProgressDialog()
////            }
//            this.data = null
//            homePresnterImp.doVideoCheck(adapter?.getItem(mCheckPosition)?.id)
//        }
//        if (data != null) {
//            autoPlayVideo(mCheckPosition, data.is_ad)
//        }
//    }
//
//    private fun autoPlayVideo(position: Int,isAd:Int) {
//        if (recyclerView == null || recyclerView.getChildAt(0) == null) {
//            return
//        }
//        val itemView = viewPagerLayoutManager!!.findViewByPosition(position) ?: return
//        val rootView = itemView.findViewById<ViewGroup>(R.id.rl_container)
//        val likeView: LikeView = rootView.findViewById(R.id.mLikeView)
//        val controllerView: ControllerView = rootView.findViewById(R.id.mControllerView)
//        player = recyclerView.getChildAt(0).findViewById(R.id.videoPlayer)
//        if (isAd==1){
//            if (player != null) {
//                player!!.startVideoAfterPreloading()
//            }
//        }
//
//        var currentVideo = adapter?.getItem(mCheckPosition)
//        if (currentVideo?.isCanPlay == true){
//            likeView.visibility = View.GONE
//        }else{
//            likeView.visibility = View.VISIBLE
//        }
//
//        //播放暂停事件
//        likeView.setOnPlayPauseListener(object : LikeView.OnPlayPauseListener {
//            override fun onPlayOrPause() {
//
//                if (player==null){
//                    player = recyclerView.getChildAt(0).findViewById(R.id.videoPlayer)
//                }
//
//                if (player!!.state == Jzvd.STATE_PLAYING) {
//                    try {
//                        player!!.state = Jzvd.STATE_PAUSE
//                        player!!.mediaInterface.pause()
//                        player!!.updateStartImage()
////                        Jzvd.goOnPlayOnPause()
//                    }catch (e:Exception){
//
//                        var data = adapter?.getItem(mCheckPosition)
//                        if (data != null) {
//                            autoPlayVideo(mCheckPosition, data.is_ad)
//                        }
//                    }
//
//                } else {
//                    var currentVideo = adapter?.getItem(mCheckPosition)
//                    if (currentVideo?.isCanPlay == true){
//
//                        try{
//                            player!!.state = Jzvd.STATE_PLAYING
//                            player!!.mediaInterface.start()
////                          Jzvd.goOnPlayOnPause()
//
//                            player!!.updateStartImage()
//                        }catch (e:Exception){
//                            var data = adapter?.getItem(mCheckPosition)
//                            if (data != null) {
//                                autoPlayVideo(mCheckPosition, data.is_ad)
//                            }
//                        }
//
//                    }else{
//
//                        if (currentVideo?.is_ad==0) {
//                            homePresnterImp.doVideoCheck(adapter?.getItem(mCheckPosition)?.id)
//                        }else{
//
//                            try {
//                                player!!.state = Jzvd.STATE_PLAYING
//                                player!!.mediaInterface.start()
////                            Jzvd.goOnPlayOnResume()
//                                player!!.updateStartImage()
//                            }catch (e:Exception){
//                                var data = adapter?.getItem(mCheckPosition)
//                                if (data != null) {
//                                    autoPlayVideo(mCheckPosition, data.is_ad)
//                                }
//                            }
//                        }
//                    }
//                }
//            }
//        })
//        //评论点赞事件
//        likeShareEvent(controllerView)
//    }
//    /**
//     * 用户操作事件
//     */
//    private fun likeShareEvent(controllerView: ControllerView) {
//        controllerView.setListener(object : OnVideoControllerListener {
//            override fun onHeadClick() {
//                var videoData = controllerView.getVideoData()
//                var intent = Intent(context, UserCenterActivity::class.java)
//                intent.putExtra("userId", videoData!!.user.code)
//                startActivity(intent)
//            }
//
//            override fun onLikeClick() {
//                var videoData = controllerView.getVideoData()
//                startProgressDialog()
//                home.a43(videoData!!.id,this@VideoPageFragment)
//            }
//            override fun onCommentClick() {
//                var intent = Intent(activity, CommentAty::class.java)
//                intent.putExtra("svalue",controllerView.getVideoData()?.id)
//                startActivity(intent)
////                CommentDialog(context!!).show()
//            }
//
//            override fun onShareClick() {
//                var videoData = controllerView.getVideoData()
//                var shareVideoDialog = ShareVideoDialog(context!!)
//                shareVideoDialog.show()
//                shareVideoDialog.setVideoData(videoData!!)
//            }
//
//            override fun onBoxClick() {
//                var videoData = controllerView.getVideoData()
//                var videoBoxDialog = VideoBoxDialog(context!!)
//                videoBoxDialog.show()
//                videoBoxDialog.setId(videoData!!.album_id)
//            }
//
//            override fun onFocusClick() {
//                var videoData = controllerView.getVideoData()
//                homePresnterImp.doAttintion(videoData!!.user.code);
//            }
//
//            override fun onFullVideoClick() {
//                var videoList = ArrayList<VideoResponse>()
//                var videoData = adapter?.getItem(mCheckPosition)
//                videoList.add(videoData!!)
////                var fullUrl = videoData?.mu
////
////                if (!TextUtils.isEmpty(fullUrl)){
////                    var intent = Intent(context, PlayListActivity::class.java)
////                    intent.putExtra("currentPosition",0)
////                    intent.putExtra("videoList",videoList)
////                    intent.putExtra("isShowFullVideo",false)
////                    intent.putExtra("isShowHeJiBtn",false)
////                    context?.startActivity(intent)
////                }else{
////
////                    if (AppConfig.debug){
////                        var intent = Intent(context, PlayListActivity::class.java)
////                        intent.putExtra("currentPosition",0)
////                        intent.putExtra("videoList",videoList)
////                        intent.putExtra("isShowFullVideo",false)
////                        intent.putExtra("isShowHeJiBtn",false)
////                        context?.startActivity(intent)
////                        return
////                    }
////                    dialogNeedVip();
////                }
//                if (AppConfig.debug) {
//                    var intent = Intent(context, PlayListActivity::class.java)
//                    intent.putExtra("currentPosition", 0)
//                    intent.putExtra("videoList", videoList)
//                    intent.putExtra("isShowFullVideo", false)
//                    intent.putExtra("isShowHeJiBtn", false)
//                    context?.startActivity(intent)
//                    return
//                }
//                if (data==null){
////                    showLoading("")
//                    startProgressDialog()
//                    homePresnterImp.doVideoCheck(adapter?.getItem(mCheckPosition)?.id)
//                    return
//                }
//                if (data?.auth_error==null){
//                    var intent = Intent(context, PlayListActivity::class.java)
//                    intent.putExtra("currentPosition",0)
//                    intent.putExtra("videoList",videoList)
//                    intent.putExtra("isShowFullVideo",false)
//                    intent.putExtra("isShowHeJiBtn",false)
//                    startActivity(intent)
//                }else{
//                    when(data?.auth_error?.key){
//                        1001->{
//                            checkVideoDialog = activity?.let { CustomConfirmDialog(it,object : CustomCallback {
//                                override fun onCompare(o: Any?) {
//                                    checkVideoDialog?.dismiss()
//                                    startActivity(Intent(activity, VipRechargeAty::class.java))
//                                }
//
//                                override fun onCancel() {
//                                    var shareVideoDialog = ShareVideoDialog(activity!!)
//                                    shareVideoDialog.show()
//                                    shareVideoDialog.setVideoData(data!!)
//                                }
//                            }) }
//                            checkVideoDialog?.setText(getStrings(R.string.home_10),data?.auth_error?.info,getStrings(R.string.home_8),getStrings(R.string.home_9))
//                            checkVideoDialog?.show()
//                        }
//                        1002->{
//                            checkVideoDialog = activity?.let { CustomConfirmDialog(it,object : CustomCallback {
//                                override fun onCompare(o: Any?) {
//                                    checkVideoDialog?.dismiss()
//                                    startActivity(Intent(activity, GoldRechargeAty::class.java))
//                                }
//
//                                override fun onCancel() {
//                                    checkVideoDialog?.dismiss()
////                                    showLoading()
//                                    startProgressDialog()
//                                    homePresnterImp.doBuyVideo(data?.id)
//                                }
//                            }) }
//                            checkVideoDialog?.setText(getStrings(R.string.home_10),data?.auth_error?.info,getStrings(R.string.home_11),getStrings(R.string.home_12))
//                            checkVideoDialog?.show()
//                        }
//                        1003->{
////                            var customTip = context?.let { CustomTipDialog(it) }
////                            customTip?.setText(getStrings(R.string.home_10),data?.auth_error?.info,getStrings(R.string.home_13))
////                            customTip?.show()
//                        }
//                    }
//
//                }
//            }
//        })
//    }
//
//
//    override fun setSuccess(o: Any?) {}
//
//    override fun setFailure(o: Any?) {
////      dismissLoading()
//        stopProgressDialog()
//        if (mSmartRefreshLayout!=null) {
//            mSmartRefreshLayout.finishRefresh()
//            mSmartRefreshLayout.finishLoadMore()
//        }
//    }
//
//    override fun setVideoRecommendSuccess(data: MutableList<VideoResponse>?) {
//        loading.setLoadingTip(XLoadTip.LoadStatus.finish)
//        mSmartRefreshLayout.finishRefresh()
//        mSmartRefreshLayout.finishLoadMore()
//        if (pageNum==1) {
//            if (data==null||data.size==0){
//                loading.setLoadingTip(XLoadTip.LoadStatus.error)
//            }else{
//                adapter!!.setNewData(data)
//            }
//
//        }else{
//            adapter!!.addData(data as ArrayList)
//            if (data.size==0){
//                pageNum-=1
//            }
//        }
//    }
//
//    override fun setVideoRecommendFaile() {
//        if (pageNum==1){
//            loading.setLoadingTip(XLoadTip.LoadStatus.error)
//        }else{
//            loading.setLoadingTip(XLoadTip.LoadStatus.finish)
//        }
//    }
//
//    override fun setSearchVideoSuccess(data: MutableList<VideoResponse>?) {
//    }
//
//    override fun setSearchVideoFaile() {
//
//    }
//
//    override fun setBoxVideoSuccess(data: AlbumVideoResponse?) {
//    }
//
//    override fun setHotClassSuccess(data: MutableList<HotClassResponse>?) {
//    }
//
//
//    fun downM3u8(url:String){
//        ToastUtils.showShort("下载视频")
//        startProgressDialog()
//        mDownVideoUtils?.setData(url)
//        Log.e("downM3u8  url==",url.toString())
//
//        mDownVideoUtils?.setDownVideoUtilsListen(object : DownVideoUtils.DownVideoUtilsListen{
//            override fun downLoading() {
//            }
//
//            override fun downSucess(path: String?) {
//                ToastUtils.showShort("下载ok")
//
//                Log.e("downM3u8==",path.toString())
//                stopProgressDialog()
//                val itemView = viewPagerLayoutManager!!.findViewByPosition(mCheckPosition) ?: return
//                val rootView = itemView.findViewById<ViewGroup>(R.id.rl_container)
//                val mVideoPlayer = itemView.findViewById<JzvdStdTikTok>(R.id.videoPlayer)
//                val likeView: LikeView = rootView.findViewById(R.id.mLikeView)
//                adapter?.getItem(mCheckPosition)?.smu = path
//                adapter?.getItem(mCheckPosition)?.isCanPlay = true
//
////                var jzDataSource = JZDataSource("file:/"+path, "dddddd")
//                var jzDataSource = JZDataSource(path, "dddddd")
//                jzDataSource.looping = true
////                mVideoPlayer.setUp(jzDataSource, Jzvd.SCREEN_NORMAL)
//                //        mVideoPlayer.setUp(jzDataSource, Jzvd.SCREEN_NORMAL, JZMediaExo.class);
//                mVideoPlayer.setUp(jzDataSource, Jzvd.SCREEN_NORMAL, JZMediaIjk::class.java)
//
//                mVideoPlayer.startPreloading() //开始预加载，加载完等待播放
//                likeView.visibility = View.GONE
//
//                if (player != null) {
//                    player!!.startVideoAfterPreloading()
//                }
//
//            }
//
//            override fun downFailed() {
//                stopProgressDialog()
//                ToastUtils.showShort("下载失败")
//
//            }
//
//        })
//        mDownVideoUtils?.download()
//    }
//
//    override fun setCheckVideoSuccess(data: VideoResponse?) {
//        this.data =data
//        stopProgressDialog()
////        dismissLoading()
////        1001=次数已用完，开通VIP享不限次观,
////        1002=金币视频查看完整版需支付金币,
////        1003=粉丝视频仅限粉丝观看
//        val itemView = viewPagerLayoutManager!!.findViewByPosition(mCheckPosition) ?: return
//        val rootView = itemView.findViewById<ViewGroup>(R.id.rl_container)
//        val likeView: LikeView = rootView.findViewById(R.id.mLikeView)
//        val controllerView: ControllerView = rootView.findViewById(R.id.mControllerView)
//        controllerView.setCommentNum(data?.comment.toString())
//
////        if(AppConfig.debug){
////            adapter?.getItem(mCheckPosition)?.mu = data?.mu
////            adapter?.getItem(mCheckPosition)?.isCanPlay = true
////            if (player != null) {
////                player!!.startVideoAfterPreloading()
////            }
////            likeView.visibility = View.GONE
////            return
////        }
//
//        if (data?.auth_error==null) {
//            downM3u8( data?.mu!!)
////            adapter?.getItem(mCheckPosition)?.mu = data?.mu
////            adapter?.getItem(mCheckPosition)?.isCanPlay = true
////            likeView.visibility = View.GONE
////            if (player != null) {
////                player!!.startVideoAfterPreloading()
////            }
//        }else{
//            adapter?.getItem(mCheckPosition)?.isCanPlay = false
//            likeView.visibility = View.VISIBLE
//            when(data.auth_error.key){
//                1001->{
//                    checkVideoDialog = context?.let { CustomConfirmDialog(it,object : CustomCallback{
//                        override fun onCompare(o: Any?) {
//                            checkVideoDialog?.dismiss()
//                            startActivity(Intent(context,VipRechargeAty::class.java))
//                        }
//
//                        override fun onCancel() {
//                            var shareVideoDialog = ShareVideoDialog(context!!)
//                            shareVideoDialog.show()
//                            shareVideoDialog.setVideoData(data!!)
//                        }
//                    }) }
//                    checkVideoDialog?.setText("",data.auth_error.info,getStrings(R.string.home_8),getStrings(R.string.home_9))
//                    checkVideoDialog?.show()
//                }
//                1002->{
//                    checkVideoDialog = context?.let { CustomConfirmDialog(it,object : CustomCallback{
//                        override fun onCompare(o: Any?) {
//                            checkVideoDialog?.dismiss()
//                            startActivity(Intent(context,GoldRechargeAty::class.java))
//                        }
//
//                        override fun onCancel() {
//                            checkVideoDialog?.dismiss()
////                            showLoading()
//                            startProgressDialog()
//                            homePresnterImp.doBuyVideo(data.id)
//                        }
//                    }) }
//                    checkVideoDialog?.setText("",data.auth_error.info,getStrings(R.string.home_11),getStrings(R.string.home_12))
//                    checkVideoDialog?.show()
//                }
//                1003->{
////                    var customTip = context?.let { CustomTipDialog(it) }
////                    customTip?.setText("",data.auth_error.info,getStrings(R.string.home_13))
////                    customTip?.show()
//                }
//            }
//        }
//    }
//
//    override fun setBuyVideoSuccess(data: Any?) {
////        dismissLoading()
//        stopProgressDialog()
//        checkVideoDialog?.dismiss()
//        checkVideoDialog==null
//        if (player != null) {
//            player!!.startVideoAfterPreloading()
//        }
//    }
//
//    override fun onRefresh(refreshLayout: RefreshLayout) {
//        pageNum=1
//        homePresnterImp.getFollowVideo(pageNum)
//    }
//
//    override fun onLoadMore(refreshLayout: RefreshLayout) {
//        pageNum+=1
//        homePresnterImp.getFollowVideo(pageNum)
//    }
//
//    override fun onActivityCreated(savedInstanceState: Bundle?) {
//        super.onActivityCreated(savedInstanceState)
//
//        mDownVideoUtils = DownVideoUtils(activity)
//        mDownVideoUtils?.onCreate()
//
//        requestData()
//
//        loading.setLoadingTipXReloadCallback(object : XLoadTip.LoadingTipXReloadCallback{
//            override fun reload() {
//                requestData()
//            }
//        })
//    }
//
//    override fun requestData(){
//        pageNum=1
//        loading.setLoadingTip(XLoadTip.LoadStatus.loading)
//        homePresnterImp.getFollowVideo(pageNum)
//    }
//
//}

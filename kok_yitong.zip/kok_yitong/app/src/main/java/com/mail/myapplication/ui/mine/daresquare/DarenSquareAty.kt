package com.mail.myapplication.ui.mine.daresquare

import android.os.Bundle
import android.text.TextUtils
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.mail.comm.image.ImageLoader
import com.mail.comm.net.AESCBCCrypt
import com.mail.comm.utils.JSONUtils
import com.mail.comm.view.refresh.XRefreshInterface
import com.mail.myapplication.BaseXAty
import com.mail.myapplication.R
import com.mail.myapplication.databinding.*
import com.mail.myapplication.interfaces.Lar
import com.mail.myapplication.ui.mine.person.PersonDetailsAty
import com.mail.myapplication.ui.mine.apply.AuthAty
import com.mail.myapplication.ui.msg.CommentListAty
import com.mail.myapplication.ui.msg.FansAty
import com.mail.myapplication.ui.utils.MyUtils3
import com.mail.myapplication.ui.wallet.IncomeAty
import com.yhz.adaptivelayout.config.AutoLayoutConifg
import com.yhz.adaptivelayout.utils.AutoUtils
import com.youth.banner.indicator.CircleIndicator

class DarenSquareAty : BaseXAty() {

    lateinit var mBinding: AtyDarenSquareBinding
    var mAdapter: GoldRecyclerAdapter? = null
    var creator_status =""
    var lar = Lar()
    var list = ArrayList<MutableMap<String,String>>()

    override fun getLayoutId(): Int = 0

    override fun getLayoutView(): View {
        mBinding = AtyDarenSquareBinding.inflate(layoutInflater);
        return mBinding.root
    }

    override fun initView() {
        creator_status = intent.getStringExtra("creator_status").toString()
    }

    override fun requestData() {
        lar?.b31(this)
        lar?.b33(this)
        lar?.b35(this)
    }

    override fun onComplete(var2: String?, type: String?) {
        super.onComplete(var2, type)
        if (type=="creator/home"){
            mBinding.swipeRefreshLayout.finishLoadmore()
            mBinding.swipeRefreshLayout.finishRefreshing()
            stopProgressDialog()
            var map = JSONUtils.parseKeyAndValueToMap(var2)
            if(map["code"]=="200"){
                var str = AESCBCCrypt.aesDecrypt(map["data"])
                var map = JSONUtils.parseKeyAndValueToMap(str)
                mBinding.tvCommentTotal.text = map["comment_total"]
                mBinding.tvFansTotal.text = map["fans_total"]
                mBinding.tvLikeTotal.text = map["like_total"]
                mBinding.tvPlayTotal.text = map["play_total"]
                mBinding.tvViewTotal.text = map["view_total"]
                mBinding.tvGiftNum.text = map["gift_total"]

            }else{
                showToastS(map["message"])
            }
        }

        if (type=="ad/list"){
            var map = JSONUtils.parseKeyAndValueToMap(var2)
            if(map["code"]=="200"){
                var str = AESCBCCrypt.aesDecrypt(map["data"])
                var list = JSONUtils.parseKeyAndValueToMapList(str)
                var adapterImg = DarenSquareBannerAdapter(list,this)
                mBinding.banner1.setAdapter(adapterImg)
            }
        }

        if (type=="ad/list/h5_ad"){
            var map = JSONUtils.parseKeyAndValueToMap(var2)
            if(map["code"]=="200"){
                var str = AESCBCCrypt.aesDecrypt(map["data"])
                list = JSONUtils.parseKeyAndValueToMapList(str)
                mAdapter?.notifyDataSetChanged()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        initTopview2(mBinding.include.relayTopBg, resources.getString(R.string.c_4))

        mBinding.include.tvTitle.text = "達人廣場"

        var mLayoutManager2 = GridLayoutManager(this, 1)
        mLayoutManager2.orientation = RecyclerView.VERTICAL
        mBinding.recyclerview.layoutManager = mLayoutManager2
        mAdapter = GoldRecyclerAdapter()
        mBinding.recyclerview.adapter = mAdapter


        with(mBinding){

            var circleIndicator = CircleIndicator(this@DarenSquareAty)
            banner1.indicator = circleIndicator
            banner1.addBannerLifecycleObserver(this@DarenSquareAty)
            banner1.isAutoLoop(true)

            swipeRefreshLayout.setEnableLoadmore(false)
            swipeRefreshLayout.setEnableRefresh(true)
            swipeRefreshLayout.setIsPinContentView(true)

            swipeRefreshLayout.setXRefreshAndLoadListen(object : XRefreshInterface {
                override fun refreshStart() {
                    requestData()
                }

                override fun loadMoreStart() {
                }

            })

        }
    }

    fun mainClick(v: View) {

        when (v.id) {

            R.id.relay_back -> {
                finish()
            }

            R.id.linlay_auth,R.id.relay_guanfang -> {
                var bundle = Bundle()
                bundle.putString("creator_status", creator_status)
                startActivity(AuthAty::class.java,bundle)
            }

            R.id.linlay_income -> {
                startActivity(IncomeAty::class.java)
            }

            R.id.linlay_make_orginal ->{
                startActivity(DarenSquareMakeOriginalAty::class.java)
            }

            R.id.linlay_comment ->{
                startActivity(CommentListAty::class.java)
            }

            R.id.linlay_fans ->{
                var bundle = Bundle()
                bundle.putString("type","fans")
                startActivity(FansAty::class.java,bundle)
            }

            R.id.linlay_mine->{
                var bundle = Bundle()
                bundle.putString("typePage", "my")
                startActivity(PersonDetailsAty::class.java, bundle)
            }

            R.id.linlay_daren ->{
                var bundle = Bundle()
                bundle.putString("creator_status", creator_status)
                startActivity(DarenSquareLeveAty::class.java, null)
            }
        }
    }

    inner class GoldRecyclerAdapter : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
            return fGoldViewHolder(ItemDareSquareBinding.inflate(LayoutInflater.from(this@DarenSquareAty)))
        }

        override fun getItemCount(): Int = list.size

        override fun getItemViewType(position: Int): Int {
            return position
        }

        override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {

            if (holder is fGoldViewHolder) {

                with(holder) {

                    var maxW = AutoLayoutConifg.getInstance().screenWidth
                    ImageLoader.loadImageAes(this@DarenSquareAty,list[position]["cover"],mBinding.imgv,maxW,maxW)
                    mBinding.tvTitle.text = list[position]["title"]
                    itemView?.setOnClickListener {

                        var link = list[position]["link"]!!
                        if (TextUtils.isEmpty(link)) {
                            return@setOnClickListener
                        }
                        this@DarenSquareAty?.requestAdCount(list[position]["id"].toString())
                        MyUtils3.openTowPage(this@DarenSquareAty,link)
                    }
                }

            }

        }

        inner class fGoldViewHolder(binding: ItemDareSquareBinding) :
            RecyclerView.ViewHolder(binding.root) {
            var mBinding: ItemDareSquareBinding = binding

            init {
                AutoUtils.autoSize(binding.root)

            }
        }

    }


}
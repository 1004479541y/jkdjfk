package com.mail.myapplication.ui.app

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.mail.comm.app.BaseApp
import com.mail.comm.base.AbsViewHolder
import com.mail.comm.base.BaseAty
import com.mail.comm.image.ImageLoader
import com.mail.comm.net.AESCBCCrypt
import com.mail.comm.utils.JSONUtils
import com.mail.comm.utils.TimeUtils
import com.mail.myapplication.databinding.DgNoticeMsgBinding
import com.mail.myapplication.interfaces.Home
import com.mail.myapplication.ui.find.MatchVoiceAty
import com.mail.myapplication.ui.msg.chat.ChatAty
import com.yhz.adaptivelayout.utils.AutoUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.xutils.common.util.LogUtil
import java.util.*

class NoticeVh(context: Context, parentView: ViewGroup) : AbsViewHolder(context, parentView) {

    lateinit var mBinding: DgNoticeMsgBinding
    var time_end: Double? = null
    var str_notice = ""
    var match_id = ""
    var timerT: Timer? = null
    var timerTaskT: TimerTask? = null
    var baseAty: BaseAty? = null
    var home = Home()
    var info_code = ""
    var class_name =""
    var mNoticeVhListen:NoticeVhListen?=null
    var msg_type =""

    override fun getLayoutId() = 0

    override fun init() {
        if (mContext is BaseAty) {
            baseAty = mContext as BaseAty
        }
    }

    override fun getLayoutView(): View {
        mBinding = DgNoticeMsgBinding.inflate(LayoutInflater.from(mContext));
        return mBinding.root
    }

    override fun onResume() {
        super.onResume()
        LogUtil.e("NoticeVh onResume")
        showNoticeMsg()
    }

    override fun onPause() {
        super.onPause()
        cancelTimerT()
    }

    override fun onCreate() {
        super.onCreate()
        info_code = BaseApp?.instance?.getOneMapData("info_code").toString()
        class_name = baseAty?.javaClass?.simpleName.toString()
        with(mBinding) {
            tvEnterChat.setOnClickListener {
                mNoticeVhListen?.onClickEnterChat()
                BaseApp?.instance?.clearNoticeMsg()
                baseAty?.startProgressDialog()
                home.a55(match_id, this@NoticeVh)
            }

            imgvCancel.setOnClickListener {
                BaseApp?.instance?.clearNoticeMsg()
                relayNotice.visibility = View.GONE
            }
        }

    }

    override fun onComplete(var2: String?, type: String?) {
        super.onComplete(var2, type)
        if (type == "match/details") {
            baseAty?.stopProgressDialog()
            var map = JSONUtils.parseKeyAndValueToMap(var2)

            if (map["code"] == "200") {
                var str = AESCBCCrypt.aesDecrypt(map["data"])
                var map_data = JSONUtils.parseKeyAndValueToMap(str)

                var map_from_user = JSONUtils.parseKeyAndValueToMap(map_data["from_user"])
                var map_to_user = JSONUtils.parseKeyAndValueToMap(map_data["to_user"])

                baseAty?.showToastS(info_code)

                if (map_from_user["user_code"] == info_code) {
                    baseAty?.showToastS("from_user_code == info_code")
                    return
                }
                if (map_to_user["user_code"] != info_code) {
                    baseAty?.showToastS("to_user_code != info_code")
                    return
                }

                if (map_data["voice_time"] == "0") {
                    var bundle = Bundle()
                    bundle.putString("code", map_from_user["user_code"])
                    bundle.putString("nick", map_from_user!!["nick"]!!)
                    bundle.putString("avatar", map_from_user!!["avatar"]!!)
                    bundle.putString("sendMaxNum", map_data!!["send_message_num"]!!)
                    bundle.putString("receiveNum", map_data!!["receive_message_num"]!!)
                    bundle.putString("min_unfollow_coins", map_data!!["min_unfollow_coins"]!!)
                    bundle.putString("enter_type", "match")
                    bundle.putString("match_id", match_id)
                    bundle.putString("json", str)
                    baseAty?.startActivity(ChatAty::class.java, bundle)

                    if (class_name == "MatchAty") {
                        baseAty?.finish()
                    }

                } else {
                    var bundle = Bundle()
                    bundle.putString("match_id", match_id)
                    bundle.putString("json", str)
                    bundle.putString("user_type", "to")
                    baseAty?.startActivity(MatchVoiceAty::class.java, bundle)

                    if (class_name == "MatchAty") {
                        baseAty?.finish()
                    }

                }

            } else {
                mBinding.relayNotice.visibility = View.GONE
                baseAty?.showToastS(map["message"])
            }
        }
    }

    fun finish(){
    }

    interface  NoticeVhListen{
        fun onClickEnterChat()
    }

    fun setNoticeVhListen(mNoticeVhListen:NoticeVhListen){
        this.mNoticeVhListen = mNoticeVhListen
    }

    override fun onExceptionType(type: String?) {
        super.onExceptionType(type)

        if (type == "match/details") {
            baseAty?.stopProgressDialog()

            if (class_name == "MatchAty") {
                baseAty?.showToastS("进入聊天失败..")
                baseAty?.finish()
            }
        }

    }

    fun showNoticeMsg() {
        var list_msg_notice = BaseApp?.instance?.getAllNoticeMsg()
        if (list_msg_notice == null || list_msg_notice.size == 0) {
            mBinding.relayNotice.visibility = View.GONE
            return
        }
        time_end = list_msg_notice[0]["time_end"]?.toDouble()!!
        var c_time = TimeUtils.getBeijinTime().toDouble()
        if (time_end!! < c_time) {
            mBinding.relayNotice.visibility = View.GONE
            return
        }
        startTime()

        mBinding.relayNotice.visibility = View.VISIBLE
        var map_msg = list_msg_notice[0]
        var msg = map_msg["msg"]
        str_notice = AESCBCCrypt.aesDecrypt(msg)
        var map = JSONUtils.parseKeyAndValueToMap(str_notice)
        match_id = map["match_id"]!!
        var map_from_user = JSONUtils.parseKeyAndValueToMap(map["from_user"])
        var maxW_head = AutoUtils.getPercentWidthSizeBigger(300)
        ImageLoader.loadImageAes(
            mContext,
            map_from_user["avatar"],
            mBinding.imgvNoticeHead,
            maxW_head,
            maxW_head
        )

        if (map["notice_type"]=="201"){
            msg_type = "语音"
        }else if (map["notice_type"]=="203"){
            msg_type = "文字"
        }else{
            msg_type = "文字"
        }
    }

    fun startTime() {
        cancelTimerT()
        timerT = Timer()
        timerTaskT = object : TimerTask() {
            override fun run() {
                var c_time = TimeUtils.getBeijinTime().toDouble()
                var t = (time_end!! - c_time) / 1000
                var text = TimeUtils.formatSecond2(t)
                getCoroutineScope()?.launch {
                    withContext(Dispatchers.Main) {
                        if (t <= 0) {
                            cancelTimerT()
                            mBinding.relayNotice.visibility = View.GONE
                        }
                        mBinding.tvEnterChat.text = "进入${msg_type}聊天(${text})"
                    }
                }
            }
        }
        timerT?.schedule(timerTaskT, 0, 500)
    }

    fun cancelTimerT() {
        timerT?.cancel()
        timerT = null
        timerTaskT?.cancel()
        timerTaskT = null
    }

    override fun onDestroy() {
        super.onDestroy()
        cancelTimerT()
        mContext = null
        baseAty = null
    }

}
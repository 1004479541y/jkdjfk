package com.mail.myapplication.ui.mine.person.cp

import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.text.TextUtils
import android.util.TypedValue
import android.view.View
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.lifecycle.Lifecycle
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.adapter.FragmentStateAdapter
import androidx.viewpager2.widget.ViewPager2
import com.google.android.material.appbar.AppBarLayout
import com.google.android.material.appbar.CollapsingToolbarLayout
import com.google.gson.Gson
import com.mail.comm.app.AppConfig
import com.mail.comm.app.AppManager
import com.mail.comm.function.chooseimg.ChooseImgAty
import com.mail.comm.image.ImageLoader
import com.mail.comm.net.AESCBCCrypt
import com.mail.comm.utils.JSONUtils
import com.mail.comm.utils.MyUtils2
import com.mail.comm.utils.PreferencesUtils
import com.mail.comm.view.load.XLoadTip
import com.mail.myapplication.BaseXAty
import com.mail.myapplication.BaseXFrg
import com.mail.myapplication.R
import com.mail.myapplication.databinding.AtyPersonCpDetailsBinding
import com.mail.myapplication.interfaces.Home
import com.mail.myapplication.interfaces.Lar
import com.mail.myapplication.ui.MainWalletAty
import com.mail.myapplication.ui.dg.gift.GiftDialog
import com.mail.myapplication.ui.mine.person.PersonDetailsAty
import com.mail.myapplication.ui.mine.person.PersonOtherDetailsAty
import com.yhz.adaptivelayout.config.AutoLayoutConifg
import com.yhz.adaptivelayout.utils.AutoUtils
import java.lang.Math.abs

class PersonCpDetailsAty : BaseXAty() {

    lateinit var mBinding: AtyPersonCpDetailsBinding
    lateinit var list_tv: Array<TextView>
    lateinit var list_v: Array<View>

    var user_code = ""
    var info_code = ""
    var room_id = ""
    var cover_update =""
    var cp_user_code =""


    var home = Home()
    var lar = Lar()
    var map_info: MutableMap<String, String>? = null
    var list_frg = ArrayList<BaseXFrg>()
    var mGiftDialog: GiftDialog? = null
    var mPersonCpIdeaDg :PersonCpIdeaDg ? =null
    var mPersonCpMoreDg :PersonCpMoreDg?=null

    override fun getLayoutId(): Int = 0

    override fun getLayoutView(): View {
        mBinding = AtyPersonCpDetailsBinding.inflate(layoutInflater);
        return mBinding.root
    }

    override fun initView() {

        user_code = intent.getStringExtra("user_code").toString()

        cp_user_code = intent.getStringExtra("cp_user_code").toString()

        if (intent.hasExtra("room_id")){
            room_id = intent.getStringExtra("room_id").toString()
        }

        if (intent.hasExtra("cp_user_code")){
            cp_user_code = intent.getStringExtra("cp_user_code").toString()
        }

        info_code = PreferencesUtils.getString(this, "info_code")

        with(mBinding) {
            list_tv = arrayOf(tv00,tv01)
            list_v = arrayOf(v00,v01)
        }

        initLayout()

    }

    override fun requestData() {
        mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.loading)
//        home?.a75(room_id,"",this)
        if (!TextUtils.isEmpty(room_id)){
            home?.a75(room_id,"",this)
        }else{
            home?.a75("",cp_user_code,this)
        }

    }

    override fun onExceptionType(type: String?) {
        super.onExceptionType(type)

        stopProgressDialog()
        if (type == "cp/info"){
            mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.error)
        }
    }

    override fun onComplete(var2: String?, type: String?) {
        super.onComplete(var2, type)

        if (type == "comment/write"){
            stopProgressDialog()
            var map = JSONUtils.parseKeyAndValueToMap(var2)
            if (map["code"] == "200") {
                var frg = list_frg[1]
                frg.requestData()
            }else{
                showToastS(map["message"])
            }
        }

        if (type == "cp/broken"){
            stopProgressDialog()
            var map = JSONUtils.parseKeyAndValueToMap(var2)
            if (map["code"] == "200") {
                finish()
                AppManager.getInstance().killActivity(PersonCpAty::class.java)
                AppManager.getInstance().killActivity(PersonOtherDetailsAty::class.java)
                AppManager.getInstance().killActivity(PersonDetailsAty::class.java)
            }else{
                showToastS(map["message"])
            }
        }


        if(type == "cp/info"){
            var map = JSONUtils.parseKeyAndValueToMap(var2)
            if (map["code"] == "200") {
                mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.finish)

                var str = AESCBCCrypt.aesDecrypt(map["data"])

                var map_str = JSONUtils.parseKeyAndValueToMap(str)

                room_id = map_str["id"].toString()

                var maxW = AutoLayoutConifg.getInstance().screenWidth
                var maxW2 = AutoUtils.getPercentWidthSize(400)

                ImageLoader.loadImageAes(this, map_str["cover"], mBinding.imgvCover,maxW,maxW)
                ImageLoader.loadImageAes(this, map_str["from_user_avatar"], mBinding.imgvHead,maxW2,maxW2)
                ImageLoader.loadImageAes(this, map_str["to_user_avatar"], mBinding.imgvHead2,maxW2,maxW2)

                mBinding.tvDays.text = "我们相伴了${map_str["love_days"]}天"

                if (info_code != map_str["from_user_code"] && info_code!= map_str["to_user_code"]){
                    mBinding.relayMore.visibility = View.GONE
                    mBinding.relayMore2.visibility = View.GONE
                }else{
                    mBinding.relayMore.visibility = View.VISIBLE
                    mBinding.relayMore2.visibility = View.VISIBLE
                }

                initFrg()

            }else{
                mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.error)
            }
        }

        if (type == "file/upload") {

            var map = JSONUtils.parseKeyAndValueToMap(var2)
            if (map["code"] == "0") {
                var dataMap = JSONUtils.parseDataToMap(var2)
                cover_update = dataMap["url"]!!
                var file_path = dataMap["file_path"]!!
                home?.a79(room_id,file_path,this)
            } else {
                stopProgressDialog()
                showToastS(map["message"])
            }

        }

        if(type == "update/cover"){
            stopProgressDialog()
            var map = JSONUtils.parseKeyAndValueToMap(var2)
            if (map["code"] == "200") {
                var maxW = AutoLayoutConifg.getInstance().screenWidth
                ImageLoader.loadImageAes(this, cover_update, mBinding.imgvCover,maxW,maxW)
            }else{
                showToastS(map["message"])
            }
        }


        if (type == "gift/reward"){
            stopProgressDialog()
            var map = JSONUtils.parseKeyAndValueToMap(var2)
            if (map["code"] == "200") {
                showToastS("打赏成功")
//                var index = mBinding.viewPager.currentItem
                var frg = list_frg[0]
                frg.requestData()
            }else{
                showToastS(map["message"])
            }
        }

    }

    fun requestData2(){}

    fun initFrg(){

        list_frg.add(PersonCpDetails01Frg.create(room_id))

        list_frg.add(PersonCpDetails02Frg.create(room_id))

        mBinding.viewPager.adapter = PersonListAdataper(
            supportFragmentManager,
            this@PersonCpDetailsAty.lifecycle,
            list_frg
        )

        mBinding.viewPager.offscreenPageLimit = list_frg.size

    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setTranslanteBar()
        if (AppConfig.model == "wanou"){
            setAndroidNativeLightStatusBar(false)
        }else{
            setAndroidNativeLightStatusBar(true)
        }

        with(mBinding) {

            loading.setLoadingTipXReloadCallback(object : XLoadTip.LoadingTipXReloadCallback {
                override fun reload() {
                    requestData()
                }
            })

            var mLayoutManager2 = GridLayoutManager(this@PersonCpDetailsAty, 1)
            mLayoutManager2.orientation = RecyclerView.VERTICAL

            appbar.addOnOffsetChangedListener(AppBarLayout.OnOffsetChangedListener { appBarLayout, verticalOffset ->
                val Offset = abs(verticalOffset).toFloat()
                val totalScrollRange = appBarLayout?.totalScrollRange
                var a = (Offset / totalScrollRange!!)
                linlayName.alpha = a
                linlayName2.alpha = 1-a
                relayBack.alpha =a
                relayBack2.alpha =1-a
                relayMore.alpha = a
                relayMore2.alpha = 1-a
            })

            linlay00.setOnClickListener {
                viewPager.setCurrentItem(0,true)
            }
            linlay01.setOnClickListener {
                viewPager.setCurrentItem(1,true)
            }

            viewPager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
                override fun onPageSelected(position: Int) {
                    when (position) {
                        0 -> {
                            setSelector(tv00)
                        }
                        1 -> {
                            setSelector(tv01)
                        }


                    }
                }
            })

            viewPager.setCurrentItem(0, false)
        }
    }

    inner class PersonListAdataper(
        fa: FragmentManager,
        lifecycle: Lifecycle,
        val docs: ArrayList<BaseXFrg>
    ) :

        FragmentStateAdapter(fa, lifecycle) {

        override fun getItemCount(): Int = docs.size

        override fun createFragment(position: Int): Fragment = docs[position]

    }

    private fun setSelector(tv: TextView) {
        for (i in list_tv.indices) {
            if (tv === list_tv[i]) {
                list_tv[i].setTextColor(Color.parseColor(getString(R.string.c_01)))
                list_tv[i].setTypeface(Typeface.defaultFromStyle(Typeface.BOLD));//加粗

                list_tv[i].setTextSize(
                    TypedValue.COMPLEX_UNIT_PX,
                    AutoUtils.getPercentWidthSizeBigger(55).toFloat()
                )
                list_v[i].visibility = View.VISIBLE
            } else {
                list_tv[i].setTextColor(Color.parseColor(getString(R.string.c_02)))
                list_tv[i].setTypeface(Typeface.defaultFromStyle(Typeface.NORMAL));//加粗
                list_tv[i].setTextSize(
                    TypedValue.COMPLEX_UNIT_PX,
                    AutoUtils.getPercentWidthSizeBigger(45).toFloat()
                )
                list_v[i].visibility = View.INVISIBLE
            }
        }
    }

    fun initLayout() {
        with(mBinding) {
            var params = toolbar.layoutParams as CollapsingToolbarLayout.LayoutParams
            var StatusBarHeight = MyUtils2.getStateBar(this@PersonCpDetailsAty)
            if (StatusBarHeight <= 0) {
                StatusBarHeight = MyUtils2.dip2px(this@PersonCpDetailsAty, 20F)
            }
            params.topMargin = StatusBarHeight
            params.height = AutoUtils.getPercentHeightSizeBigger(120)
            toolbar.setPadding(0, 0, 0, 0)
            toolbar.layoutParams = params
        }
    }

    fun mainClick(v: View) {

        when (v.id) {

            R.id.relay_back, R.id.relay_back2 -> {
                finish()
            }

            R.id.imgv_gift ->{
                if (mGiftDialog == null){
                    mGiftDialog = GiftDialog(this)
                    mGiftDialog?.setDataType("1")
                }
                mGiftDialog?.show()
                mGiftDialog?.requestData()
                mGiftDialog?.setGiftDialogListen(object : GiftDialog.GiftDialogListen{
                    override fun recharge() {
                        var bundle = Bundle()
                        bundle.putString("page_type", "pay")
                        startActivity(MainWalletAty::class.java, bundle)
                    }

                    override fun sendGift(
                        gift_cover: String,
                        gift_svga: String,
                        gift_title: String,
                        gift_id: String,
                    ) {
                        startProgressDialog()
                        home.a81(gift_id,room_id,this@PersonCpDetailsAty)
                    }

                })
            }

            R.id.imgv_idea ->{

                if (mPersonCpIdeaDg == null){
                    mPersonCpIdeaDg = PersonCpIdeaDg(this)
                }
                mPersonCpIdeaDg?.show()
                mPersonCpIdeaDg?.showInuput()
                mPersonCpIdeaDg?.setPersonCpIdeaDgListen(object :
                    PersonCpIdeaDg.PersonCpIdeaDgListen{
                    override fun send(content: String) {
                        var list_post = ArrayList<MutableMap<String, String>>()
                        var map = HashMap<String, String>()
                        map["content"] = content
                        map["code"] = ""
                        list_post.add(map)
                        val jsonString = Gson().toJson(list_post)
                        home.a83( room_id, jsonString, this@PersonCpDetailsAty)
                    }
                })
            }

            R.id.relay_more,R.id.relay_more2 ->{
                if (mPersonCpMoreDg == null){
                    mPersonCpMoreDg = PersonCpMoreDg(this)
                }
                mPersonCpMoreDg?.setPersonOtherMoreDgListen(object :
                    PersonCpMoreDg.PersonCpMoreDgListen{
                    override fun updateCover() {
                        var bundle = Bundle()
                        bundle.putInt("max_num", 1)
                        bundle.putString("ratio", "16,16")
                        startActivityForResult(ChooseImgAty::class.java, bundle, 300)
//                        startProgressDialog()
//                        lar.b7(path_head, this)
                    }

                    override fun fenshou() {
                        showCommonDialog("1010",true,"你确定要分手吗？","取消"
                        ,"确定",object: BaseCommonDialogListen{

                                override fun onclick01() {

                                }

                                override fun onclick02() {
                                    startProgressDialog()
                                    home?.a84(room_id,this@PersonCpDetailsAty)
                                }

                            })
                    }

                })
                mPersonCpMoreDg?.show()
            }

        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (resultCode != RESULT_OK) {
            return
        }

        when (requestCode) {

            300 -> {
                var type = data?.getStringExtra("type")

                when (type) {
                    "img_photo" -> {
                        var list = data?.getStringArrayListExtra("data")
                        startProgressDialog()
                        lar.b7(list!![0], this)
//                        if (click_upolad_type == "head"){
//                            path_head = list!![0]
//                            ImageLoader.loadImage(this, list!![0], mBinding.ivHead)
//                        }else{
//                            path_wall = list!![0]
//
//                            startProgressDialog()
//                            lar.b722(list!![0], this)
//                        }

                    }
                }

            }
        }
    }



}
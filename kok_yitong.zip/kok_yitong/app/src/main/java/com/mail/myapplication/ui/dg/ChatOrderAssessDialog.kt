package com.mail.myapplication.ui.dg

import android.app.Dialog
import android.os.Bundle
import android.text.TextUtils
import android.view.Gravity
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.mail.comm.base.BaseAty
import com.mail.comm.image.ImageLoader
import com.mail.myapplication.R
import com.mail.myapplication.databinding.DgChatOrderAssessBinding
import com.mail.myapplication.databinding.DgPayBinding
import com.mail.myapplication.databinding.ItemDgPayBinding
import com.mail.myapplication.interfaces.Lar
import com.yhz.adaptivelayout.utils.AutoUtils

class ChatOrderAssessDialog(context: BaseAty) : Dialog(context) {

    private var baseAty = context
    lateinit var mBinding: DgChatOrderAssessBinding
    var listen: ChatOrderAssessDialogListen? = null

    var list = ArrayList<MutableMap<String, String>>()

    var lar = Lar()
    var index_check = 0
    var is_satisfy = "1"
    var content = ""

    fun setData(list: ArrayList<MutableMap<String, String>>) {
        if (isShowing){
            this.list = list
            index_check = 0
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        mBinding = DgChatOrderAssessBinding.inflate(layoutInflater);
        setContentView(mBinding.root)
        window?.setWindowAnimations(R.style.dialogFullscreen3)
        val dialogWindow = window
        dialogWindow!!.setBackgroundDrawable(null)
        dialogWindow.setGravity(Gravity.BOTTOM)
        setCanceledOnTouchOutside(true)
        val m = baseAty.windowManager
        val d = m.defaultDisplay// 获取屏幕宽、高
        val p = dialogWindow.attributes
        window?.getDecorView()?.setPadding(0, 0, 0, 0)
//        p.height =  (d.height * 1) // 高度设置为屏幕的0.6
        p.width = (d.width * 1) // 宽度设置为屏幕的0.85
        dialogWindow.attributes = p

        with(mBinding) {

            relayCancel.setOnClickListener {
                dismiss()
            }

            tvOk.setOnClickListener {

                content  =  edit.text.toString()

                if (TextUtils.isEmpty(content)){
                    baseAty.showToastS("内容不能为空")
                    return@setOnClickListener
                }

                dismiss()
                listen?.assess(is_satisfy,content)
            }

            imgv1.setOnClickListener {
                is_satisfy = "1"
                a1()
            }

            imgv2.setOnClickListener {
                is_satisfy = "0"
                a1()
            }
        }
    }

    fun a1(){
        if (is_satisfy == "1"){
            mBinding.imgv1.setImageResource(R.drawable.ia_66)
            mBinding.imgv2.setImageResource(R.drawable.ia_69)
        }else{
            mBinding.imgv1.setImageResource(R.drawable.ia_67)
            mBinding.imgv2.setImageResource(R.drawable.ia_68)
        }
    }

    fun setData(head:String,nick:String){
        if (isShowing){
            var maxW = AutoUtils.getPercentWidthSizeBigger(300)
            ImageLoader.loadImageAes(baseAty,head,mBinding.ivHead,maxW,maxW)
            mBinding.tvNick.text = nick
        }
    }

    interface  ChatOrderAssessDialogListen{
        fun assess(is_satisfy:String,content:String)
    }

    fun setChatOrderAssessDialogListen(listener:ChatOrderAssessDialogListen){
        this.listen =listener
    }

}
//package com.mail.myapplication.ui.view;
//
//import android.Manifest;
//import android.app.Activity;
//import android.app.AlertDialog;
//import android.app.Dialog;
//import android.content.ComponentName;
//import android.content.Context;
//import android.content.DialogInterface;
//import android.content.Intent;
//import android.content.ServiceConnection;
//import android.content.pm.PackageManager;
//import android.graphics.Bitmap;
//import android.net.Uri;
//import android.os.Build;
//import android.os.Bundle;
//import android.os.Environment;
//import android.os.Handler;
//import android.os.IBinder;
//import android.provider.MediaStore;
//import android.support.annotation.NonNull;
//import android.support.v4.app.ActivityCompat;
//import android.support.v4.content.ContextCompat;
//import android.support.v4.content.FileProvider;
//import android.support.v7.widget.LinearLayoutManager;
//import android.support.v7.widget.RecyclerView;
//import android.view.Gravity;
//import android.view.LayoutInflater;
//import android.view.View;
//import android.view.ViewGroup;
//import android.view.Window;
//import android.view.WindowManager;
//import android.widget.ImageView;
//import android.widget.LinearLayout;
//import android.widget.RelativeLayout;
//import android.widget.TextView;
//
//import com.langji.xiniu.R;
//import com.langji.xiniu.app.BasAty;
//import com.langji.xiniu.interfaces.AnsPro;
//import com.langji.xiniu.services.MusicServices;
//import com.langji.xiniu.ui.details.PhotoDetails;
//import com.langji.xiniu.ui.lar.LoginAty;
//import com.langji.xiniu.ui.mine.otherpersondetails.OtherPersonDetailsAty;
//import com.langji.xiniu.ui.utils.FileCompressUtil;
//import com.langji.xiniu.ui.utils.ImagesUtils;
//import com.langji.xiniu.view.lame.LameMp3Manager;
//import com.langji.xiniu.view.lame.MediaRecorderButton;
//import com.langji.xiniu.view.lame.MediaRecorderListener;
//import com.toocms.dink5.mylibrary.app.Config;
//import com.toocms.dink5.mylibrary.commonutils.JSONUtils;
//import com.toocms.dink5.mylibrary.commonutils.PreferencesUtils;
//import com.toocms.dink5.mylibrary.commonutils.TimeUtils;
//import com.yalantis.ucrop.UCrop;
//import com.zhy.autolayout.utils.AutoUtils;
//
//import org.xutils.http.RequestParams;
//import org.xutils.view.annotation.Event;
//import org.xutils.view.annotation.ViewInject;
//import org.xutils.x;
//
//import java.io.File;
//import java.io.IOException;
//import java.util.ArrayList;
//import java.util.List;
//import java.util.Map;
//import java.util.Timer;
//import java.util.TimerTask;
//
//import me.nereo.multi_image_selector.MultiImageSelector;
//
///**
// * Created by Administrator on 2017/11/9 0009.
// */
//
//public class GoAnswer2Aty extends BasAty implements MusicServices.musicListen, MediaRecorderListener, MusicServices.musicPositionListen {
//
//
//    @ViewInject(R.id.imgv_voice)
//    public ImageView imgv_voice;
//    @ViewInject(R.id.tv_time)
//    public TextView tv_time;
//    @ViewInject(R.id.tv_reset_voice)
//    public TextView tv_reset_voice;
//    @ViewInject(R.id.tv_ok_voice)
//    public TextView tv_ok_voice;
//    @ViewInject(R.id.arc2)
//    public CycleView arc2;
//
//    @ViewInject(R.id.imgv_top_head)
//    public ImageView imgv_top_head;
//    @ViewInject(R.id.tv_top_cat)
//    public TextView tv_top_cat;
//    @ViewInject(R.id.tv_content)
//    public TextView tv_content;
//    @ViewInject(R.id.tv_top_time)
//    public TextView tv_top_time;
//    @ViewInject(R.id.tv_top_person)
//    public TextView tv_top_person;
//    @ViewInject(R.id.tv_nickname_top)
//    public TextView tv_nickname_top;
//
//    @ViewInject(R.id.tv_img_num)
//    public TextView tv_img_num;
//    @ViewInject(R.id.recyclerview)
//    public RecyclerView recyclerview;
//
//    private String audioFileName;
//    private long recordTotalTime;
//    public static final long DEFAULT_MAX_RECORD_TIME = 120000;
//    public static final long DEFAULT_MIN_RECORD_TIME = 2000;
//    protected static final int DEFAULT_MIN_TIME_UPDATE_TIME = 1000;
//    private long maxRecordTime = DEFAULT_MAX_RECORD_TIME;
//    public MusicServices musicServices;
//
//    private Timer timer;
//    private TimerTask timerTask;
//    private Handler mainHandler;
//    private Intent intent;
//    private String bastPath;
//    private long startPriceTime;
//    private long currentPriceTime;
//
//    private int voiceStatus;
//
//    private static String[] PERMISSIONS_STORAGE = {
//            Manifest.permission.READ_EXTERNAL_STORAGE,
//            Manifest.permission.RECORD_AUDIO,
//            Manifest.permission.CAMERA,
//            Manifest.permission.WRITE_EXTERNAL_STORAGE};
//
//    private List<String> mPermissionList = new ArrayList<>();
//    private String id;
//
//    private AnsPro ansPro;
//    private Map<String, String> data_map;
//
//    private File file;
//    private static final int REQUEST_IMAGE = 2;
//    private ArrayList<String> mSelectPath;
//    private static final String SAMPLE_CROPPED_IMAGE_NAME = "SampleCropImage";
//    private static final int REQUEST_CODE_IMAGE_CAPTURE = 100;
//    private ArrayList<String> img_recyList;
//    private ArrayList<String> img_recyPathList;
//    private HeroseTopRecyclerAdapter adapter;
//
//
//    @Override
//    public int getLayoutId() {
//        return R.layout.aty_go_answer2;
//    }
//
//    @Override
//    public void initPresenter() {
//
//    }
//
//    @Override
//    public void initView() {
//        mSelectPath = new ArrayList<>();
//        img_recyList = new ArrayList<>();
//        img_recyPathList = new ArrayList<>();
//        id = getIntent().getStringExtra("id");
//        ansPro = new AnsPro();
//        img_recyList.add("0");
//    }
//
//    @Override
//    public void requestData() {
//        startProgressDialog();
//        ansPro.h(this, id, 0, this);
//    }
//
//    @Override
//    public void onComplete(RequestParams var1, String var2, String type) {
//        super.onComplete(var1, var2, type);
//        stopProgressDialog();
//        Map<String, String> map = JSONUtils.parseKeyAndValueToMap(var2);
//        if (!map.get("ret").equals("200")) {
//            if (map.get("ret").equals("581")) {
//                finish();
//            }
//            return;
//        }
//        if (type.equals("Answer.addAnswer")) {
////            showShortToast(map.get("msg"));
//            finish();
//        }
//
//        if (type.equals("QA.offerDetail")) {
//            data_map = JSONUtils.parseKeyAndValueToMap(map.get("data"));
//            final Map<String, String> question_user = JSONUtils.parseKeyAndValueToMap(data_map.get("question_user"));
//            tv_content.setText(data_map.get("content"));
//            tv_nickname_top.setText(question_user.get("nickname"));
//            ImagesUtils.disImgCircleNo(GoAnswer2Aty.this, question_user.get("avatar"), imgv_top_head);
//            tv_top_cat.setText(data_map.get("catName"));
//            Double public_time2 = Double.parseDouble(data_map.get("public_time"));
//            Double answer_end_time2 = Double.parseDouble(data_map.get("answer_end_time"));
//            String s2 = TimeUtils.formatSecond4(answer_end_time2 - System.currentTimeMillis() / 1000);
//            tv_top_time.setText(s2);
//            tv_top_person.setText(data_map.get("answer_num") + "人已回答");
//            imgv_top_head.setOnClickListener(new View.OnClickListener() {
//                @Override
//                public void onClick(View view) {
//                    if (question_user.get("is_open").equals("1")) {
//                        Intent intent = new Intent(mContext, OtherPersonDetailsAty.class);
//                        intent.putExtra("user_id", question_user.get("id"));
//                        mContext.startActivity(intent);
//                    }
//                }
//            });
//
//        }
//    }
//
//    /**
//     * voiceStatus = 0 没有录音 1正在录音2 录音完成 3正在播放
//     *
//     * @param view
//     */
//    @Event(value = {R.id.imgv_back, R.id.imgv_voice, R.id.tv_reset_voice, R.id.tv_ok_voice})
//    private void onTestBaidulClick(View view) {
//
//        switch (view.getId()) {
//            case R.id.imgv_back:
//                finish();
//                break;
//            case R.id.imgv_voice:
//                if (voiceStatus == 0) {
//                    voiceStatus = 1;
//                    arc2.setVisibility(View.VISIBLE);
//                    onRecordStart();
//                    imgv_voice.setImageResource(R.drawable.aio_record_stop);
//                } else if (voiceStatus == 1) {
//                    voiceStatus = 2;
//                    stopRecordAudio();
//                    if (timer != null) {
//                        timer.cancel();
//                    }
//                    imgv_voice.setImageResource(R.drawable.aio_record_play_nor);
//                } else if (voiceStatus == 2) {
//                    arc2.setProgress(0);
////                    LogUtil.e("ddddddddddaudioFileName" + audioFileName);
//                    musicServices.startPlaying(audioFileName);
//                    voiceStatus = 3;
//                    imgv_voice.setImageResource(R.drawable.aio_record_stop);
////                    LogUtil.e("dddddddddddddddstart");
//                } else if (voiceStatus == 3) {
//                    voiceStatus = 2;
//                    musicServices.stopPlaying();
//                    tv_reset_voice.setVisibility(View.VISIBLE);
//                    tv_ok_voice.setVisibility(View.VISIBLE);
//                    imgv_voice.setImageResource(R.drawable.aio_record_play_nor);
//                }
//                break;
//            case R.id.tv_reset_voice:
//                showNoPayDialog(0);
//                break;
//            case R.id.tv_ok_voice:
//                if (!Config.isLogin()) {
//                    startActivity(LoginAty.class);
//                    return;
//                }
//                showNoPayDialog(1);
//                break;
//        }
//    }
//
//    @Override
//    public void onExceptionType(Throwable var1, RequestParams params, String type) {
//        super.onExceptionType(var1, params, type);
//        stopProgressDialog();
//        if (type.equals("Answer.addAnswer")) {
//            showShortToast("网络不给力");
//        }
//    }
//
//
//    @Override
//    public void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setisEndbleLoginRefresh(true);
//        LameMp3Manager.instance.setMediaRecorderListener(this);
//        bastPath = getBasePath();
//        mPermissionList.clear();
//        for (int i = 0; i < PERMISSIONS_STORAGE.length; i++) {
//            if (ContextCompat.checkSelfPermission(this, PERMISSIONS_STORAGE[i]) != PackageManager.PERMISSION_GRANTED) {
//                mPermissionList.add(PERMISSIONS_STORAGE[i]);
//
//            }
//        }
//        if (mPermissionList.isEmpty() || Build.VERSION.SDK_INT < Build.VERSION_CODES.JELLY_BEAN) {
//        } else {
//            String[] permissions = mPermissionList.toArray(new String[mPermissionList.size()]);//将List转为数组
//            ActivityCompat.requestPermissions(this, permissions, 101);
//        }
//        mainHandler = new Handler();
//        intent = new Intent(this, MusicServices.class);
//        startService(intent);
//        bindService(intent, serviceConnection, Context.BIND_AUTO_CREATE);
//        adapter = new HeroseTopRecyclerAdapter(this);
//        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
//        linearLayoutManager.setOrientation(LinearLayoutManager.HORIZONTAL);
//        recyclerview.setLayoutManager(linearLayoutManager);
//        recyclerview.setAdapter(adapter);
//    }
//
//    ServiceConnection serviceConnection = new ServiceConnection() {
//        @Override
//        public void onServiceConnected(ComponentName componentName, IBinder iBinder) {
//            MusicServices.MyBinder binder = (MusicServices.MyBinder) iBinder;
//            musicServices = binder.getService();// 获取到的Service即MyService
//            musicServices.setMusicListen(GoAnswer2Aty.this);
//            musicServices.setMusicPositionListen(GoAnswer2Aty.this);
//        }
//
//        @Override
//        public void onServiceDisconnected(ComponentName componentName) {
//
//        }
//    };
//
//
//    /**
//     * 检查是否ready录制,如果已经ready则开始录制
//     */
//    private void startRecordAudio() throws RuntimeException {
//        LameMp3Manager.instance.startRecorder(bastPath + File.separator + "lame.mp3");
//    }
//
//    public void onRecordStart() {
//        recordTotalTime = 0;
//        startPriceTime = System.currentTimeMillis();
//        tv_time.setTextColor(getResources().getColor(R.color.main_color));
//        initTimer();
//        timer.schedule(timerTask, 0, DEFAULT_MIN_TIME_UPDATE_TIME);
//        startRecordAudio();
//    }
//
//    /**
//     * 停止录音
//     */
//    private void stopRecordAudio() throws RuntimeException {
//        try {
//
//            currentPriceTime = System.currentTimeMillis();
//            recordTotalTime = currentPriceTime - startPriceTime;
//            if (recordTotalTime >= maxRecordTime) {
//                recordTotalTime = maxRecordTime;
//            }
//            LameMp3Manager.instance.stopRecorder();
//            tv_reset_voice.setVisibility(View.VISIBLE);
//            tv_ok_voice.setVisibility(View.VISIBLE);
//            if (timer != null) {
//                timer.cancel();
//            }
//        } catch (Exception e) {
//        }
//    }
//
//    /**
//     * 初始化计时器用来更新倒计时
//     */
//    private void initTimer() {
//        timer = new Timer();
//        timerTask = new TimerTask() {
//            @Override
//            public void run() {
//                mainHandler.post(new Runnable() {
//                    @Override
//                    public void run() {
//                        //每隔1000毫秒更新一次ui
//                        currentPriceTime = System.currentTimeMillis();
////                        recordTotalTime += 1000;
//                        recordTotalTime = currentPriceTime - startPriceTime;
//                        float l = recordTotalTime / (float) maxRecordTime;
//                        arc2.setProgress((int) (l * 100));
//                        updateTimerUI();
//                    }
//                });
//            }
//        };
//    }
//
//    private void updateTimerUI() {
//        if (recordTotalTime >= maxRecordTime) {
//            stopRecordAudio();
//            voiceStatus = 2;
//            imgv_voice.setImageResource(R.drawable.aio_record_play_nor);
//            String s = TimeUtils.formatSecond2((double) (recordTotalTime / 1000));
//            tv_time.setText(s);
//        } else {
//            String s = TimeUtils.formatSecond2((double) (recordTotalTime / 1000));
////            String string = String.format(" 倒计时 %s ", StringUtil.formatRecordTime(recordTotalTime, maxRecordTime));
//            tv_time.setText(s);
//        }
//    }
//
//
//    public void onRecordCancel() {
//        if (timer != null) {
//            timer.cancel();
//        }
//    }
//
//    @Override
//    public void playCompletion() {
//        voiceStatus = 2;
//        imgv_voice.setImageResource(R.drawable.aio_record_play_nor);
//        if (recordTotalTime == maxRecordTime) {
//            arc2.setProgress(100);
//        }
//    }
//
//    @Override
//    protected void onDestroy() {
//        super.onDestroy();
//        onRecordCancel();
//        musicServices.stopPlaying();
//        if (serviceConnection != null) {
//            unbindService(serviceConnection);// 解除绑定，断开连接
//            stopService(intent);
//        }
//    }
//
//    @Override
//    public void onRecorderFinish(int status, String path) {
//        if (status == MediaRecorderButton.RECORDER_SUCCESS) {
//            audioFileName = path;
////            LogUtil.e("ddddddddddddddddddd文件大侠" + FileSizeUtil.getFileOrFilesSize(audioFileName, FileSizeUtil.SIZETYPE_KB));
//        } else {
//            tv_time.setText("点击录音，最多录制120秒");
//            voiceStatus = 0;
//            imgv_voice.setImageResource(R.drawable.aio_record_start_nor);
//            arc2.setVisibility(View.GONE);
//            musicServices.stopPlaying();
//            stopRecordAudio();
//            tv_reset_voice.setVisibility(View.GONE);
//            tv_ok_voice.setVisibility(View.GONE);
//        }
//    }
//
//    public String getBasePath() {
//        String strPath = null;
//        if (!Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED)) {
//            strPath = this.getFilesDir() + "/" + "lameMp3";
//        } else {
//            strPath = Environment.getExternalStorageDirectory() + "/" + "lameMp3";
//        }
//        File dir = new File(strPath);
//        if (!dir.exists()) {
//            dir.mkdirs();
//        }
//        return strPath;
//    }
//
//
//    @Override
//    public void currentPostion(String time, int mCurrentPosition) {
//        float l = mCurrentPosition / (float) seekBarMaxIndex;
//        arc2.setProgress((int) (l * 100));
////        LogUtils.e("ddddddddddddddddmaxIndex=" + maxIndex + ",mCurrentPosition=" + mCurrentPosition + ",recordTotalTime=" + recordTotalTime);
//    }
//
//    private int seekBarMaxIndex;
//    private int maxIndex;
//
//    @Override
//    public void returnMaxIndex(int maxIndex) {
//        this.maxIndex = maxIndex;
//        seekBarMaxIndex = (int) (maxIndex * maxRecordTime / recordTotalTime);
//    }
//
//    private void pickImage() {
//        mPermissionList.clear();
//        for (int i = 0; i < PERMISSIONS_STORAGE.length; i++) {
//            if (ContextCompat.checkSelfPermission(mContext, PERMISSIONS_STORAGE[i]) != PackageManager.PERMISSION_GRANTED) {
//                mPermissionList.add(PERMISSIONS_STORAGE[i]);
//
//            }
//        }
//        if (mPermissionList.isEmpty() || Build.VERSION.SDK_INT < Build.VERSION_CODES.JELLY_BEAN) {
//            showOptions2();
////            showOptions();
//        } else {
//            String[] permissions = mPermissionList.toArray(new String[mPermissionList.size()]);//将List转为数组
//            ActivityCompat.requestPermissions(GoAnswer2Aty.this, permissions, 101);
//        }
//    }
//
//    public void showOptions() {
//        AlertDialog.Builder alertDialog = new AlertDialog.Builder(this);
//        alertDialog.setTitle(R.string.options);
//        alertDialog.setItems(R.array.options, new DialogInterface.OnClickListener() {
//            @Override
//            public void onClick(DialogInterface dialog, int which) {
//                if (which == 0) {
//                    int maxNum = 9;
//                    MultiImageSelector selector = MultiImageSelector.create(GoAnswer2Aty.this);
//                    selector.showCamera(false);
//                    selector.count(maxNum);
//                    selector.single();
//                    selector.origin(mSelectPath);
//                    selector.start(GoAnswer2Aty.this, REQUEST_IMAGE);
//                } else {
//                    useCamera();
//                }
//            }
//        });
//        alertDialog.show();
//    }
//
//    public void showOptions2() {
//        mSelectPath.clear();
//        int size = img_recyPathList.size();
//        int maxNum = 3 - size;
//        MultiImageSelector selector = MultiImageSelector.create(GoAnswer2Aty.this);
//        selector.showCamera(false);
//        selector.count(maxNum);
//        selector.multi();
//        selector.origin(mSelectPath);
//        selector.start(GoAnswer2Aty.this, REQUEST_IMAGE);
//    }
//
//    /**
//     * 使用相机
//     */
//    private void useCamera() {
//
//        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
//        file = new File(Environment.getExternalStorageDirectory().getAbsolutePath()
//                + "/test/" + System.currentTimeMillis() + ".jpg");
//        file.getParentFile().mkdirs();
//        Uri uri;
//        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
//            uri = FileProvider.getUriForFile(this, "com.sixiangxingke.xingke.FileProvider", file);
//        } else {
//            file = new File(getNewPhotoPath());
//            uri = Uri.fromFile(file);
//        }
//        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
//        intent.putExtra(MediaStore.EXTRA_OUTPUT, uri);
//        startActivityForResult(intent, REQUEST_CODE_IMAGE_CAPTURE);
//    }
//
//    private boolean isEndbleOpen = true;
//
//    @Override
//    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
//        if (requestCode == 101) {
//            for (int i = 0; i < grantResults.length; i++) {
//                if (grantResults[i] != PackageManager.PERMISSION_GRANTED) {
//                    isEndbleOpen = false;
//                    boolean showRequestPermission = ActivityCompat.shouldShowRequestPermissionRationale(GoAnswer2Aty.this, permissions[i]);
//                    if (showRequestPermission) {//
////                        showOptions();
////                            judgePermission();
////                        return;
//                    } else {
//                    }
//                }
//            }
//            if (isEndbleOpen) {
////                showOptions();
//            }
//        } else {
//            super.onRequestPermissionsResult(requestCode, permissions, grantResults);
//        }
//    }
//
//
//    private void startCropActivity(@NonNull Uri uri) {
//        String destinationFileName = SAMPLE_CROPPED_IMAGE_NAME + System.currentTimeMillis();
//        destinationFileName += ".jpg";
//        UCrop uCrop = UCrop.of(uri, Uri.fromFile(new File(getCacheDir(), destinationFileName)));
//        uCrop = uCrop.withAspectRatio(1, 1);
//
//        UCrop.Options options = new UCrop.Options();
//        options.setCompressionFormat(Bitmap.CompressFormat.JPEG);
//        options.setCompressionQuality(100);
//        options.setStatusBarColor(ActivityCompat.getColor(GoAnswer2Aty.this, R.color.mis_actionbar_color));
//        options.setToolbarColor(ActivityCompat.getColor(GoAnswer2Aty.this, R.color.mis_actionbar_color));
//        options.setFreeStyleCropEnabled(true);
//        uCrop.withOptions(options);
//        uCrop.start(this, UCrop.REQUEST_CROP);
//    }
//
//    private String getNewPhotoPath() {
//        return Environment.getExternalStorageDirectory().getPath() + "/WebViewUploadImage" + "/" + System.currentTimeMillis() + ".jpg";
//    }
//
//    @Override
//    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
//        super.onActivityResult(requestCode, resultCode, data);
//        if (resultCode == Activity.RESULT_OK) {
//            switch (requestCode) {
//                case REQUEST_IMAGE:
//                    mSelectPath = data.getStringArrayListExtra(MultiImageSelector.EXTRA_RESULT);
////                    Uri uri = Uri.fromFile(new File(mSelectPath.get(0)));
////                    startCropActivity(uri);
////                    for (int i = 0; i < mSelectPath.size(); i++) {
////                        img_recyPathList.add(mSelectPath.get(i));
////                    }
//                    for (int i = 0; i < mSelectPath.size(); i++) {
//                        try {
//                            Bitmap bitmap = FileCompressUtil.compressImage(FileCompressUtil.getimage(mSelectPath.get(i)));
//                            File file = new File(FileCompressUtil.saveFile(bitmap, FileCompressUtil.getTimeNow() + "_" + i, GoAnswer2Aty.this));
//                            img_recyPathList.add(file.getAbsolutePath());
////                uploadFile(file, "leftPicPath");
//                        } catch (IOException e) {
//                            e.printStackTrace();
//                        }
//
//                    }
//
//                    img_recyList.clear();
//                    for (int i = 0; i < img_recyPathList.size(); i++) {
//                        img_recyList.add("1");
//                    }
//                    if (img_recyPathList.size() != 3) {
//                        img_recyList.add("0");
//                    }
//                    adapter.notifyDataSetChanged();
//                    tv_img_num.setText(img_recyPathList.size() + "/3");
//                    break;
//                case UCrop.REQUEST_CROP:
//                    Uri resultUri = UCrop.getOutput(data);
//                    String path = new File(resultUri.getPath()).getAbsolutePath();
//                    img_recyPathList.add(path);
//                    img_recyList.clear();
//                    for (int i = 0; i < img_recyPathList.size(); i++) {
//                        img_recyList.add("1");
//                    }
//                    if (img_recyPathList.size() != 3) {
//                        img_recyList.add("0");
//                    }
//                    adapter.notifyDataSetChanged();
//                    tv_img_num.setText(img_recyPathList.size() + "/3");
//                    break;
//                case REQUEST_CODE_IMAGE_CAPTURE:
//                    Uri uri2 = Uri.fromFile(file);
//                    startCropActivity(uri2);
//                    break;
//            }
//        }
//    }
//
//    private int isCheck;
//
//    public void showNoPayDialog(final int index) {
//        View view = View.inflate(this, R.layout.dlg_exit, null);
//        TextView tv_content = (TextView) view.findViewById(R.id.buildeexti_tv_content);
//        TextView tv_no = (TextView) view.findViewById(R.id.buildeexti_tv_no);
//        TextView tv_ok = (TextView) view.findViewById(R.id.builderexit_tv_ok);
//        TextView tv_tilte = (TextView) view.findViewById(R.id.tv_tilte);
//        LinearLayout linlay_check = (LinearLayout) view.findViewById(R.id.linlay_check);
//        final ImageView imgv_check = (ImageView) view.findViewById(R.id.imgv_check);
//
//        final Dialog dialog = new Dialog(this, R.style.ActionSheetDialogStyle);
//
//        tv_tilte.setText("歪猫温馨提醒");
//        if (index == 1) {
//            if (!PreferencesUtils.getBoolean(GoAnswer2Aty.this, "isPublichCheck")) {
//                linlay_check.setVisibility(View.VISIBLE);
//            } else {
//                linlay_check.setVisibility(View.GONE);
//            }
//            tv_tilte.setText("歪猫温馨提醒");
//            tv_no.setText("去检查一下");
//            tv_ok.setText("确认发出");
//            tv_content.setText("喵~ 未防手滑误点，\n请确认录音满意后再发送哦！");
//        } else {
//            linlay_check.setVisibility(View.GONE);
//            tv_tilte.setText("重新录制将会删除此条录音");
//            tv_ok.setText("确认");
//            tv_no.setText("取消");
//            tv_content.setText("喵~ 确定要重新录制么?");
//        }
//        imgv_check.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                if (isCheck == 0) {
//                    imgv_check.setImageResource(R.drawable.ic_public_check);
//                    isCheck = 1;
//                } else {
//                    imgv_check.setImageResource(R.drawable.ic_publish_nochek);
//                    isCheck = 0;
//                }
//            }
//        });
//        tv_no.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                dialog.cancel();
//            }
//        });
//        tv_ok.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                dialog.cancel();
//                if (index == 1) {
//                    if (isCheck == 1) {
//                        PreferencesUtils.putBoolean(GoAnswer2Aty.this, "isPublichCheck", true);
//                    }
//                    startProgressDialog();
//                    ansPro.o(GoAnswer2Aty.this, img_recyPathList, audioFileName, id, GoAnswer2Aty.this);
//                } else {
//                    tv_time.setTextColor(getResources().getColor(R.color.tv_text_gray));
//                    tv_time.setText("点击录音，最多录制120秒");
//                    voiceStatus = 0;
//                    imgv_voice.setImageResource(R.drawable.aio_record_start_nor);
//                    arc2.setVisibility(View.GONE);
//                    musicServices.stopPlaying();
//                    stopRecordAudio();
//                    tv_reset_voice.setVisibility(View.GONE);
//                    tv_ok_voice.setVisibility(View.GONE);
//                }
//            }
//        });
//        dialog.setCanceledOnTouchOutside(false);
//        dialog.setContentView(view);
//        Window window = dialog.getWindow();
//        window.setGravity(Gravity.CENTER);
//        WindowManager.LayoutParams atb = window.getAttributes();
//        atb.width = (int) (getResources().getDisplayMetrics().widthPixels);
//        window.setAttributes(atb);
//        dialog.show();
//    }
//
//    public class HeroseTopRecyclerAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
//        private LayoutInflater inflater;
//        private Context context;
//
//        public HeroseTopRecyclerAdapter(Context context) {
//            inflater = LayoutInflater.from(context);
//            this.context = context;
//        }
//
//        @Override
//        public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
//            View view = null;
//            view = inflater.inflate(R.layout.item_goans, parent, false);
//            return new fGoldViewHolder(view);
//        }
//
//        @Override
//        public void onBindViewHolder(RecyclerView.ViewHolder holder, final int position) {
//
//            fGoldViewHolder fGoldViewHolder = (HeroseTopRecyclerAdapter.fGoldViewHolder) holder;
//
//            if (img_recyList.get(position).equals("1")) {
//                fGoldViewHolder.relay_cha.setVisibility(View.VISIBLE);
//                ImagesUtils.disImgRound2(GoAnswer2Aty.this, img_recyPathList.get(position), fGoldViewHolder.imgv);
//            } else {
//                fGoldViewHolder.imgv.setImageResource(R.drawable.publish_add);
//                fGoldViewHolder.relay_cha.setVisibility(View.GONE);
//            }
//            fGoldViewHolder.relay_cha.setOnClickListener(new View.OnClickListener() {
//                @Override
//                public void onClick(View view) {
//                    img_recyList.clear();
//                    img_recyPathList.remove(position);
//                    for (int i = 0; i < img_recyPathList.size(); i++) {
//                        img_recyList.add("1");
//                    }
//                    img_recyList.add("0");
//                    notifyDataSetChanged();
//                    tv_img_num.setText(img_recyPathList.size() + "/3");
//                }
//            });
//            holder.itemView.setOnClickListener(new View.OnClickListener() {
//                @Override
//                public void onClick(View view) {
//                    if (img_recyList.get(position).equals("0")) {
//                        pickImage();
//                    } else {
//                        Intent intent = new Intent(GoAnswer2Aty.this, PhotoDetails.class);
//                        intent.putStringArrayListExtra("data", img_recyPathList);
//                        intent.putExtra("key", position + "");
//                        GoAnswer2Aty.this.startActivity(intent);
//                    }
//                }
//            });
//
//        }
//
//        @Override
//        public int getItemCount() {
//            return img_recyList.size();
//        }
//
//        @Override
//        public int getItemViewType(int position) {
//            return position;
//        }
//
//        class fGoldViewHolder extends RecyclerView.ViewHolder {
//
//            @ViewInject(R.id.imgv)
//            ImageView imgv;
//            @ViewInject(R.id.relay_cha)
//            RelativeLayout relay_cha;
//
//            public fGoldViewHolder(View itemView) {
//                super(itemView);
//                x.view().inject(this, itemView);
//                AutoUtils.autoSize(itemView);
//            }
//        }
//
//    }
//}

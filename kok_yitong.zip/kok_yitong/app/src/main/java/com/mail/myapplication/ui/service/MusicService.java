package com.mail.myapplication.ui.service;

import android.app.Service;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Binder;
import android.os.Handler;
import android.os.IBinder;

import org.xutils.common.util.LogUtil;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

/**
 * Created by Administrator on 2017/11/13 0013.
 */

public class MusicService extends Service {

    private MediaPlayer mMediaPlayer = null;

    @Override
    public void onCreate() {
        super.onCreate();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return super.onStartCommand(intent, flags, startId);
    }

    @Override
    public void onDestroy() {
        stopPlaying();
        stopSelf();
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return new MyBinder();
    }

    public class MyBinder extends Binder {
        /**
         * 获取Service的方法 * @return 返回PlayerService
         */
        public MusicService getService() {
            return MusicService.this;
        }
    }

    public void startPlaying(String url) {
        LogUtil.e("startPlaying3"+url);
        stopPlaying();
        mMediaPlayer = new MediaPlayer();
        try {
//            mMediaPlayer.setDataSource("http://res.webftp.bbs.hnol.net/zhangyu/music/cd108/07.mp3");
            mMediaPlayer.setDataSource(url);
//            mMediaPlayer.prepare();
            mMediaPlayer.prepareAsync();
//            mSeekBar.setMax(mMediaPlayer.getDuration());
            mMediaPlayer.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
                @Override
                public void onPrepared(MediaPlayer mp) {
                    mMediaPlayer.start();
                    if (mMusicPositionListen != null) {
                        mMusicPositionListen.returnMaxIndex(mMediaPlayer.getDuration());
                    }
                    updateSeekBar();
                }
            });

        } catch (IOException e) {

        }

        mMediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                stopPlaying();
                if (mMusicListen != null) {
                    mMusicListen.playCompletion();
                }
            }
        });
    }

    private MusicListen mMusicListen;
    private MusicPositionListen mMusicPositionListen;

    public void setMusicListen(MusicListen mMusicListen) {
        this.mMusicListen = mMusicListen;
    }

    public void setMusicPositionListen(MusicPositionListen mMusicPositionListen) {
        this.mMusicPositionListen = mMusicPositionListen;
    }

    public interface MusicListen {

        void playCompletion();

    }

    public interface MusicPositionListen {

        void currentPostion(String time, int mCurrentPosition);

        void returnMaxIndex(int maxIndex);

    }

    public void stopPlaying() {
        if (mMediaPlayer != null) {
            mMediaPlayer.stop();
            mMediaPlayer.reset();
            mMediaPlayer.release();
            mMediaPlayer = null;
        }

    }

    private Handler mHandler = new Handler();

    private void updateSeekBar() {
        mHandler.postDelayed(mRunnable, 10);
    }

    //updating mSeekBar
    private Runnable mRunnable = new Runnable() {
        @Override
        public void run() {
            if (mMediaPlayer != null) {
                int mCurrentPosition = mMediaPlayer.getCurrentPosition();
//                mSeekBar.setProgress(mCurrentPosition);

                long minutes = TimeUnit.MILLISECONDS.toMinutes(mCurrentPosition);
                long seconds = TimeUnit.MILLISECONDS.toSeconds(mCurrentPosition)
                        - TimeUnit.MINUTES.toSeconds(minutes);
//                mCurrentProgressTextView.setText(String.format("%02d:%02d", minutes, seconds));

                if (mMusicPositionListen != null) {
                    mMusicPositionListen.currentPostion(String.format("%02d:%02d", minutes, seconds), mCurrentPosition);
                }
                updateSeekBar();
            }
        }
    };

    public void pausePlaying() {
        mHandler.removeCallbacks(mRunnable);
        if (mMediaPlayer != null) {
            mMediaPlayer.pause();
        }
    }

    private String voice_length;

    public void resumePlaying(String url, String voice_length) {
        this.voice_length = voice_length;
        if (mMediaPlayer != null) {
            mHandler.removeCallbacks(mRunnable);
            mMediaPlayer.start();
            updateSeekBar();
        } else {
            startPlaying(url);
        }
    }

}

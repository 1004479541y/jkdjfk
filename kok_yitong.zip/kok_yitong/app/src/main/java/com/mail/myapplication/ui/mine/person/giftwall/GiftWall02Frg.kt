package com.mail.myapplication.ui.mine.person.giftwall

import android.graphics.Color
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.mail.comm.image.ImageLoader
import com.mail.comm.net.AESCBCCrypt
import com.mail.comm.utils.JSONUtils
import com.mail.comm.utils.PreferencesUtils
import com.mail.comm.view.load.XLoadTip
import com.mail.comm.view.refresh.XRefreshInterface
import com.mail.myapplication.BaseXFrg
import com.mail.myapplication.databinding.FrgGiftWall1Binding
import com.mail.myapplication.databinding.FrgGiftWall2Binding
import com.mail.myapplication.databinding.ItemGiftWall1Binding
import com.mail.myapplication.databinding.ItemGiftWall2Binding
import com.mail.myapplication.interfaces.Home
import com.mail.myapplication.ui.mine.person.PersonOtherDetailsAty
import com.yhz.adaptivelayout.utils.AutoUtils
import org.xutils.common.util.LogUtil

class GiftWall02Frg: BaseXFrg() {

    var home = Home()
    lateinit var mBinding: FrgGiftWall2Binding
    var list = ArrayList<MutableMap<String, String>>()
    var list_top = ArrayList<MutableMap<String, String>>()
    var mAdapter: GoldRecyclerAdapter? = null

    var user_code = ""

    var info_code = ""

    override fun getLayoutId() =0

    override fun initView() {
        user_code = arguments?.getString("user_code").toString()
        info_code = PreferencesUtils.getString(requireActivity(),"info_code")
    }

    companion object {

        fun create(user_code: String): GiftWall02Frg {
            val fragment = GiftWall02Frg()
            val bundle = Bundle()
            bundle.putString("user_code", user_code)
            fragment.arguments = bundle
            return fragment
        }

    }

    override fun getLayoutView(): View {
        mBinding = FrgGiftWall2Binding.inflate(layoutInflater);
        return mBinding.root
    }

    override fun requestData() {
        mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.loading)
        home.a68(user_code, this)
    }

    fun requestData2() {
        home.a68(user_code, this)
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)

        var mLayoutManager = GridLayoutManager(requireContext(), 1)
        mLayoutManager.orientation = RecyclerView.VERTICAL
        mBinding.recyclerview.layoutManager = mLayoutManager
        mAdapter = GoldRecyclerAdapter()
        mBinding.recyclerview.adapter = mAdapter

        mBinding.loading.setLoadingTipXReloadCallback(object : XLoadTip.LoadingTipXReloadCallback {
            override fun reload() {
                requestData()
            }
        })

        mBinding.swipeRefreshLayout.setEnableLoadmore(false)
        mBinding.swipeRefreshLayout.setEnableRefresh(true)
        mBinding.swipeRefreshLayout.setXRefreshAndLoadListen(object : XRefreshInterface {
            override fun refreshStart() {
                requestData2()
            }

            override fun loadMoreStart() {
            }

        })

        LogUtil.e("LogUtil=="+user_code+",,"+info_code)

        mBinding.ivHead1.setOnClickListener {
            var bundle = Bundle()
            bundle.putString("user_id",list_top[0]["_id"])
            startActivity(PersonOtherDetailsAty::class.java,bundle)
        }
        mBinding.ivHead2.setOnClickListener {
            var bundle = Bundle()
            bundle.putString("user_id",list_top[1]["_id"])
            startActivity(PersonOtherDetailsAty::class.java,bundle)
        }

        mBinding.ivHead3.setOnClickListener {
            var bundle = Bundle()
            bundle.putString("user_id",list_top[2]["_id"])
            startActivity(PersonOtherDetailsAty::class.java,bundle)
        }

        mBinding.ivHead4.setOnClickListener {
            var bundle = Bundle()
            bundle.putString("user_id",list_top[3]["_id"])
            startActivity(PersonOtherDetailsAty::class.java,bundle)
        }

    }

    override fun onComplete(var2: String?, type: String?) {
        super.onComplete(var2, type)
        mBinding.swipeRefreshLayout.finishRefreshing()
        mBinding.swipeRefreshLayout.finishLoadmore()
        if (type == "gift/rate") {
            var map = JSONUtils.parseKeyAndValueToMap(var2)
            if (map["code"] == "200") {
                mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.finish)
                var str = AESCBCCrypt.aesDecrypt(map["data"])
                var map_data = JSONUtils.parseKeyAndValueToMap(str)
                var map_data_user_rate_info = JSONUtils.parseKeyAndValueToMap(map_data["user_rate_info"])


                if (map_data_user_rate_info!=null&&map_data_user_rate_info.containsKey("my_nick")){
                    mBinding.relay2.visibility = View.VISIBLE

                    mBinding.tvRank.text = map_data_user_rate_info["my_rate"]

                    if (map_data_user_rate_info["my_rate"] =="0"){
                        mBinding.tvRank.text = "未上榜"
                    }

                    mBinding.tvNick.text = map_data_user_rate_info["my_nick"]
                    mBinding.tvVauleMy.text = "对他的贡献值为"+map_data_user_rate_info["my_contribute"]
                    var maxW = AutoUtils.getPercentWidthSizeBigger(400)
                    ImageLoader.loadImageAes(requireActivity(), map_data_user_rate_info["my_avatar"], mBinding.ivHead,maxW,maxW)

                }else{
                    mBinding.relay2.visibility = View.GONE
                }

                if (user_code == info_code){
                    mBinding.relay2.visibility = View.GONE
                }

                list.clear()
                list_top.clear()
                var mList = JSONUtils.parseKeyAndValueToMapList(map_data["data"])
                if (mList != null && mList.size>0){
                    mBinding.relayEmpty.visibility = View.GONE
                    mBinding.swipeRefreshLayout.visibility = View.VISIBLE
                    for ( index in mList.indices){
                        if (index>3){
                            list.add(mList[index])
                        }else{
                            list_top.add(mList[index])
                        }
                    }
                }else{
                    mBinding.relayEmpty.visibility = View.VISIBLE
                    mBinding.swipeRefreshLayout.visibility = View.GONE
                }

                mAdapter?.notifyDataSetChanged()

                if (list_top.size>0){
                    mBinding.relayTop1.visibility = View.VISIBLE
                    var maxW = AutoUtils.getPercentWidthSizeBigger(400)
                    ImageLoader.loadImageAes(requireActivity(), list_top[0]["avatar"], mBinding.ivHead1,maxW,maxW)
                    mBinding.tvNick1.text = list_top[0]["nick"]
                    mBinding.tvCp1.text = "貢獻值"+list_top[0]["count_contribute_num"]
                }

                if (list_top.size>1){
                    mBinding.relayTop2.visibility = View.VISIBLE
                    var maxW = AutoUtils.getPercentWidthSizeBigger(400)
                    ImageLoader.loadImageAes(requireActivity(), list_top[1]["avatar"], mBinding.ivHead2,maxW,maxW)
                    mBinding.tvNick2.text = list_top[1]["nick"]
                    mBinding.tvCp2.text = "貢獻值"+list_top[1]["count_contribute_num"]
                }

                if (list_top.size>2){
                    mBinding.relayTop3.visibility = View.VISIBLE
                    var maxW = AutoUtils.getPercentWidthSizeBigger(400)
                    ImageLoader.loadImageAes(requireActivity(), list_top[2]["avatar"], mBinding.ivHead3,maxW,maxW)
                    mBinding.tvNick3.text = list_top[2]["nick"]
                    mBinding.tvCp3.text = "貢獻值"+list_top[2]["count_contribute_num"]
                }

                if (list_top.size>3){
                    mBinding.relay04.visibility = View.VISIBLE
                    var maxW = AutoUtils.getPercentWidthSizeBigger(400)
                    ImageLoader.loadImageAes(requireActivity(), list_top[3]["avatar"], mBinding.ivHead4,maxW,maxW)
                    mBinding.tvNick4.text = list_top[3]["nick"]
                    mBinding.tvCp4.text = "貢獻值"+list_top[3]["count_contribute_num"]
                }


            }else{
                mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.error)
            }
        }
    }

    override fun onExceptionType(type: String?) {
        super.onExceptionType(type)
        mBinding.swipeRefreshLayout.finishRefreshing()
        mBinding.swipeRefreshLayout.finishLoadmore()
        if (type == "gift/rate"){
            mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.error)
        }
    }

    inner class GoldRecyclerAdapter : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
            return fGoldViewHolder(ItemGiftWall2Binding.inflate(LayoutInflater.from(context)))
        }

        override fun getItemCount(): Int =list.size

        override fun getItemViewType(position: Int): Int {
            return position
        }

        override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {

            if (holder is fGoldViewHolder) {

                with(holder) {

                    with(mBinding) {

                        if (position % 2== 0){
                            relayBg.setBackgroundColor(Color.parseColor("#FFECF2"))
                        }else{
                            relayBg.setBackgroundColor(Color.parseColor("#fdf3f5"))
                        }

                        tvNum.text = (position+5).toString()
                        var maxW = AutoUtils.getPercentWidthSizeBigger(400)
                        ImageLoader.loadImageAes(requireActivity(), list[position]["avatar"], mBinding.ivHead,maxW,maxW)
                        mBinding.tvNick.text = list[position]["nick"]
                        mBinding.tvCp.text = "貢獻值"+list[position]["count_contribute_num"]

                        ivHead.setOnClickListener {
                            var bundle = Bundle()
                            bundle.putString("user_id",list[position]["_id"])
                            startActivity(PersonOtherDetailsAty::class.java,bundle)
                        }

                    }

                }
            }
        }

        inner class fGoldViewHolder(binding: ItemGiftWall2Binding) :
            RecyclerView.ViewHolder(binding.root) {

            var mBinding: ItemGiftWall2Binding = binding

            init {
                AutoUtils.autoSize(binding.root)

            }
        }

    }

}
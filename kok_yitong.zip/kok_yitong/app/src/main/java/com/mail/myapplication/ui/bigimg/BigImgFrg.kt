package com.mail.myapplication.ui.bigimg

import android.graphics.Bitmap
import android.os.Bundle
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.View
import com.mail.comm.image.ImageLoader
import com.mail.comm.view.load.XLoadTip
import com.mail.myapplication.BaseXFrg
import com.mail.myapplication.databinding.FrgBigimgBinding
import com.mail.myapplication.ui.video.PlayListAty
import com.yhz.adaptivelayout.config.AutoLayoutConifg
import org.xutils.common.util.LogUtil

class BigImgFrg : BaseXFrg() {

    lateinit var mBinding: FrgBigimgBinding
    var img = ""
    var img_status = ""

    override fun getLayoutView(): View {
        mBinding = FrgBigimgBinding.inflate(layoutInflater);
        return mBinding.root
    }

    companion object {
        fun create(img: String): BigImgFrg {
            val fragment = BigImgFrg()
            val bundle = Bundle()
            bundle.putString("img", img)
            fragment.arguments = bundle
            return fragment
        }
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        img = arguments?.getString("img").toString()
        loadImg()
        mBinding.loading.setLoadingTipXReloadCallback(object: XLoadTip.LoadingTipXReloadCallback{
            override fun reload() {
                loadImg()
            }
        })

        mBinding.imgv.setOnDoubleTapListener(object : GestureDetector.OnDoubleTapListener{
            override fun onSingleTapConfirmed(p0: MotionEvent?): Boolean {
                if (activity is BigImgListAty){
                    (activity as BigImgListAty).finshPage("3")
                }
                return true
            }

            override fun onDoubleTap(p0: MotionEvent?): Boolean {
                return true
            }

            override fun onDoubleTapEvent(p0: MotionEvent?): Boolean {
                return false
            }

        })
    }

    fun loadImg(){
        mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.loading)
        mBinding.loading.setBackgrouneColorsX("#00000000")
        ImageLoader.loadImageAesCallback(activity,img,object :
            ImageLoader.BimapCallback {
            override fun onLoadSuccess(bitmap: Any?) {
                mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.finish)
                if (bitmap is Bitmap){
                    img_status = "1"
                    mBinding.imgv.setImageBitmap(bitmap)
                }
            }

            override fun onLoadFailed() {
                mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.error)
            }
        })

    }

    override fun getLayoutId(): Int = 0

    override fun initView() {}

    override fun requestData() {}


}
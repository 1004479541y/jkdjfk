package com.mail.myapplication.ui.app

import cn.jpush.android.api.JPushInterface
import com.mail.comm.app.AppConfig
import com.mail.comm.app.BaseApp
import com.tencent.ugc.TXUGCBase
import com.github.moduth.blockcanary.BlockCanary

class MyApp : BaseApp() {

    lateinit var mChatManager: RtmManager

    override fun onCreate() {
        super.onCreate()
        mChatManager = RtmManager(this)
        JPushInterface.setDebugMode(AppConfig.debug)
        JPushInterface.init(this)

        if (AppConfig.debug){
            BlockCanary.install(this, AppBlockCanaryContext()).start()
        }

    }

    fun getChatManager(): RtmManager {
        return mChatManager
    }

    fun initChatIm(){
        mChatManager.init()
    }

    fun initTxVideo(licenceUrl:String,licenseKey:String){
        TXUGCBase.getInstance().setLicence(this, licenceUrl, licenseKey)
    }

}
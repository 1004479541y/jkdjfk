package com.mail.myapplication.ui.wallet

import android.graphics.Color
import android.os.Bundle
import android.view.View
import com.mail.comm.net.AESCBCCrypt
import com.mail.comm.utils.JSONUtils
import com.mail.comm.view.load.XLoadTip
import com.mail.comm.view.refresh.XRefreshInterface
import com.mail.myapplication.BaseXAty
import com.mail.myapplication.R
import com.mail.myapplication.databinding.*
import com.mail.myapplication.interfaces.Lar

class IncomeAty : BaseXAty() {

    lateinit var mBinding: AtyIncomeBinding
    var lar = Lar()

    override fun getLayoutId(): Int = 0

    override fun getLayoutView(): View {
        mBinding = AtyIncomeBinding.inflate(layoutInflater);
        return mBinding.root
    }

    override fun initView() {}

    override fun requestData() {
        mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.loading)
        lar?.b32(this)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        initTopview2(mBinding.include.relayTopBg, resources.getString(R.string.c_4))
        mBinding.include.tvTitle.text = "收益數據"
        mBinding.include.tvRight.text = "收益紀錄"
        mBinding.include.tvRight.setTextColor(Color.parseColor("#66000000"))
        mBinding.include.tvRight.visibility = View.VISIBLE

        mBinding.loading.setLoadingTipXReloadCallback(object : XLoadTip.LoadingTipXReloadCallback {
            override fun reload() {
                requestData()
            }
        })

        mBinding.swipeRefreshLayout.setEnableLoadmore(false)
        mBinding.swipeRefreshLayout.setEnableRefresh(true)
        mBinding.swipeRefreshLayout.setIsPinContentView(true)

        mBinding.swipeRefreshLayout.setXRefreshAndLoadListen(object : XRefreshInterface {
            override fun refreshStart() {
                lar?.b32(this@IncomeAty)
            }

            override fun loadMoreStart() {
            }

        })
    }

    override fun onComplete(var2: String?, type: String?) {
        super.onComplete(var2, type)

        if (type=="creator/profit"){
            stopProgressDialog()
            mBinding.swipeRefreshLayout.finishRefreshing()
            mBinding.swipeRefreshLayout.finishLoadmore()

            var map = JSONUtils.parseKeyAndValueToMap(var2)
            if(map["code"]=="200"){
                mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.finish)

                var str = AESCBCCrypt.aesDecrypt(map["data"])
                var map_data = JSONUtils.parseKeyAndValueToMap(str)
                mBinding.tvForumIncome.text = "+"+map_data["forum_income"]
                mBinding.tvGiftIncome.text = "+"+map_data["gift_income"]
                mBinding.tvGroupIncome.text = "+"+map_data["group_income"]
                mBinding.tvTotalIncome.text = map_data["total_income"]
                mBinding.tvYesterdayTotalIncome.text = "+"+map_data["yesterday_total_income"]

            }else{
                mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.error)
                showToastS(map["message"])
            }
        }

    }

    override fun onExceptionType(type: String?) {
        super.onExceptionType(type)
        stopProgressDialog()
        mBinding.swipeRefreshLayout.finishRefreshing()
        mBinding.swipeRefreshLayout.finishLoadmore()

        if (type=="creator/profit"){
            mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.error)
        }


    }


    fun mainClick(v: View) {

        when (v.id) {

            R.id.relay_back -> {
                finish()
            }

            R.id.tv_apply -> {
                startActivity(WithdrawAty::class.java)
            }

            R.id.tv_right->{
                var bundle = Bundle()
                bundle.putInt("type_index", 2)
                startActivity(WithdrawLogAty::class.java, bundle)
            }

        }
    }



}
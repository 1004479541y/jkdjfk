package com.mail.myapplication.ui.mine.fans

import android.os.Bundle
import android.text.TextUtils
import android.view.View
import android.widget.RelativeLayout
import com.mail.comm.app.AppConfig
import com.mail.comm.app.AppManager
import com.mail.comm.app.BaseApp
import com.mail.comm.net.AESCBCCrypt
import com.mail.comm.utils.JSONUtils
import com.mail.comm.utils.MyUtils2
import com.mail.comm.view.load.XLoadTip
import com.mail.myapplication.BaseXAty
import com.mail.myapplication.R
import com.mail.myapplication.databinding.AtyFansGroupCreateBinding
import com.mail.myapplication.interfaces.Lar
import com.mail.myapplication.ui.mine.person.PersonDetailsAty
import com.yhz.adaptivelayout.utils.AutoUtils

class FansGroupCreateAty:BaseXAty() {

    var title =""
    var month_coins =""
    var season_coins =""
    var year_coins =""
    var lar = Lar()

    lateinit var mBinding: AtyFansGroupCreateBinding

    override fun getLayoutId(): Int =0

    override fun getLayoutView(): View {
        mBinding = AtyFansGroupCreateBinding.inflate(layoutInflater);
        return mBinding.root
    }

    override fun initView() {
    }

    override fun requestData() {
        mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.loading)
        requestData2()
    }

    fun requestData2() {
        lar.b24(this)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setTranslanteBar()
        if (AppConfig.model =="wanou"){
            initTopview2(mBinding.include.relayTopBg, resources.getString(R.string.c_4))
            setAndroidNativeLightStatusBar(false)
            mBinding.include.tvTitle.text = "創建私密團"
        }else{
            setAndroidNativeLightStatusBar(true)
        }

        initLayout()
        mBinding.include.tvTitle.text = ""

        mBinding.loading.setLoadingTipXReloadCallback(object : XLoadTip.LoadingTipXReloadCallback {
            override fun reload() {
                requestData()
            }
        })
    }

    fun initLayout() {
        var params = mBinding.include.relayTopBg.layoutParams as RelativeLayout.LayoutParams
        var StatusBarHeight = MyUtils2.getStateBar(this@FansGroupCreateAty)
        if (StatusBarHeight <= 0) {
            StatusBarHeight = MyUtils2.dip2px(this@FansGroupCreateAty, 20F)
        }
        params.topMargin = StatusBarHeight
        params.height = AutoUtils.getPercentHeightSizeBigger(150)
        mBinding.include.relayTopBg.layoutParams = params
    }


    fun mainClick(v: View) {

        when (v.id) {

            R.id.relay_back -> {
                finish()
            }

            R.id.tv_ok ->{
                title = mBinding.editTitle.text.toString()
                month_coins = mBinding.editMonthCoins.text.toString()
                season_coins = mBinding.editSeasonCoins.text.toString()
                year_coins = mBinding.editYearCoins.text.toString()

                if (TextUtils.isEmpty(title)){
                    showToastS("标题不能为空")
                    return
                }
                if (TextUtils.isEmpty(month_coins)){
                    showToastS("月票金币数不能为空")
                    return
                }
//                if (TextUtils.isEmpty(season_coins)){
//                    showToastS("季票金币数不能为空")
//                    return
//                }
//                if (TextUtils.isEmpty(year_coins)){
//                    showToastS("年票金币数不能为空")
//                    return
//                }
                startProgressDialog()
                lar.b23(title,month_coins,season_coins,year_coins,this)
            }
        }
    }

    override fun onComplete(var2: String?, type: String?) {
        super.onComplete(var2, type)

        if (type=="creator/info"){

            var map = JSONUtils.parseKeyAndValueToMap(var2)
            if (map["code"] == "200") {
                mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.finish)
                var str = AESCBCCrypt.aesDecrypt(map["data"])
                var map_data = JSONUtils.parseKeyAndValueToMap(str)
                mBinding.tvOk.text = map_data["min_fans_group_coins"]+"金币创建私密團"
            }else{
                showToastS(map["message"])
                mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.error)
            }
        }

        if (type=="group/create"){
            stopProgressDialog()
            var map = JSONUtils.parseKeyAndValueToMap(var2)
            if (map["code"] == "200") {
                BaseApp.instance?.saveOneMapData("has_fans_group","y")
                showToastS("创建成功")
                AppManager.getInstance().killActivity(FansGroupDetailsAty::class.java)
                AppManager.getInstance().killActivity(PersonDetailsAty::class.java)
                finish()
            }else{
                showToastS(map["message"])
            }

        }
    }


    override fun onExceptionType(type: String?) {
        super.onExceptionType(type)
        if (type=="group/create"){
            stopProgressDialog()
            mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.error)
        }

        if (type=="creator/info"){
            mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.error)
        }
    }


}
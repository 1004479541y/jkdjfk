package com.mail.myapplication.ui.find

import android.app.Dialog
import android.os.Bundle
import android.view.Gravity
import android.view.View
import com.mail.comm.base.BaseAty
import com.mail.comm.image.ImageLoader
import com.mail.myapplication.R
import com.mail.myapplication.databinding.DgAuthFansBinding
import com.mail.myapplication.databinding.DgMatchVoiceCpBinding
import com.mail.myapplication.databinding.DgMatchVoiceCpRuleBinding
import com.mail.myapplication.databinding.DgMatchVoiceLockBinding
import com.yhz.adaptivelayout.utils.AutoUtils


class MatchVoiceCpRuleDg(context: BaseAty) : Dialog(context) {

    var baseAty = context
    var listener :AuthFansDialogListen? =null
    lateinit var mBinding: DgMatchVoiceCpRuleBinding
    var maxW_head = AutoUtils.getPercentWidthSizeBigger(400)


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        mBinding = DgMatchVoiceCpRuleBinding.inflate(layoutInflater);
        setContentView(mBinding.root)
        window?.setWindowAnimations(R.style.dialogFullscreen2)
        window!!.setBackgroundDrawable(null)
        window!!.setGravity(Gravity.CENTER)
        setCanceledOnTouchOutside(true)
        val m = baseAty.windowManager
        val d = m.defaultDisplay// 获取屏幕宽、高
        val p = window!!.attributes
        window?.getDecorView()?.setPadding(0, 0, 0, 0)
        p.width = (d.width * 1) // 宽度设置为屏幕的0.85
        window!!.attributes = p

        mBinding.tvBack.setOnClickListener {
            dismiss()
        }

    }

    fun setData(cp_rule_content:String,head:String,to_head:String,is_follow:String) {

        if (isShowing){
            ImageLoader.loadImageAes(baseAty,head,mBinding.imgvHead2,maxW_head,maxW_head)
            mBinding.tvRule.text = cp_rule_content
            if (is_follow == "1"){
                ImageLoader.loadImageAes(baseAty,to_head,mBinding.imgvHead,maxW_head,maxW_head)
            }
        }


    }


    interface  AuthFansDialogListen{
        fun onclik01()
        fun onclik02()
        fun onCancel()
    }


    fun setAuthFansDialogListenn(listener:AuthFansDialogListen){
        this.listener =listener
    }

}
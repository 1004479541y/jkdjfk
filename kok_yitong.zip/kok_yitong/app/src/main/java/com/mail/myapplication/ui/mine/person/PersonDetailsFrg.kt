package com.mail.myapplication.ui.mine.person

import android.os.Bundle
import android.text.TextUtils
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.mail.comm.image.ImageLoader
import com.mail.comm.net.AESCBCCrypt
import com.mail.comm.utils.JSONUtils
import com.mail.comm.utils.MyUtils
import com.mail.comm.utils.PreferencesUtils
import com.mail.comm.view.load.XLoadTip
import com.mail.myapplication.BaseXFrg
import com.mail.myapplication.databinding.FrgPersonDetailsBinding
import com.mail.myapplication.databinding.ItemPeisonDetailsGiftBinding
import com.mail.myapplication.databinding.ItemPersonDetails1Binding
import com.mail.myapplication.interfaces.Home
import com.mail.myapplication.interfaces.Lar
import com.yhz.adaptivelayout.utils.AutoUtils
import org.xutils.common.util.LogUtil
import java.util.HashMap

class PersonDetailsFrg:BaseXFrg() {

    lateinit var mBinding: FrgPersonDetailsBinding

    var mAdapter: GoldRecyclerAdapter? = null
    var mAdapter2: GoldRecyclerAdapter2? = null
    var list_habit = ArrayList<String>()
    var list_wall = ArrayList<MutableMap<String,String>>()
    var home = Home()
    var lar = Lar()
    var user_code = ""
    var map_info: MutableMap<String, String>? = null

    override fun getLayoutId()=0

    override fun initView() {
        user_code= PreferencesUtils.getString(requireActivity(), "info_code")
    }

    override fun requestData() {
        mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.loading)
        home.a66(user_code, this)
    }

    fun requestDataInfo(){
        lar.b6(this)
    }

    override fun getLayoutView(): View {
        mBinding = FrgPersonDetailsBinding.inflate(layoutInflater);
        return mBinding.root
    }

    override fun onResume() {
        super.onResume()
        initMyInfo()
    }

    override fun onComplete(var2: String?, type: String?) {
        super.onComplete(var2, type)
        if (type == "gift/wall") {
            var map = JSONUtils.parseKeyAndValueToMap(var2)
            if (map["code"] == "200") {
                requestDataInfo()
                var str = AESCBCCrypt.aesDecrypt(map["data"])
                list_wall.clear()
                var mList = JSONUtils.parseKeyAndValueToMapList(str)
                if (mList != null && mList.size>0){
                    list_wall.addAll(mList)
                }
                mBinding.tvNum.text = "点亮${list_wall.size}"
                mAdapter2?.notifyDataSetChanged()
            }else{
                mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.error)
            }
        }

        if (type == "user/info") {

            var map = JSONUtils.parseKeyAndValueToMap(var2)
            if (map["code"] == "200") {
                mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.finish)

                var str_info = AESCBCCrypt.aesDecrypt(map["data"])
                map_info = JSONUtils.parseKeyAndValueToMap(str_info)
                MyUtils.saveMyInfo(requireActivity(), map_info as HashMap<String, String>)

                initMyInfo()
            }else{
                mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.error)
            }
        }
    }

    override fun onExceptionType(type: String?) {
        super.onExceptionType(type)
        if (type == "gift/wall"){
            mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.error)
        }
        if (type == "user/info"){
            mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.error)
        }
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        var mLayoutManager = LinearLayoutManager(requireContext())
        mLayoutManager.orientation = RecyclerView.HORIZONTAL
        mBinding.recyclerview.layoutManager = mLayoutManager
        mAdapter = GoldRecyclerAdapter()
        mBinding.recyclerview.adapter = mAdapter
        mBinding.recyclerview.isNestedScrollingEnabled = false
        initGift()


        mBinding.loading.setLoadingTipXReloadCallback(object : XLoadTip.LoadingTipXReloadCallback {
            override fun reload() {
                requestData()
            }
        })
    }

    fun initGift(){
        var mLayoutManager = LinearLayoutManager(requireContext())
        mLayoutManager.orientation = RecyclerView.HORIZONTAL
        mBinding.recyclerview2.layoutManager = mLayoutManager
        mAdapter2 = GoldRecyclerAdapter2()
        mBinding.recyclerview2.adapter = mAdapter2
        mBinding.recyclerview2.isNestedScrollingEnabled = false
    }

    fun initMyInfo() {

        with(mBinding) {

            var xacty = requireContext()
            var info_intro = PreferencesUtils.getString(xacty, "info_intro")
            var info_city = PreferencesUtils.getString(xacty, "info_city")
            var info_years = PreferencesUtils.getString(xacty, "info_years")
            var info_job = PreferencesUtils.getString(xacty, "info_job")

            mBinding.tvIntro.text = "${info_intro}"
            mBinding.tvCity.text = "地址：${info_city}"
            mBinding.tvJob.text = "職業：${info_job}"
            mBinding.tvBirth.text = "年龄：${info_years}"

            if (map_info!=null&&map_info!!.containsKey("has_fans_group")){

                var has_fans_group = map_info!!["has_fans_group"].toString()

                if (has_fans_group == "y"){
                    mBinding.tvHasFansGroup.text = "进入圈子>>"
                }else{
                    mBinding.tvHasFansGroup.text = "创建圈子>>"
                }

            }

            if (TextUtils.isEmpty(info_intro)) {
                mBinding.tvIntro.text = "暂无签名"
            }

            var info_habit = PreferencesUtils.getString(xacty, "info_habit")
            var str = info_habit.split(",")
            list_habit.clear()

            if (str != null && str.size > 0 && !TextUtils.isEmpty(info_habit)) {
                for (str in str) {
                    list_habit.add(str)
                }
            }

            if (list_habit.size == 0){
                mBinding.tvSign.visibility = View.GONE
                mBinding.recyclerview.visibility = View.GONE
            }else{
                mBinding.tvSign.visibility = View.VISIBLE
                mBinding.recyclerview.visibility = View.VISIBLE
            }

            mAdapter?.notifyDataSetChanged()

        }

    }


    inner class GoldRecyclerAdapter : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
            return fGoldViewHolder(ItemPersonDetails1Binding.inflate(LayoutInflater.from(context)))
        }

        override fun getItemCount(): Int = list_habit.size

        override fun getItemViewType(position: Int): Int {
            return position
        }

        override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {

            if (holder is fGoldViewHolder) {

                with(holder) {
                    with(mBinding) {
                        tvName.text = list_habit[position]
                    }
                }

            }

        }

        inner class fGoldViewHolder(binding: ItemPersonDetails1Binding) :
            RecyclerView.ViewHolder(binding.root) {
            var mBinding: ItemPersonDetails1Binding = binding

            init {
                AutoUtils.autoSize(binding.root)

            }
        }

    }


    inner class GoldRecyclerAdapter2 : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
            return fGoldViewHolder(ItemPeisonDetailsGiftBinding.inflate(LayoutInflater.from(context)))
        }

        override fun getItemCount(): Int = list_wall.size

        override fun getItemViewType(position: Int): Int {
            return position
        }

        override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {

            if (holder is fGoldViewHolder) {

                with(holder) {
                    with(mBinding) {
                        var map = list_wall[position]
                        var maxW = AutoUtils.getPercentWidthSizeBigger(200)
                        ImageLoader.loadImageAes(requireActivity(), map["gift_cover"], imgv,maxW,maxW)
                        tvName.text = map["title"]
                        tvNum.text = "x"+map["num"]
                    }
                }

            }

        }

        inner class fGoldViewHolder(binding: ItemPeisonDetailsGiftBinding) :
            RecyclerView.ViewHolder(binding.root) {
            var mBinding: ItemPeisonDetailsGiftBinding = binding

            init {
                AutoUtils.autoSize(binding.root)

            }
        }

    }


}
package com.mail.myapplication.ui.voice;

/**
 * Created by clam314 on 2016/7/21
 */
public interface MediaRecorderListener {

    public void onRecorderFinish(int status, String path);
}

package com.mail.myapplication.ui.mine.apply

import android.os.Bundle
import android.view.View
import com.mail.myapplication.BaseXAty
import com.mail.myapplication.R
import com.mail.myapplication.databinding.AtyAuthFinishBinding

class AuthFinishAty : BaseXAty() {

    lateinit var mBinding: AtyAuthFinishBinding

    override fun getLayoutId(): Int = 0

    override fun initView() {}

    override fun requestData() {}

    override fun getLayoutView(): View {
        mBinding = AtyAuthFinishBinding.inflate(layoutInflater);
        return mBinding.root
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        with(mBinding){
            initTopview2(include.relayTopBg,getString(R.string.c_9))
            include.tvTitle.text = ""
        }
    }

    fun mainClick(v: View) {

        when (v.id) {

            R.id.relay_back -> {
                finish()

            }

            R.id.tv_ok -> {
              finish()
            }

        }
    }


}
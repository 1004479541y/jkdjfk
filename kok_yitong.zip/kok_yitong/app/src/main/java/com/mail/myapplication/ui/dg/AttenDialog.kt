package com.mail.myapplication.ui.dg

import android.app.Dialog
import android.os.Bundle
import android.view.Gravity
import com.mail.comm.base.BaseAty
import com.mail.comm.base.BaseDialog
import com.mail.comm.net.AESCBCCrypt
import com.mail.comm.utils.JSONUtils
import com.mail.comm.view.load.XLoadTip
import com.mail.myapplication.R
import com.mail.myapplication.databinding.DgAttenBinding
import com.mail.myapplication.databinding.DgBindPhoneBinding
import com.mail.myapplication.interfaces.Lar
import com.mail.myapplication.ui.MainWalletAty
import org.xutils.common.util.LogUtil


class AttenDialog(context: BaseAty) : BaseDialog(context) {

    var listener :AttenDialogListen? =null
    lateinit var mBinding: DgAttenBinding
    var info = ""
    var lar = Lar()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        mBinding = DgAttenBinding.inflate(layoutInflater);
        setContentView(mBinding.root)
        window?.setWindowAnimations(R.style.dialogFullscreen2)

        window!!.setBackgroundDrawable(null)
        window!!.setGravity(Gravity.CENTER)
        setCanceledOnTouchOutside(false)
        val m = baseAty.windowManager
        val d = m.defaultDisplay// 获取屏幕宽、高
        val p = window!!.attributes
        window?.getDecorView()?.setPadding(0, 0, 0, 0)
//        p.height =  (d.height * 1) // 高度设置为屏幕的0.6
        p.width = (d.width * 1) // 宽度设置为屏幕的0.85
        window!!.attributes = p

        mBinding.tv01.setOnClickListener {
            listener?.onclik01()
            dismiss()
        }

        mBinding.tv02.setOnClickListener {
            dismiss()
            listener?.onclik02()
        }

        mBinding.tvCoins.setOnClickListener {
            dismiss()
            var bundle = Bundle()
            bundle.putString("page_type", "pay")
            (baseAty as BaseAty).startActivity(MainWalletAty::class.java, bundle)
        }
    }

    interface  AttenDialogListen{
        fun onclik01()
        fun onclik02()
    }

    fun requestData(min_unfollow_coins:String) {
        if (isShowing) {
            lar.b10(this)
            mBinding.tvContent.text = "了解對方更多內容，需解鎖關注，只需${min_unfollow_coins}金幣即可解鎖。"
        }
    }

    fun setAttenDialogListen(listener:AttenDialogListen){
        this.listener =listener
    }

    override fun onComplete(var2: String?, type: String?) {
        super.onComplete(var2, type)

        if (type == "wallet/info") {
            var map = JSONUtils.parseKeyAndValueToMap(var2)
            if (map["code"] == "200") {
                var str_wallet = AESCBCCrypt.aesDecrypt(map["data"])
                var map_info = JSONUtils.parseKeyAndValueToMap(str_wallet)
                mBinding.tvCoins.text = "金幣餘額：${map_info["coins"]} 立即充值>>"
            }
        }

    }


    override fun onExceptionType(type: String?) {
        super.onExceptionType(type)
    }

}
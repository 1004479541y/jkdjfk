package com.mail.myapplication.ui

import android.content.ComponentName
import android.content.Intent
import android.content.ServiceConnection
import android.os.Bundle
import android.os.Environment
import android.os.IBinder
import android.view.View
import android.widget.Toast
import androidx.lifecycle.lifecycleScope
import com.mail.comm.app.AppConfig
import com.mail.comm.utils.FileSizeUtil
import com.mail.comm.utils.TimeUtils
import com.mail.myapplication.BaseXAty
import com.mail.myapplication.R
import com.mail.myapplication.databinding.AtyTestBinding
import com.mail.myapplication.ui.service.MusicService
import com.mail.myapplication.ui.voice.MediaRecorderListener
import com.zlw.main.recorderlib.RecordManager
import com.zlw.main.recorderlib.recorder.RecordConfig
import com.zlw.main.recorderlib.recorder.RecordHelper.RecordState
import com.zlw.main.recorderlib.recorder.listener.RecordResultListener
import com.zlw.main.recorderlib.recorder.listener.RecordSoundSizeListener
import com.zlw.main.recorderlib.recorder.listener.RecordStateListener
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.xutils.common.util.LogUtil
import java.io.File
import java.util.*
import kotlin.collections.ArrayList

class TestAty : BaseXAty(), MusicService.MusicListen, MusicService.MusicPositionListen,

    MediaRecorderListener {

    lateinit var mBinding: AtyTestBinding
    var list = ArrayList<MutableMap<String, String>>()

    var voiceStatus = 0
    var timer: Timer? = null
    var timerTask: TimerTask? = null
    var audioFileName: String? = null
    var recordTotalTime = 0L

    var maxRecordTime = 120000L
    var DEFAULT_MIN_TIME_UPDATE_TIME = 1000
    var startPriceTime: Long = 0
    var currentPriceTime: Long = 0

    var mMusicService: MusicService? = null
    var mIntent: Intent? = null
    var seekBarMaxIndex = 0
    var bastPath: String? = null

    //     0没有录音
    //     1正在录音
    //     2录音完成
    //     3正在播放

    override fun getLayoutId(): Int = 0

    override fun initView() {}

    override fun requestData() {}

    override fun getLayoutView(): View {
        mBinding = AtyTestBinding.inflate(layoutInflater)
        return mBinding.root
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
//        LameMp3Manager.instance.setMediaRecorderListener(this)
        bastPath = getBasePath()

        mIntent = Intent(this, MusicService::class.java)
        startService(mIntent)
        bindService(mIntent, serviceConnection, BIND_AUTO_CREATE)
        initRecord()

    }

    private fun initRecord() {
        RecordManager.getInstance().init(application,AppConfig.debug)
        RecordManager.getInstance().changeFormat(RecordConfig.RecordFormat.MP3)

        val recordDir = String.format(Locale.getDefault(), "%s/Record/${packageName}/",
            Environment.getExternalStorageDirectory().absolutePath)
        RecordManager.getInstance().changeRecordDir(recordDir)

        RecordManager.getInstance().setRecordSoundSizeListener(RecordSoundSizeListener { soundSize ->
            mBinding.tvSize.text = String.format(Locale.getDefault(), "声音大小：%s db", soundSize)
        })

        RecordManager.getInstance().setRecordResultListener(RecordResultListener { result ->

            audioFileName = result.absolutePath
            var file_name = FileSizeUtil.getAutoFileOrFilesSize(audioFileName)

            LogUtil.e("file_name="+file_name)
//            Toast.makeText(this, "录音文件： " + result.absolutePath, Toast.LENGTH_SHORT).show()
        })

        RecordManager.getInstance().setRecordStateListener(object : RecordStateListener {
            override fun onStateChange(state: RecordState) {

                LogUtil.e("RecordManager="+state.name)
                when (state) {
                    RecordState.PAUSE -> mBinding.tvStatus.text = "暂停中"
                    RecordState.IDLE -> mBinding.tvStatus.setText("空闲中")
                    RecordState.RECORDING -> mBinding.tvStatus.setText("录音中")
                    RecordState.STOP -> mBinding.tvStatus.setText("停止")
                    RecordState.FINISH -> {
                        mBinding.tvStatus.setText("录音结束")
//                        tvSoundSize.setText("---")
                    }
                    else -> {
                    }
                }
            }

            override fun onError(error: String) {
                LogUtil.e("RecordManager=onError"+error)

            }
        })

    }

    fun getBasePath(): String? {
        var strPath: String? = null
        strPath = if (Environment.getExternalStorageState() != Environment.MEDIA_MOUNTED) {
            this.filesDir.toString() + "/" + "lameMp3"
        } else {
            Environment.getExternalStorageDirectory().toString() + "/" + "lameMp3"
        }
        val dir = File(strPath)
        if (!dir.exists()) {
            dir.mkdirs()
        }
        return strPath
    }

    fun mainClick(v: View) {

        when (v.id) {

            R.id.tv_reset_voice -> {
                mBinding.tvTime.text = "点击录音，最多录制120秒"
                voiceStatus = 0
                mBinding.imgvVoice.setImageResource(R.drawable.aio_record_start_nor)
                mBinding.arc2.visibility = View.GONE
                mMusicService?.stopPlaying()
                stopRecordAudio()
                mBinding.tvResetVoice.visibility = View.GONE
                mBinding.tvOkVoice.visibility = View.GONE
            }

            R.id.tv_ok_voice -> {

            }

            R.id.imgv_voice -> {

                when (voiceStatus) {

                    0 -> {
                        voiceStatus = 1
                        mBinding.arc2.visibility = View.VISIBLE
                        mBinding.imgvVoice.setImageResource(R.drawable.aio_record_stop)
                        onRecordStart()
                    }

                    1 -> {
                        voiceStatus = 2
                        stopRecordAudio()
                        mBinding.imgvVoice.setImageResource(R.drawable.aio_record_play_nor)
                    }

                    2 -> {
                        mBinding.arc2.progress = 0
                        LogUtil.e("startPlaying0"+audioFileName)
                        if (mMusicService == null){
                            LogUtil.e("startPlaying1"+audioFileName)

                        }
                        mMusicService?.startPlaying(audioFileName)
                        voiceStatus = 3
                        mBinding.imgvVoice.setImageResource(R.drawable.aio_record_stop)
                    }

                    3 -> {
                        voiceStatus = 2
                        mMusicService?.stopPlaying()
                        mBinding.tvResetVoice.visibility = View.VISIBLE
                        mBinding.tvOkVoice.visibility = View.VISIBLE
                        mBinding.imgvVoice.setImageResource(R.drawable.aio_record_play_nor)
                    }
                }
            }
        }
    }

    fun onRecordStart() {
        recordTotalTime = 0
        startPriceTime = System.currentTimeMillis()
        mBinding.tvTime.setTextColor(resources.getColor(R.color.main_color))
        initTimer()
        timer?.schedule(timerTask, 0, DEFAULT_MIN_TIME_UPDATE_TIME.toLong())
        startRecordAudio()
    }

    fun startRecordAudio() {
        RecordManager.getInstance().start()
//        LameMp3Manager.instance.startRecorder(bastPath + File.separator + "lame.mp3")
    }

    fun cancelTimer() {
        timer?.cancel()
        timer = null
        timerTask?.cancel()
        timerTask = null
    }

    fun initTimer() {
        cancelTimer()
        timer = Timer()
        timerTask = object : TimerTask() {
            override fun run() {
                lifecycleScope.launch {
                    withContext(Dispatchers.Main) {
                        updateTimerUI()
                    }
                }
            }
        }
    }

    fun updateTimerUI() {
        currentPriceTime = System.currentTimeMillis()
        recordTotalTime = currentPriceTime - startPriceTime

        val l = recordTotalTime / maxRecordTime.toFloat()
        mBinding.arc2.progress = (l * 100).toInt()
        val s: String = TimeUtils.formatSecond7((recordTotalTime / 1000).toDouble())
        mBinding.tvTime.text = s

        if (recordTotalTime >= maxRecordTime) {
            voiceStatus = 2
            stopRecordAudio()
            mBinding.imgvVoice.setImageResource(R.drawable.aio_record_play_nor)
        }
    }

    /**
     * 停止录音
     */
    fun stopRecordAudio() {
        try {
            cancelTimer()
            currentPriceTime = System.currentTimeMillis()
            recordTotalTime = currentPriceTime - startPriceTime
            if (recordTotalTime >= maxRecordTime) {
                recordTotalTime = maxRecordTime
            }
//            LameMp3Manager.instance.stopRecorder()
            RecordManager.getInstance().stop()

            mBinding.tvResetVoice.visibility = View.VISIBLE
            mBinding.tvOkVoice.visibility = View.VISIBLE
//            if (timer != null) {
//                timer!!.cancel()
//            }
        } catch (e: Exception) {
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        if (serviceConnection != null) {
            unbindService(serviceConnection) // 解除绑定，断开连接
            stopService(mIntent)
        }
    }

    var serviceConnection: ServiceConnection = object : ServiceConnection {
        override fun onServiceConnected(componentName: ComponentName, iBinder: IBinder) {
            val binder: MusicService.MyBinder = iBinder as MusicService.MyBinder
            mMusicService = binder.service // 获取到的Service即MyService
            mMusicService?.setMusicListen(this@TestAty)
            mMusicService?.setMusicPositionListen(this@TestAty)
        }

        override fun onServiceDisconnected(componentName: ComponentName) {}
    }

    override fun playCompletion() {
        voiceStatus = 2
        mBinding.imgvVoice.setImageResource(R.drawable.aio_record_play_nor)
        if (recordTotalTime == maxRecordTime) {
            mBinding.arc2.progress = 100
        }
    }

    override fun currentPostion(time: String?, mCurrentPosition: Int) {
        val l = mCurrentPosition / seekBarMaxIndex.toFloat()
        mBinding.arc2.progress = (l * 100).toInt()
    }

    override fun returnMaxIndex(maxIndex: Int) {
        seekBarMaxIndex = ((maxIndex * maxRecordTime / recordTotalTime).toInt())
    }

    override fun onRecorderFinish(status: Int, path: String?) {
    }

}
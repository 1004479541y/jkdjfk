package com.mail.myapplication.ui.dg

import android.app.Dialog
import android.os.Bundle
import android.view.Gravity
import android.view.View
import com.mail.comm.base.BaseAty
import com.mail.myapplication.R
import com.mail.myapplication.databinding.DgAuthFansBinding
import com.mail.myapplication.databinding.DgGiftInfoBinding


class GiftInfoDialog(context: BaseAty) : Dialog(context) {

    var baseAty = context
    lateinit var mBinding: DgGiftInfoBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        mBinding = DgGiftInfoBinding.inflate(layoutInflater);
        setContentView(mBinding.root)
        window?.setWindowAnimations(R.style.dialogFullscreen2)
        window!!.setBackgroundDrawable(null)
        window!!.setGravity(Gravity.CENTER)
        setCanceledOnTouchOutside(true)
        val m = baseAty.windowManager
        val d = m.defaultDisplay// 获取屏幕宽、高
        val p = window!!.attributes
        window?.getDecorView()?.setPadding(0, 0, 0, 0)
        p.width = (d.width * 1) // 宽度设置为屏幕的0.85
        window!!.attributes = p

        mBinding.imgvCancel.setOnClickListener {
            dismiss()
        }

    }

    fun setData(info: String,title:String) {
        if (isShowing){
            mBinding.tvContent.text = info
            mBinding.tvTitle.text = title+"玩法介绍"
        }
    }

    fun setData2(info: String,title:String) {
        if (isShowing){
            mBinding.tvContent.text = info
            mBinding.tvTitle.text = title+"玩法介绍"
        }
    }


}
package com.mail.myapplication.ui.mine.person.cp

import android.os.Bundle
import android.text.TextUtils
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.mail.comm.app.AppManager
import com.mail.comm.app.BaseApp
import com.mail.comm.image.ImageLoader
import com.mail.comm.net.AESCBCCrypt
import com.mail.comm.utils.JSONUtils
import com.mail.comm.utils.PreferencesUtils
import com.mail.comm.utils.TimeUtils
import com.mail.comm.view.load.XLoadTip
import com.mail.comm.view.refresh.XRefreshInterface
import com.mail.myapplication.BaseXAty
import com.mail.myapplication.R
import com.mail.myapplication.databinding.*
import com.mail.myapplication.interfaces.Home
import com.mail.myapplication.ui.dg.GiftInfoDialog
import com.mail.myapplication.ui.mine.person.PersonOtherDetailsAty
import com.mail.myapplication.ui.msg.chat.ChatAty
import com.mail.myapplication.ui.msg.database.ChatUtils
import com.mail.myapplication.ui.utils.MyUtils3
import com.yhz.adaptivelayout.utils.AutoUtils
import io.agora.rtm.ErrorInfo
import io.agora.rtm.ResultCallback
import io.agora.rtm.RtmMessage
import io.agora.rtm.RtmStatusCode
import org.xutils.common.util.LogUtil

class PersonCpAty : BaseXAty() {

    var home = Home()
    var list = ArrayList<MutableMap<String, String>>()

    var index_check = -1
    lateinit var mBinding: AtyPersonCpBinding
    lateinit var mAdapter2: GoldRecyclerAdapter2
    var mPersonCpDg: PersonCpDg?=null
    var user_code = ""

    var to_user_nick = ""
    var to_user_code = ""
    var to_user_avatar = ""

    var info_nick = ""
    var info_code = ""
    var info_avatar = ""
    var info_gender = ""

    var cp_user_nick ="cp"
    var cp_user_code = ""

    var room_id =""
    var min_cp_value =0
    var cp_value =0
    var cp_play_rule =""

    var mGiftInfoDialog: GiftInfoDialog? =null


    override fun getLayoutId(): Int = 0

    override fun initView() {
        info_avatar = PreferencesUtils.getString(this, "info_avatar")
        info_nick = PreferencesUtils.getString(this, "info_nick")
        info_code = PreferencesUtils.getString(this, "info_code")
        user_code = intent.getStringExtra("user_code").toString()
        info_gender = BaseApp.instance?.getOneMapData("info_gender").toString()
//        enter_type = intent.getStringExtra("enter_type").toString()
    }

    override fun requestData() {
        mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.loading)
        home.a72(user_code,this)
    }

    fun requestData2() {
//      home.a29(page,this)
    }

    override fun getLayoutView(): View {
        mBinding = AtyPersonCpBinding.inflate(layoutInflater);
        return mBinding.root
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        initIm()
        with(mBinding){
            initTopview2(include.relayTopBg, resources.getString(R.string.c_4))
            include.tvTitle.text = "CP榜"

            var mLayoutManager2 = GridLayoutManager(this@PersonCpAty,1)
            mLayoutManager2.orientation = RecyclerView.VERTICAL
            recyclerview2.layoutManager =mLayoutManager2
            mAdapter2 = GoldRecyclerAdapter2()
            recyclerview2.adapter = mAdapter2

            loading.setLoadingTipXReloadCallback(object: XLoadTip.LoadingTipXReloadCallback{
                override fun reload() {
                    requestData()
                }
            })

            var maxW = AutoUtils.getPercentWidthSizeBigger(500)
            ImageLoader.loadImageAes(this@PersonCpAty,info_avatar,imgvHeadMy,maxW,maxW)

            if (info_code == user_code){
                mBinding.relay2.visibility = View.GONE
            }else{
                mBinding.relay2.visibility = View.VISIBLE
            }

            when (info_gender) {

                "1" -> {
                    mBinding.tvGender.text = "1"
                    mBinding.linlayGender.setBackgroundResource(R.drawable.shape_77)
                }

                "0" -> {
                    mBinding.tvGender.text = "0"
                    mBinding.linlayGender.setBackgroundResource(R.drawable.shape_78)
                }

                "10" -> {
                    mBinding.tvGender.text = "10"
                    mBinding.linlayGender.setBackgroundResource(R.drawable.shape_79)
                }

                else -> {
                    mBinding.linlayGender.visibility = View.GONE
                }

            }
        }
    }

    fun mainClick(v: View) {

        when (v.id) {

            R.id.v_rule ->{

                if (mGiftInfoDialog == null){
                    mGiftInfoDialog = GiftInfoDialog(this)
                }
                mGiftInfoDialog?.show()
                mGiftInfoDialog?.setData2(cp_play_rule,"CP")
            }

            R.id.relay_back -> {
                finish()
            }

            R.id.relay_cp ->{

                if (!TextUtils.isEmpty(cp_user_nick)&&cp_user_nick!="null"){
                    var bundle = Bundle()
                    bundle.putString("user_code",user_code)
                    bundle.putString("room_id",room_id)
                    startActivity(PersonCpDetailsAty::class.java,bundle)
                    return
                }
            }

            R.id.linlay_cp ->{

                if (!TextUtils.isEmpty(cp_user_nick)&&cp_user_nick!="null"){
//                    var bundle = Bundle()
//                    bundle.putString("user_code",user_code)
//                    bundle.putString("room_id",room_id)
//                    startActivity(PersonCpDetailsAty::class.java,bundle)
                    var bundle = Bundle()
                    bundle.putString("user_id",cp_user_code)
                    startActivity(PersonOtherDetailsAty::class.java,bundle)
                    return
                }

                if (info_code == user_code){
                    return
                }

                if (min_cp_value>cp_value){
                    showCommonDialog("1012",true,"CP值${min_cp_value}才可以處CP哦\n趕緊互動提高CP值吧"
                    ,"","确定")
//                    var bundle = Bundle()
//                    bundle.putString("code", to_user_code)
//                    bundle.putString("nick", to_user_nick)
//                    bundle.putString("avatar", to_user_avatar)
//                    bundle.putString("is_send_pic", "0")
//                    AppManager.getInstance().killActivity(ChatAty::class.java)
//                    startActivity(ChatAty::class.java, bundle)
                    return
                }

                if (mPersonCpDg == null){
                    mPersonCpDg = PersonCpDg(this)
                }

                mPersonCpDg?.show()
                mPersonCpDg?.setDataHead(to_user_avatar,info_avatar)
                mPersonCpDg?.requestData()

                mPersonCpDg?.setPersonCpDgListen(object : PersonCpDg.PersonCpDgListen{

                    override fun buyCp(id: String) {
                        startProgressDialog()
                        home.a74(id,user_code,this@PersonCpAty)
                    }

                })

            }

            R.id.imgv_cp ->{

                if (info_code == user_code){
                    return
                }

                if (min_cp_value>cp_value){
                    var bundle = Bundle()
                    bundle.putString("code", to_user_code)
                    bundle.putString("nick", to_user_nick)
                    bundle.putString("avatar", to_user_avatar)
                    bundle.putString("is_send_pic", "0")
                    AppManager.getInstance().killActivity(ChatAty::class.java)
                    startActivity(ChatAty::class.java, bundle)
                    return
                }

                if (mPersonCpDg == null){
                    mPersonCpDg = PersonCpDg(this)
                }

                mPersonCpDg?.show()
                mPersonCpDg?.setDataHead(to_user_avatar,info_avatar)
                mPersonCpDg?.requestData()

                mPersonCpDg?.setPersonCpDgListen(object : PersonCpDg.PersonCpDgListen{

                    override fun buyCp(id: String) {
                        startProgressDialog()
                        home.a74(id,user_code,this@PersonCpAty)
                    }

                })
            }
        }
    }

    /**
     * API CALL: send message to peer
     */
    fun sendPeerMessage(message: RtmMessage) {
        mRtmClient?.sendMessageToPeer(to_user_code, message, mChatManager?.getSendMessageOptions(),
            object : ResultCallback<Void?> {
                override fun onSuccess(aVoid: Void?) {


                }

                override fun onFailure(errorInfo: ErrorInfo) {

                }
            })
    }


    override fun onComplete(var2: String?, type: String?) {
        super.onComplete(var2, type)

        if (type == "cp/purchase"){
            stopProgressDialog()
            var map = JSONUtils.parseKeyAndValueToMap(var2)
            showToastS(map["message"])
            if (map["code"] == "200") {
                requestData()
                var str = AESCBCCrypt.aesDecrypt(map["data"])
                var map_data = JSONUtils.parseKeyAndValueToMap(str)

                var time = TimeUtils.getBeijinTime()

                var json = MyUtils3.getCpMsg(
                    to_user_code, to_user_avatar, to_user_nick,
                    info_code, info_avatar, info_nick,
                    map_data["cover"],  map_data["svaga"], map_data["gift_id"],
                    map_data["title"], "2",
                    "送你一个${map_data!!["title"]}","我想跟你处CP",
                    "","cp_love",
                    time, map_data["message_id"])

                var message_gift = mRtmClient?.createMessage()
                message_gift?.text = json
                if (message_gift != null) {
                    sendPeerMessage(message_gift)
                }

            }
        }

        if (type== "cp/list"){

            mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.finish)
            var map = JSONUtils.parseKeyAndValueToMap(var2)
            if (map["code"] == "200") {
                var str = AESCBCCrypt.aesDecrypt(map["data"])
                var map_data = JSONUtils.parseKeyAndValueToMap(str)

                cp_play_rule = map_data["cp_play_rule"].toString()

                to_user_nick = map_data["to_user_nick"].toString()
                to_user_code = map_data["to_user_code"].toString()
                to_user_avatar = map_data["to_user_avatar"].toString()

                mBinding.tvName1.text = to_user_nick

                cp_user_code = map_data["cp_user_code"].toString()
                room_id = map_data["room_id"].toString()
                min_cp_value = map_data["min_cp_value"].toString().toInt()

                var maxW = AutoUtils.getPercentWidthSizeBigger(400)
                ImageLoader.loadImageAes(this, to_user_avatar, mBinding.ivHead1,maxW,maxW)

                if (!TextUtils.isEmpty(map_data["cp_user_nick"])&&map_data["cp_user_nick"] != "null"){
                    cp_user_nick = map_data["cp_user_nick"].toString()
                    mBinding.tvName2.text = cp_user_nick
                    ImageLoader.loadImageAes(this, map_data["cp_user_avatar"], mBinding.ivHead2,maxW,maxW)
                }else{
                    cp_user_nick = ""
                }

                if (map_data["cp_value"] == "0"){
                    mBinding.tvRank.text = "未上榜"
                }else{
                    mBinding.tvRank.text = map_data["rate"]
                }

                cp_value = map_data["cp_value"].toString().toInt()

                if (cp_value>min_cp_value){
                    mBinding.imgvCp.setImageResource(R.drawable.ia_31)
                }else{
                    mBinding.imgvCp.setImageResource(R.drawable.ia_70)
                }
                mBinding.tvNick.text = info_nick

                mBinding.tvCpValue.text = "CP值${map_data["cp_value"]}"

                mBinding.tvCpTime.text = "陪伴時長${map_data["meet_days"]}"

                var mList = JSONUtils.parseKeyAndValueToMapList(map_data["data"])

                list.clear()

                list.addAll(mList)

                if (list.size == 0){
                    mBinding.linlayCp1.visibility = View.GONE
                }

                mAdapter2?.notifyDataSetChanged()

            } else {
                mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.error)
            }
        }
    }

    override fun onExceptionType(type: String?) {
        super.onExceptionType(type)
        stopProgressDialog()
        if (type== "cp/list"){
            mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.error)
        }
    }

    inner class GoldRecyclerAdapter2 : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {

            return fGoldViewHolder(ItemPersonCpBinding.inflate(LayoutInflater.from(this@PersonCpAty)))

        }

        override fun getItemCount(): Int =list.size

        override fun getItemViewType(position: Int): Int {
            return position
        }

        override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {

            if (holder is fGoldViewHolder) {

                with(holder) {
                    with(mBinding) {

                        tvNick.text = list[position]["cp_user_nick"]
                        var maxW = AutoUtils.getPercentWidthSizeBigger(400)
                        var to_user_avatar = list[position]["cp_user_avatar"].toString()
                        ImageLoader.loadImageAes(this@PersonCpAty, to_user_avatar, mBinding.ivHead,maxW,maxW)

                        tvCpValue.text = "CP值${list[position]["cp_value"]}"
                        tvCpTime.text = "陪伴時長${list[position]["meet_days"]}"

                        when (position) {

                            0 -> {
                                tvRank.visibility = View.GONE
                                imgvRank.visibility = View.VISIBLE
                                imgvRank.setImageResource(R.mipmap.ic_160)
                            }

                            1 -> {
                                tvRank.visibility = View.GONE
                                imgvRank.visibility = View.VISIBLE
                                imgvRank.setImageResource(R.mipmap.ic_161)
                            }

                            2 -> {
                                tvRank.visibility = View.GONE
                                imgvRank.visibility = View.VISIBLE
                                imgvRank.setImageResource(R.mipmap.ic_162)
                            }

                            else -> {
                                tvRank.visibility = View.VISIBLE
                                tvRank.text = (position+1).toString()
                                imgvRank.visibility = View.GONE
                            }

                        }

                        var info_gender = list[position]["cp_user_gender"]

                        when (info_gender) {

                            "1" -> {
                                mBinding.tvGender.text = "1"
                                mBinding.linlayGender.setBackgroundResource(R.drawable.shape_77)
                            }

                            "0" -> {
                                mBinding.tvGender.text = "0"
                                mBinding.linlayGender.setBackgroundResource(R.drawable.shape_78)
                            }

                            "10" -> {
                                mBinding.tvGender.text = "10"
                                mBinding.linlayGender.setBackgroundResource(R.drawable.shape_79)
                            }

                            else -> {
                                mBinding.linlayGender.visibility = View.GONE
                            }

                        }

                        var cp_value_1 = list[position]["cp_value"].toString().toInt()

                        if (list[position]["is_loving"]=="1"){
                            imgvCp2.visibility = View.VISIBLE
                            imgvCp2.setImageResource(R.drawable.ia_71)

                        } else {
                            if (min_cp_value <= cp_value_1) {
                                imgvCp2.visibility = View.VISIBLE
                                imgvCp2.setImageResource(R.drawable.ia_31)
                            } else {
                                imgvCp2.visibility = View.GONE
                            }
                        }

                        if (info_code == list[position]["cp_user_code"]){
                            imgvCp2.visibility = View.GONE
                        }

                        ivHead.setOnClickListener {
                            if (info_code == list[position]["cp_user_code"]){
                                return@setOnClickListener
                            }

                            var bundle = Bundle()
                            bundle.putString("user_id",list[position]["cp_user_code"])
                            startActivity(PersonOtherDetailsAty::class.java,bundle)

                        }

                        imgvCp2.setOnClickListener {
                            var bundle = Bundle()
                            bundle.putString("user_code",list[position]["cp_user_code"])
                            startActivity(PersonCpAty::class.java,bundle)
                        }

                    }
                }

            }

        }

        inner class fGoldViewHolder(binding: ItemPersonCpBinding) : RecyclerView.ViewHolder(binding.root) {
            var mBinding: ItemPersonCpBinding = binding

            init {
                AutoUtils.autoSize(binding.root)

            }
        }

    }




}
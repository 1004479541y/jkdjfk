package com.mail.myapplication.ui.mine.person.cp

import android.os.Bundle
import android.view.Gravity
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.mail.comm.base.BaseAty
import com.mail.comm.base.BaseDialog
import com.mail.comm.image.ImageLoader
import com.mail.comm.net.AESCBCCrypt
import com.mail.comm.utils.JSONUtils
import com.mail.comm.view.load.XLoadTip
import com.mail.myapplication.R
import com.mail.myapplication.databinding.DgPersonCpBinding
import com.mail.myapplication.databinding.ItemDgPersonCpBinding
import com.mail.myapplication.interfaces.Home
import com.mail.myapplication.interfaces.Lar
import com.mail.myapplication.ui.wallet.RechargeAty
import com.yhz.adaptivelayout.utils.AutoUtils

class PersonCpDg(context: BaseAty) : BaseDialog(context) {

    lateinit var mBinding: DgPersonCpBinding
    var mAdapter: GoldRecyclerAdapter? = null
    var home = Home()
    var list = ArrayList<MutableMap<String, String>>()
    var lar = Lar()
    var index_check = 0
    var mPersonCpDgListen:PersonCpDgListen?=null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        mBinding = DgPersonCpBinding.inflate(layoutInflater);
        setContentView(mBinding.root)
        window?.setWindowAnimations(R.style.dialogFullscreen3)
        val dialogWindow = window

        dialogWindow!!.setBackgroundDrawable(null)
        dialogWindow.setGravity(Gravity.BOTTOM)
        setCanceledOnTouchOutside(true)
        val m = baseAty.windowManager
        val d = m.defaultDisplay// 获取屏幕宽、高
        val p = dialogWindow.attributes
        window?.getDecorView()?.setPadding(0, 0, 0, 0)
        p.width = (d.width * 1) // 宽度设置为屏幕的0.85
        dialogWindow.attributes = p

        with(mBinding){

            var mLayoutManager2 = GridLayoutManager(baseAty, 3)
            mLayoutManager2.orientation = RecyclerView.VERTICAL
            recyclerview.layoutManager = mLayoutManager2
            mAdapter = GoldRecyclerAdapter()
            recyclerview.adapter = mAdapter

//            loading.setLoadingTipXReloadCallback(object: XLoadTip.LoadingTipXReloadCallback{
//                override fun reload() {
//                    requestData()
//                }
//            })

            tv001.setOnClickListener {
                dismiss()
                if (baseAty is BaseAty){
                    (baseAty as BaseAty).startActivity(RechargeAty::class.java)
                }
            }

            tvBuy.setOnClickListener {
                dismiss()
                mPersonCpDgListen?.buyCp(list[index_check]["id"].toString())
            }

        }

    }


    interface PersonCpDgListen{
        fun buyCp(id:String)
    }

    fun setPersonCpDgListen(mPersonCpDgListen:PersonCpDgListen){
        this.mPersonCpDgListen =mPersonCpDgListen
    }

    fun requestData() {
        if (isShowing) {
//            mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.loading)
            home.a73(this)
            lar.b102(this)
        }
    }

    fun setDataHead(head:String,head2:String){
        if(isShowing){
            var maxW = AutoUtils.getPercentWidthSizeBigger(400)
            ImageLoader.loadImageAes(baseAty, head, mBinding.imgv1,maxW,maxW)
            ImageLoader.loadImageAes(baseAty, head2, mBinding.imgv2,maxW,maxW)
        }
    }

    override fun onExceptionType(type: String?) {
        super.onExceptionType(type)
        if (type == "cp/order"){
//            mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.error)
        }
    }

    override fun onComplete(var2: String?, type: String?) {
        super.onComplete(var2, type)
        if (type == "cp/order"){
//            mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.finish)
            var map = JSONUtils.parseKeyAndValueToMap(var2)
            if(map["code"]=="200"){
                var str = AESCBCCrypt.aesDecrypt(map["data"])
                list = JSONUtils.parseKeyAndValueToMapList(str)
                mAdapter?.notifyDataSetChanged()

            }else{
//                mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.error)
            }
        }

        if (type == "coins/wallet") {
            var map = JSONUtils.parseKeyAndValueToMap(var2)
            if (map["code"] == "200") {
                var str_wallet = AESCBCCrypt.aesDecrypt(map["data"])
                var map_info = JSONUtils.parseKeyAndValueToMap(str_wallet)
                mBinding.tvCoins.text = map_info["user_coins"]
            }
        }
    }

    inner class GoldRecyclerAdapter : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
            return fGoldViewHolder(ItemDgPersonCpBinding.inflate(LayoutInflater.from(context)))
        }

        override fun getItemCount(): Int = list.size

        override fun getItemViewType(position: Int): Int {
            return position
        }

        override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {

            if (holder is fGoldViewHolder) {

                with(holder) {
                    with(mBinding) {

                        tvCoins.text = list[position]["coins"]
                        tvTime.text = list[position]["day"]+"天"
                        itemView.setOnClickListener {
                            index_check = position
                            notifyDataSetChanged()
                        }
//
                        if (position == index_check) {
                            relayBg.setBackgroundResource(R.drawable.shape_104)
                        } else {
                            relayBg.setBackgroundResource(R.drawable.shape_89)
                        }

                    }
                }

            }

        }

        inner class fGoldViewHolder(binding: ItemDgPersonCpBinding) :
            RecyclerView.ViewHolder(binding.root) {
            var mBinding: ItemDgPersonCpBinding = binding

            init {
                AutoUtils.autoSize(binding.root)

            }
        }

    }




}
package com.mail.myapplication.ui.mine.person.giftwall

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.mail.comm.base.BaseAty
import com.mail.comm.image.ImageLoader
import com.mail.comm.net.AESCBCCrypt
import com.mail.comm.utils.JSONUtils
import com.mail.comm.utils.PreferencesUtils
import com.mail.comm.utils.TimeUtils
import com.mail.comm.view.load.XLoadTip
import com.mail.comm.view.refresh.XRefreshInterface
import com.mail.myapplication.BaseXFrg
import com.mail.myapplication.databinding.FrgGiftWall1Binding
import com.mail.myapplication.databinding.ItemGiftWall1Binding
import com.mail.myapplication.interfaces.Home
import com.mail.myapplication.ui.MainWalletAty
import com.mail.myapplication.ui.dg.gift.GiftDialog
import com.mail.myapplication.ui.mine.person.PersonOtherDetailsAty
import com.mail.myapplication.ui.msg.chat.ChatAty
import com.mail.myapplication.ui.utils.MyUtils3
import com.yhz.adaptivelayout.utils.AutoUtils
import org.xutils.common.util.LogUtil

class GiftWall01Frg: BaseXFrg() {

    var home = Home()
    lateinit var mBinding: FrgGiftWall1Binding
    var list = ArrayList<MutableMap<String, String>>()
    var mAdapter: GoldRecyclerAdapter? = null
    var giftDialog: GiftDialog?=null

    var user_code = ""
    var nick = ""
    var avatar = ""
    var is_send_pic = ""
    var info_code = ""

    override fun getLayoutId() =0

    override fun initView() {
        info_code = PreferencesUtils.getString(requireActivity(),"info_code")

        user_code = arguments?.getString("user_code").toString()
        nick = arguments?.getString("nick").toString()
        avatar = arguments?.getString("avatar").toString()
        is_send_pic = arguments?.getString("is_send_pic").toString()
    }

    companion object {
        fun create(user_code: String,nick:String,avatar:String,is_send_pic:String): GiftWall01Frg {
            val fragment = GiftWall01Frg()
            val bundle = Bundle()
            bundle.putString("user_code", user_code)
            bundle.putString("nick", nick)
            bundle.putString("avatar", avatar)
            bundle.putString("is_send_pic", is_send_pic)
            fragment.arguments = bundle
            return fragment
        }
    }

    override fun getLayoutView(): View {
        mBinding = FrgGiftWall1Binding.inflate(layoutInflater);
        return mBinding.root
    }

    override fun requestData() {
        mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.loading)
        home.a67(user_code, this)
    }

    fun requestData2(){
        home.a67(user_code, this)

    }

    fun showGift(){
        if (giftDialog == null){
//            giftDialog = GiftDialog(this)
            giftDialog?.setGiftDialogListen(object : GiftDialog.GiftDialogListen{
                override fun recharge() {
                    var bundle = Bundle()
                    bundle.putString("page_type", "pay")
                    startActivity(MainWalletAty::class.java, bundle)
                }

                override fun sendGift(gift_cover: String, gift_svga: String,
                                      gift_title: String, gift_id: String) {
//                    this@GiftWall01Frg.sendGift(gift_cover,gift_svga,gift_title,gift_id)
                }

            })
        }
        giftDialog?.show()
        giftDialog?.requestData()
    }

//    fun sendGift(gift_cover:String,gift_svga:String,gift_title:String,gift_id:String){
//        var time = TimeUtils.getBeijinTime()
//        var message_id = MyUtils3.getMD5Str(time+user_code)
//
//        var json = MyUtils3.getGiftMsg(
//            to_user_code,to_avatar,to_nick,
//            user_code,avatar,nick,
//            gift_cover,gift_svga,gift_title,gift_id,
//            time,message_id
//        )
//        message_gift = mRtmClient?.createMessage()
//        message_gift?.text = json
//        LogUtil.e(" message.serverReceivedTs="+json)
////                val messageBean = MessageBean(user_code, message, true)
//        map_gift = HashMap<String,String>()
//        map_gift["user_code"] = user_code
//        map_gift["to_user_code"] = to_user_code
//        map_gift["time"] = time
//        map_gift["msg"] = json
//        map_gift["message_id"] = message_id
//
//        mBinding.editChat.setText("")
//        mBinding.imgvSend.visibility = View.GONE
//        mBinding.progressP.visibility = View.VISIBLE
//        home.a432(to_user_code,user_code,json,time,message_id,"",this@ChatAty)
//    }
//

    override fun onComplete(var2: String?, type: String?) {
        super.onComplete(var2, type)
        mBinding.swipeRefreshLayout.finishRefreshing()
        mBinding.swipeRefreshLayout.finishLoadmore()
        if (type == "gift/wall/all") {
            var map = JSONUtils.parseKeyAndValueToMap(var2)
            if (map["code"] == "200") {
                mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.finish)
                var str = AESCBCCrypt.aesDecrypt(map["data"])
                list.clear()
                var mList = JSONUtils.parseKeyAndValueToMapList(str)
                if (mList != null && mList.size>0){
                    list.addAll(mList)
                }
                mAdapter?.notifyDataSetChanged()
            }else{
                mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.error)
            }
        }
    }

    override fun onExceptionType(type: String?) {
        super.onExceptionType(type)
        mBinding.swipeRefreshLayout.finishRefreshing()
        mBinding.swipeRefreshLayout.finishLoadmore()
        if (type == "gift/wall/all"){
            mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.error)
        }
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)

        var mLayoutManager = GridLayoutManager(requireContext(), 4)
        mLayoutManager.orientation = RecyclerView.VERTICAL
        mBinding.recyclerview.layoutManager = mLayoutManager
        mAdapter = GoldRecyclerAdapter()
        mBinding.recyclerview.adapter = mAdapter

        mBinding.loading.setLoadingTipXReloadCallback(object : XLoadTip.LoadingTipXReloadCallback {
            override fun reload() {
                requestData()
            }
        })

        mBinding.swipeRefreshLayout.setEnableLoadmore(false)
        mBinding.swipeRefreshLayout.setEnableRefresh(true)
        mBinding.swipeRefreshLayout.setXRefreshAndLoadListen(object : XRefreshInterface {
            override fun refreshStart() {
                requestData2()
            }

            override fun loadMoreStart() {
            }

        })
    }

    inner class GoldRecyclerAdapter : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
            return fGoldViewHolder(ItemGiftWall1Binding.inflate(LayoutInflater.from(context)))
        }

        override fun getItemCount(): Int = list.size

        override fun getItemViewType(position: Int): Int {
            return position
        }

        override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {

            if (holder is fGoldViewHolder) {

                with(holder) {

                    with(mBinding) {

                        if (position<=3){
                            vTop.visibility = View.VISIBLE
                        }else{
                            vTop.visibility = View.GONE
                        }
                        var map = list[position]
                        var num = map["user_receive_num"]!!.toInt()

                        if (num == 0){
                            ivHead.visibility = View.GONE
                            tvDian.visibility = View.VISIBLE
                            tvNum.visibility = View.GONE
                        }else{
                            ivHead.visibility = View.VISIBLE
                            tvDian.visibility = View.GONE
                            tvNum.visibility = View.VISIBLE
                            tvNum.text = "x"+map["user_receive_num"]
                            var maxW = AutoUtils.getPercentWidthSizeBigger(200)
                            ImageLoader.loadImageAes(requireActivity(), map["light_user_avatar"], ivHead,maxW,maxW)
                        }

                        var maxW = AutoUtils.getPercentWidthSizeBigger(200)
                        ImageLoader.loadImageAes(requireActivity(), map["cover"], imgv,maxW,maxW)
                        tvName.text = map["title"]

                        tvDian.setOnClickListener {

                            if (info_code == user_code){
                                showToastS("不可以给自己点亮")
                                return@setOnClickListener
                            }

                            var bundle = Bundle()
                            bundle.putString("code", this@GiftWall01Frg.user_code)
                            bundle.putString("nick", this@GiftWall01Frg.nick)
                            bundle.putString("avatar", this@GiftWall01Frg.avatar)
                            bundle.putString("is_send_pic", this@GiftWall01Frg.is_send_pic)
                            startActivity(ChatAty::class.java, bundle)
                            activity?.finish()
                        }

                        ivHead.setOnClickListener {
                            var bundle = Bundle()
                            bundle.putString("user_id",list[position]["light_user_code"])
                            startActivity(PersonOtherDetailsAty::class.java,bundle)
                        }

                    }

                }

            }

        }

        inner class fGoldViewHolder(binding: ItemGiftWall1Binding) :
            RecyclerView.ViewHolder(binding.root) {

            var mBinding: ItemGiftWall1Binding = binding

            init {
                AutoUtils.autoSize(binding.root)

            }
        }

    }

}
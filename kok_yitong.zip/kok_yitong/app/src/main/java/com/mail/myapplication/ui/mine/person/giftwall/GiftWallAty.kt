package com.mail.myapplication.ui.mine.person.giftwall

import android.os.Bundle
import android.view.View
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.lifecycle.Lifecycle
import androidx.viewpager2.adapter.FragmentStateAdapter
import androidx.viewpager2.widget.ViewPager2
import com.mail.comm.utils.PreferencesUtils
import com.mail.myapplication.BaseXAty
import com.mail.myapplication.R
import com.mail.myapplication.databinding.AtyGiftWallBinding
import com.mail.myapplication.databinding.FrgGiftWall1Binding
import com.mail.myapplication.ui.mine.person.cp.PersonCpDetails01Frg
import com.mail.myapplication.ui.mine.person.cp.PersonCpDetails02Frg
import com.mail.myapplication.ui.msg.chat.ChatAty

class GiftWallAty : BaseXAty() {

    lateinit var mBinding: AtyGiftWallBinding

    var list_frg = ArrayList<Fragment>()

    var user_code = ""
    var nick = ""
    var avatar = ""
    var is_send_pic = ""
    var info_code = ""


    override fun getLayoutView(): View {
        mBinding = AtyGiftWallBinding.inflate(layoutInflater);
        return mBinding.root
    }

    override fun getLayoutId() = 0

    override fun initView() {
        user_code = intent.getStringExtra("user_code").toString()
        nick = intent.getStringExtra("nick").toString()
        avatar = intent.getStringExtra("avatar").toString()
        is_send_pic = intent.getStringExtra("is_send_pic").toString()
        info_code = PreferencesUtils.getString(this,"info_code")

    }

    override fun requestData() {}

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        with(mBinding) {
            initTopview2(include.relayTopBg, resources.getString(R.string.c_4))
            include.tvTitle.text = "礼物墙"
        }
        initFrg()
    }

    fun initFrg(){

        list_frg.add(GiftWall01Frg.create(user_code,nick,avatar,is_send_pic))

        list_frg.add(GiftWall02Frg.create(user_code))

        mBinding.viewPager.adapter = PersonListAdataper(supportFragmentManager, this@GiftWallAty.lifecycle, list_frg)
        mBinding.viewPager.offscreenPageLimit = list_frg.size

        mBinding.tv1.setOnClickListener {
            mBinding.viewPager.setCurrentItem(0,true)
        }

        mBinding.tv2.setOnClickListener {
            mBinding.viewPager.setCurrentItem(1,true)
        }

        mBinding.viewPager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) {
                when (position) {
                    0 -> {
                        mBinding.tv1.setBackgroundResource(R.drawable.shape_93)
                        mBinding.tv2.setBackgroundResource(R.drawable.shape_92)
                    }
                    1 -> {
                        mBinding.tv1.setBackgroundResource(R.drawable.shape_92)
                        mBinding.tv2.setBackgroundResource(R.drawable.shape_93)
                    }
                }
            }
        })

    }

    inner class PersonListAdataper(
        fa: FragmentManager,
        lifecycle: Lifecycle,
        val docs: ArrayList<Fragment>
    ) :

        FragmentStateAdapter(fa, lifecycle) {

        override fun getItemCount(): Int = docs.size

        override fun createFragment(position: Int): Fragment = docs[position]

    }

    fun mainClick(v: View) {

        when (v.id) {

            R.id.relay_back -> {
                finish()
            }

            R.id.tv_send -> {

                if (info_code == user_code){
//                    showToastS("不可以给自己点亮")
                    return
                }

                var bundle = Bundle()
                bundle.putString("code", this.user_code)
                bundle.putString("nick", this.nick)
                bundle.putString("avatar", this.avatar)
                bundle.putString("is_send_pic", this.is_send_pic)
                startActivity(ChatAty::class.java, bundle)
                finish()
            }

            R.id.tv_1 -> {
                mBinding.viewPager.setCurrentItem(0,true)
            }

            R.id.tv_2 -> {
                mBinding.viewPager.setCurrentItem(1,true)
            }

        }

    }

}
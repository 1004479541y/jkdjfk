package com.mail.myapplication.ui.find

import android.animation.*
import android.os.Bundle
import android.os.CountDownTimer
import android.text.TextUtils
import android.view.View
import android.widget.ImageView
import android.widget.RelativeLayout
import com.lzy.okgo.utils.HttpUtils.runOnUiThread
import com.mail.comm.app.AppConfig
import com.mail.comm.app.BaseApp
import com.mail.comm.image.ImageLoader
import com.mail.comm.net.AESCBCCrypt
import com.mail.comm.utils.JSONUtils
import com.mail.comm.utils.MyUtils2
import com.mail.myapplication.BaseXFrg
import com.mail.myapplication.R
import com.mail.myapplication.databinding.FrgFindBinding
import com.mail.myapplication.interfaces.Home
import com.mail.myapplication.ui.app.NoticeVh
import com.mail.myapplication.ui.mine.person.PersonDetailsAty
import com.mail.myapplication.ui.mine.person.PersonOtherDetailsAty
import com.mail.myapplication.ui.utils.MyUtils3
import com.yhz.adaptivelayout.config.AutoLayoutConifg
import com.yhz.adaptivelayout.utils.AutoUtils
import org.xutils.common.util.LogUtil
import java.util.*
import kotlin.collections.ArrayList
import kotlin.collections.HashMap

class FindFrg : BaseXFrg() {

    var index = 0
    var home = Home()
    var info_code =""
    lateinit var mBinding: FrgFindBinding
    var map_user = HashMap<String,String>()
    var list_imgv = ArrayList<ImageView>()
    var list = ArrayList<HashMap<String,String>>()
    var list_user = ArrayList<MutableMap<String,String>>()

    var index_last = -1
    var index_first = -1
    var index_last_type = "+"
    var index_first_type = "+"
    var index_list_user =0
    var voice_chat_num =""
    var word_chat_num =""
    var countDownTimer:CountDownTimer?=null
    var noticeVh:NoticeVh?=null
//    var match_video_url =""

    override fun getLayoutView(): View {
        mBinding = FrgFindBinding.inflate(layoutInflater);
        return mBinding.root
    }

    override fun getLayoutId(): Int = 0

    override fun onResume() {
        super.onResume()
        home.a50(this)
//        requestData2()
        noticeVh?.onResume()
        info_code = BaseApp?.instance?.getOneMapData("info_code")!!
    }

    fun requestData2(){
        home.a52(this)
    }

    override fun requestData() {
        home.a52(this)
    }

    override fun onPause() {
        super.onPause()
        noticeVh?.onPause()
    }

    fun initLayout() {
        var params = mBinding.linlay012.layoutParams as RelativeLayout.LayoutParams
        var StatusBarHeight = MyUtils2.getStateBar(activity)
        if (StatusBarHeight <= 0) {
            StatusBarHeight = MyUtils2.dip2px(activity, 20F)
        }
        params.topMargin = StatusBarHeight
        params.height = AutoUtils.getPercentHeightSizeBigger(150)
        mBinding.linlay012.layoutParams = params
    }

    override fun initView() {
        list_imgv.clear()
        list_imgv.add(mBinding.imgv1)
        list_imgv.add(mBinding.imgv2)
        list_imgv.add(mBinding.imgv3)
        list_imgv.add(mBinding.imgv4)
        list_imgv.add(mBinding.imgv5)
        list_imgv.add(mBinding.imgv6)
        list_imgv.add(mBinding.imgv7)
        list_imgv.add(mBinding.imgv8)
        list_imgv.add(mBinding.imgv9)
        list_imgv.add(mBinding.imgv10)
        list_imgv.add(mBinding.imgv11)
        list_imgv.add(mBinding.imgv12)
        list_imgv.add(mBinding.imgv13)
        list_imgv.add(mBinding.imgv14)
        list_imgv.add(mBinding.imgv15)
        list_imgv.add(mBinding.imgv16)
        list_imgv.add(mBinding.imgv17)
        list_imgv.add(mBinding.imgv18)
        Collections.shuffle(list_imgv!!)
        index_last = 7
        index_first =0


    }

    override fun onComplete(var2: String?, type: String?) {
        super.onComplete(var2, type)

        if (type == "getBgImage"){

            var map = JSONUtils.parseKeyAndValueToMap(var2)
            if(map["code"]=="200"){
                var str = AESCBCCrypt.aesDecrypt(map["data"])
                var map_data =  JSONUtils.parseKeyAndValueToMap(str)
                BaseApp.instance?.saveOneMapData("match_video_url",map_data["bg_image"])
//                match_video_url = BaseApp.instance?.getOneMapData("match_video_url").toString()
            }else{
                showToastS(map["message"])
            }
        }

        if (type == "random/people") {
            var map = JSONUtils.parseKeyAndValueToMap(var2)
            if (map["code"] == "200") {
                var str = AESCBCCrypt.aesDecrypt(map["data"])
                var maps = JSONUtils.parseKeyAndValueToMap(str)
                mBinding.tvPerNum.text = maps["people"]
            }
        }

        if (type == "find"){
            var map = JSONUtils.parseKeyAndValueToMap(var2)
            if (map["code"] == "200") {
                var str = AESCBCCrypt.aesDecrypt(map["data"])
                var maps = JSONUtils.parseKeyAndValueToMap(str)
                list_user = JSONUtils.parseKeyAndValueToMapList(maps["user_data"])

                voice_chat_num = maps["voice_chat_num"]!!
                word_chat_num = maps["word_chat_num"]!!
                mBinding.tvVoiceNum.text = "今日剩餘${voice_chat_num}次"
                mBinding.tvWordNum.text = "今日剩餘${word_chat_num}次"

                mBinding.tvAdTime.text = "每天${maps["match_start_at"]}~${maps["match_end_at"]}限时开发"

                var maxW_head =AutoLayoutConifg.getInstance().screenWidth
                ImageLoader.loadImageAes(activity, maps["match_cover"], mBinding.imgvAd,maxW_head,maxW_head)
                if (list_user!=null&&list_user.size>20){
                    initView()
                    startAnim()
                }
            }
        }
    }

    fun startAnim(){

        list.clear()

        for (index in list_imgv!!.indices){
            var map = HashMap<String,String>()
            map["isAnim"] = "0"
            list.add(map)
            list_imgv!![index].visibility= View.GONE
            list_imgv!![index].clearAnimation()
        }

        countDownTimer?.cancel()

        countDownTimer = object : CountDownTimer(1000*30000, 1000) {
            override fun onTick(millisUntilFinished: Long) {
                runOnUiThread {
                    var time = 30000-(millisUntilFinished / 1000).toInt()
//                    LogUtil.e("startAnim===="+time)
                    if (time%2==0){
                        var s1 =time/2-1
                        if (s1<7){
                            index_list_user++
                            if (index_list_user>list_user.size-1){
                                index_list_user =0
                            }
                            map_user[s1.toString()] =s1.toString()
                            startOneAnim(s1,"1")
                            LogUtil.e("startAnim 10===="+map_user[s1.toString()])

                        }else{
                            if (index_list_user>list_user.size-1){
                                index_list_user =0
                            }
                            map_user[index_last.toString()] = index_list_user.toString()
                            LogUtil.e("startAnim 00===="+index_last+","+index_list_user)
                            startOneAnim(index_last,"1")
                            startOneAnim(index_first,"0")

                            index_list_user++

                            if (index_last_type == "-") {
                                index_last -= 1
                            } else {
                                index_last += 1
                            }

                            if (index_last > list_imgv!!.size - 1) {
                                index_last = 0
                                index_last_type = "+"
                            }

                            if (index_first_type == "-") {
                                index_first -= 1
                            } else {
                                index_first += 1
                            }

                            if (index_first > list_imgv!!.size - 1) {
                                index_first = 0
                                index_first_type = "+"
                            }
                        }
                    }
                }
            }

            override fun onFinish() {

            }

        }
        countDownTimer?.start()
    }

    fun startOneAnim(index: Int,type:String) {
        var map =  list[index]
        map["isAnim"]="1"
        map["type"]=type
        list.set(index,map)

        var imgv = list_imgv!![index]
        var index_imgv =map_user[index.toString()]!!.toInt()

        if (type=="1"){
            val lp = imgv?.layoutParams as RelativeLayout.LayoutParams
            imgv.visibility = View.VISIBLE
            var random_start = AutoUtils.getPercentWidthSize(60)
            var random_end = AutoUtils.getPercentWidthSize(130)
            lp.height =(random_start..random_end).random()
            lp.width =  lp.height
            imgv.layoutParams = lp
            var maxW_head = AutoUtils.getPercentWidthSizeBigger(200)
            var imgv_url = list_user[index_imgv]["avatar"]
            ImageLoader.loadImageAes(activity,imgv_url,imgv,maxW_head,maxW_head)

            imgv.scaleType = ImageView.ScaleType.FIT_XY
            onScaleAnimation(imgv)
        }else{
            onScaleAnimationOut(imgv)
        }

        imgv.setOnClickListener {

            var bundle = Bundle()
            if (list_user[index_imgv]["code"]==info_code){
                bundle.putString("typePage","my")
                startActivity(PersonDetailsAty::class.java,bundle)
            }else{
                bundle.putString("user_id",list_user[index_imgv]["code"])
                startActivity(PersonOtherDetailsAty::class.java,bundle)
            }

        }
    }

    private fun onScaleAnimationOut(imgv:ImageView) {
        val animatorX: ObjectAnimator = ObjectAnimator.ofFloat(imgv, "scaleX", 1.0f, 0.0f)
        val animatorY: ObjectAnimator = ObjectAnimator.ofFloat(imgv, "scaleY", 1.0f, 0.0f)
        val set = AnimatorSet()
        set.setDuration(2000)
        set.playTogether(animatorX, animatorY)
        set.start()
    }

    private fun onScaleAnimation(imgv:ImageView) {
        val animatorX: ObjectAnimator = ObjectAnimator.ofFloat(imgv, "scaleX", 0.3f, 1.0f)
        val animatorY: ObjectAnimator = ObjectAnimator.ofFloat(imgv, "scaleY", 0.3f, 1.0f)
        val set = AnimatorSet()
        set.setDuration(2000)
        set.playTogether(animatorX, animatorY)
        set.start()

        set.addListener(object : Animator.AnimatorListener{
            override fun onAnimationStart(p0: Animator?) {
            }

            override fun onAnimationEnd(p0: Animator?) {
            }

            override fun onAnimationCancel(p0: Animator?) {
            }

            override fun onAnimationRepeat(p0: Animator?) {
            }
        })
    }


    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        initLayout()
        noticeVh = NoticeVh(requireActivity(),mBinding.relay)
        noticeVh?.addToParent()
        noticeVh?.onCreate()

        with(mBinding) {

            linlay03.setOnClickListener {
                if (AppConfig.model == "wanou"){
                    var match_video_url = BaseApp.instance?.getOneMapData("match_video_url").toString()
                    if (TextUtils.isEmpty(match_video_url)){
                        home.a63(this@FindFrg)
                        return@setOnClickListener
                    }
                }
                if (TextUtils.isEmpty(voice_chat_num)){
                    requestData2()
                    return@setOnClickListener
                }
                if (!MyUtils3.isFastClick()) {
                    return@setOnClickListener
                }
                var bundle = Bundle()
                bundle.putString("match_type","voice")
                startActivity(MatchAty::class.java,bundle)
            }

            linlay04.setOnClickListener {
                if (AppConfig.model == "wanou"){
                    var match_video_url = BaseApp.instance?.getOneMapData("match_video_url").toString()
                    if (TextUtils.isEmpty(match_video_url)){
                        home.a63(this@FindFrg)
                        return@setOnClickListener
                    }
                }
                if (TextUtils.isEmpty(voice_chat_num)){
                    requestData2()
                    return@setOnClickListener
                }
                if (!MyUtils3.isFastClick()) {
                    return@setOnClickListener
                }
                var bundle = Bundle()
                bundle.putString("match_type","word")
                startActivity(MatchAty::class.java,bundle)
            }

            var  isVibrate =BaseApp.instance?.getOneMapData("isVibrate")

            if (TextUtils.isEmpty(isVibrate) || isVibrate == "1"){
                imgvVibrate.setImageResource(R.drawable.ib_02)
            }else{
                imgvVibrate.setImageResource(R.drawable.ib_03)
            }

            imgvVibrate.setOnClickListener {
                if (!MyUtils3.isFastClick()) {
                    return@setOnClickListener
                }
                var  isVibrate =BaseApp.instance?.getOneMapData("isVibrate")

                if (TextUtils.isEmpty(isVibrate) || isVibrate == "1"){
                    isVibrate = "0"
                    imgvVibrate.setImageResource(R.drawable.ib_03)
                    showToastS("消息震动已关闭")
                }else{
                    isVibrate = "1"
                    imgvVibrate.setImageResource(R.drawable.ib_02)
                    showToastS("消息震动已开启")
                }
                BaseApp.instance?.saveOneMapData("isVibrate",isVibrate)
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        for (index in list_imgv!!.indices) {
            var map = HashMap<String, String>()
            map["isAnim"] = "0"
            list_imgv!![index].clearAnimation()
        }
        countDownTimer?.cancel()
        noticeVh?.onDestroy()
    }


}
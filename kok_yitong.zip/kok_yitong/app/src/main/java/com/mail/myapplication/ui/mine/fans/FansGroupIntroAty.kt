package com.mail.myapplication.ui.mine.fans

import android.os.Bundle
import android.view.View
import com.mail.myapplication.BaseXAty
import com.mail.myapplication.R
import com.mail.myapplication.databinding.*

class FansGroupIntroAty : BaseXAty() {

    lateinit var mBinding: AtyFansGroupIntroBinding

    override fun getLayoutId(): Int = 0

    override fun getLayoutView(): View {
        mBinding = AtyFansGroupIntroBinding.inflate(layoutInflater);
        return mBinding.root
    }

    override fun initView() {
    }

    override fun requestData() {
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        initTopview2(mBinding.include.relayTopBg, resources.getString(R.string.c_4))
        mBinding.include.tvTitle.text = "私密團介紹"
    }


    fun mainClick(v: View) {

        when (v.id) {

            R.id.relay_back -> {
                finish()
            }

        }
    }



}
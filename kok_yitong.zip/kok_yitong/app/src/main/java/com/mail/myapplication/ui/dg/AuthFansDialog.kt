package com.mail.myapplication.ui.dg

import android.app.Dialog
import android.os.Bundle
import android.view.Gravity
import android.view.View
import com.mail.comm.base.BaseAty
import com.mail.myapplication.R
import com.mail.myapplication.databinding.DgAuthFansBinding


class AuthFansDialog(context: BaseAty) : Dialog(context) {

    var baseAty = context
    var listener :AuthFansDialogListen? =null
    lateinit var mBinding: DgAuthFansBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        mBinding = DgAuthFansBinding.inflate(layoutInflater);
        setContentView(mBinding.root)
        window?.setWindowAnimations(R.style.dialogFullscreen2)
        window!!.setBackgroundDrawable(null)
        window!!.setGravity(Gravity.CENTER)
        setCanceledOnTouchOutside(true)
        val m = baseAty.windowManager
        val d = m.defaultDisplay// 获取屏幕宽、高
        val p = window!!.attributes
        window?.getDecorView()?.setPadding(0, 0, 0, 0)
        p.width = (d.width * 1) // 宽度设置为屏幕的0.85
        window!!.attributes = p

        mBinding.imgvCancel.setOnClickListener {
            listener?.onCancel()
            dismiss()
        }

        mBinding.tv01.setOnClickListener {
            listener?.onclik01()
            dismiss()
        }

        mBinding.tv02.setOnClickListener {
            dismiss()
            listener?.onclik02()
        }
        mBinding.tvContent.text = "该帖在仅私密團成员可看！是否加入Ta的私密團？"
    }

    fun setNoEnableCancel(){
        if (isShowing){
            setCanceledOnTouchOutside(false)
            setCancelable(false)
            mBinding.imgvCancel.visibility= View.GONE
        }
    }

    fun setData(info: String) {
        if (isShowing){
            mBinding.tvContent.text = info
        }
    }

    interface  AuthFansDialogListen{
        fun onclik01()
        fun onclik02()
        fun onCancel()
    }

    fun setAuthFansDialogListenn(listener:AuthFansDialogListen){
        this.listener =listener
    }

}
package com.mail.myapplication.ui.find

import android.app.Dialog
import android.os.Bundle
import android.view.Gravity
import android.view.View
import com.mail.comm.base.BaseAty
import com.mail.comm.image.ImageLoader
import com.mail.myapplication.R
import com.mail.myapplication.databinding.DgAuthFansBinding
import com.mail.myapplication.databinding.DgMatchVoiceCpBinding
import com.mail.myapplication.databinding.DgMatchVoiceLockBinding
import com.yhz.adaptivelayout.utils.AutoUtils


class MatchVoiceCpDg(context: BaseAty) : Dialog(context) {

    var baseAty = context
    var listener :MatchVoiceCpDgListen? =null
    lateinit var mBinding: DgMatchVoiceCpBinding
    var maxW_head = AutoUtils.getPercentWidthSizeBigger(400)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        mBinding = DgMatchVoiceCpBinding.inflate(layoutInflater);
        setContentView(mBinding.root)
        window?.setWindowAnimations(R.style.dialogFullscreen2)
        window!!.setBackgroundDrawable(null)
        window!!.setGravity(Gravity.CENTER)
        setCanceledOnTouchOutside(true)
        val m = baseAty.windowManager
        val d = m.defaultDisplay// 获取屏幕宽、高
        val p = window!!.attributes
        window?.getDecorView()?.setPadding(0, 0, 0, 0)
        p.width = (d.width * 1) // 宽度设置为屏幕的0.85
        window!!.attributes = p

//        mBinding.imgvCancel.setOnClickListener {
//            listener?.onCancel()
//            dismiss()
//        }
//        mBinding.tv01.setOnClickListener {
//            listener?.onclik01()
//            dismiss()
//        }
//
//        mBinding.tv02.setOnClickListener {
//            dismiss()
//            listener?.onclik02()
//        }
////        mBinding.tvContent.text = "该帖在仅私密團成员可看！是否加入Ta的私密團？"

        mBinding.tvRule.setOnClickListener {
            this.listener?.onclik01()
        }

        mBinding.tvGift.setOnClickListener {
            dismiss()
            this.listener?.sendGift()
        }

        mBinding.tvTime.setOnClickListener {
            dismiss()
            this.listener?.addTime()
        }

    }

    fun setNoEnableCancel(){
        if (isShowing){
            setCanceledOnTouchOutside(false)
            setCancelable(false)
//            mBinding.imgvCancel.visibility= View.GONE
        }
    }

    fun setData(cp_rule_content:String,head:String,to_head:String,is_follow:String) {

        if (isShowing){
            ImageLoader.loadImageAes(baseAty,head,mBinding.imgvHead2,maxW_head,maxW_head)
            mBinding.tvDes.text = cp_rule_content
            if (is_follow == "1"){
                ImageLoader.loadImageAes(baseAty,to_head,mBinding.imgvHead,maxW_head,maxW_head)
            }
        }
    }

    fun hideAddTime(){
        if (isShowing){
            mBinding.relayAddTime.visibility = View.GONE
        }
    }

    interface  MatchVoiceCpDgListen{
        fun onclik01()
        fun sendGift()
        fun addTime()
    }

    fun setMatchVoiceCpDgListen(listener:MatchVoiceCpDgListen){
        this.listener =listener
    }

}
package com.mail.myapplication.ui.dg

import android.app.Dialog
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import com.mail.comm.base.BaseAty
import com.mail.comm.utils.JSONUtils
import com.mail.myapplication.R
import com.mail.myapplication.databinding.DgFansBinding
import com.mail.myapplication.interfaces.Lar
import org.xutils.common.util.LogUtil

class FansDialog(context: BaseAty) : Dialog(context) {

    private var baseAty = context
    lateinit var mBinding: DgFansBinding
    var list = ArrayList<MutableMap<String, String>>()
    var lar = Lar()
    var listen: PayListen? = null
    var mapDataGroup:MutableMap<String,String>?=null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        mBinding = DgFansBinding.inflate(layoutInflater);
        setContentView(mBinding.root)
        window?.setWindowAnimations(R.style.dialogFullscreen3)
        val dialogWindow = window
        dialogWindow!!.setBackgroundDrawable(null)
        dialogWindow.setGravity(Gravity.BOTTOM)
        setCanceledOnTouchOutside(true)
        val m = baseAty.windowManager
        val d = m.defaultDisplay// 获取屏幕宽、高
        val p = dialogWindow.attributes
        window?.getDecorView()?.setPadding(0, 0, 0, 0)
//        p.height =  (d.height * 1) // 高度设置为屏幕的0.6
        p.width = (d.width * 1) // 宽度设置为屏幕的0.85
        dialogWindow.attributes = p

        with(mBinding) {

            relayM.setOnClickListener {

                if (tvGold.text.toString() == "暂未开通"){
                    return@setOnClickListener
                }

                listen?.toPay("month", mapDataGroup!!["month_coins"]!!)
            }

            relayS.setOnClickListener {
                if (tvGold2.text.toString() == "暂未开通"){
                    return@setOnClickListener
                }
                listen?.toPay("season",mapDataGroup!!["season_coins"]!!)
            }

            relayY.setOnClickListener {
                if (tvGold3.text.toString() == "暂未开通"){
                    return@setOnClickListener
                }
                listen?.toPay("year",mapDataGroup!!["year_coins"]!!)
            }

            relayCancel.setOnClickListener {
                dismiss()
            }

        }
    }

    interface  PayListen{
        fun toPay(type:String,goldNum:String)
    }

    fun setPayListen(listener:PayListen){
        this.listen =listener
    }

    fun setData(str_group: String) {

        LogUtil.e("setData==="+str_group)

        if (isShowing){
             mapDataGroup = JSONUtils.parseKeyAndValueToMap(str_group)
            LogUtil.e("setData==="+"金幣"+mapDataGroup!!["month_coins"])
            with((mBinding)){

                if (mapDataGroup!!["month_coins"]=="0"){
                    tvGold.text = "暂未开通"
                    tvGold.setTextColor(Color.parseColor("#66000000"))
                    imgvGold.visibility = View.INVISIBLE
                }else{
                    tvGold.text = "金幣"+mapDataGroup!!["month_coins"]
                    tvGold.setTextColor(Color.parseColor("#FFFBA540"))
                    imgvGold.visibility = View.VISIBLE

                }
                if (mapDataGroup!!["season_coins"]=="0"){
                    tvGold2.text = "暂未开通"
                    tvGold2.setTextColor(Color.parseColor("#66000000"))
                    imgvGold2.visibility = View.INVISIBLE

                }else{
                    tvGold2.text = "金幣"+mapDataGroup!!["season_coins"]
                    tvGold2.setTextColor(Color.parseColor("#FFFBA540"))
                    imgvGold2.visibility = View.VISIBLE

                }
                if (mapDataGroup!!["year_coins"]=="0"){
                    tvGold3.text = "暂未开通"
                    tvGold3.setTextColor(Color.parseColor("#66000000"))
                    imgvGold3.visibility = View.INVISIBLE

                }else{
                    tvGold3.text = "金幣"+mapDataGroup!!["year_coins"]
                    tvGold3.setTextColor(Color.parseColor("#FFFBA540"))
                    imgvGold3.visibility = View.VISIBLE
                }

            }
        }

    }


}
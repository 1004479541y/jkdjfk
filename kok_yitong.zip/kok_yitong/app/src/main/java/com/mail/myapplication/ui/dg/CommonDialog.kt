package com.mail.myapplication.ui.dg

import android.os.Bundle
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import com.mail.comm.base.BaseAty
import com.mail.comm.base.BaseDialog
import com.mail.myapplication.R
import com.mail.myapplication.databinding.DialogCommBinding


class CommonDialog(context: BaseAty) : BaseDialog(context) {

    lateinit var mBinding: DialogCommBinding
    var info = ""
    var listener:CommonDialogListen?=null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        mBinding = DialogCommBinding.inflate(layoutInflater);
        setContentView(mBinding.root)
        window?.setWindowAnimations(R.style.dialogFullscreen2)
        window!!.setBackgroundDrawable(null)
        window!!.setGravity(Gravity.CENTER)
        setCanceledOnTouchOutside(true)
        val m = baseAty.windowManager
        val d = m.defaultDisplay// 获取屏幕宽、高
        val p = window!!.attributes
        window?.getDecorView()?.setPadding(0, 0, 0, 0)
        p.width = (d.width * 1) // 宽度设置为屏幕的0.85
        window!!.attributes = p

        mBinding.imgvCancel.setOnClickListener {
            dismiss()
        }

        mBinding.tv01.setOnClickListener {
            listener?.onclik01()
        }

        mBinding.tv02.setOnClickListener {
            listener?.onclik02()
        }

    }

    fun setData(info: String,str_01:String,str_02: String) {
        if (isShowing){
            if (TextUtils.isEmpty(str_01)){
                mBinding.tv01.visibility = View.GONE
            }
            if (TextUtils.isEmpty(str_02)){
                mBinding.tv02.visibility = View.GONE
            }
            mBinding.tvContent.text = info
            mBinding.tv01.text = str_01
            mBinding.tv02.text = str_02
        }
    }

    fun setCommCanceled(isEnable:Boolean){
        if (isShowing){
            setCanceledOnTouchOutside(isEnable)
            setCancelable(isEnable)
        }
    }

    fun setCancelViewVisibility(isEnable: Boolean) {
        if (isShowing){
            if (isEnable) {
                mBinding.imgvCancel.visibility = View.VISIBLE
            } else {
                mBinding.imgvCancel.visibility = View.GONE
            }
        }

    }

    interface  CommonDialogListen{
        fun onclik01()
        fun onclik02()
    }

    fun setCommonDialogListen(listener:CommonDialogListen){
        this.listener =listener
    }



}
package com.mail.myapplication.ui.view;

import android.content.Context;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.ViewConfiguration;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.widget.NestedScrollView;

public class RecyclerViewAtViewPager3 extends NestedScrollView {


    private int downX;
    private int downY;
    private int moveX;
    private int moveY;
    private int mT ;
    public RecyclerViewAtViewPager3(@NonNull Context context) {
        super(context,null);
        mT =ViewConfiguration.get(context).getScaledTouchSlop();
    }

    public RecyclerViewAtViewPager3(@NonNull Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        mT =ViewConfiguration.get(context).getScaledTouchSlop();
    }

    public RecyclerViewAtViewPager3(@NonNull Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        mT =ViewConfiguration.get(context).getScaledTouchSlop();
    }

    @Override
    public boolean onInterceptTouchEvent(MotionEvent e) {
//        return super.onInterceptTouchEvent(ev);
        switch (e.getAction()) {
            case MotionEvent.ACTION_DOWN:
                downX = (int) e.getRawX();
                downY = (int) e.getRawY();
                break;
            case MotionEvent.ACTION_MOVE:
                moveX = (int) e.getRawX();
                moveY = (int) e.getRawY();
                if (Math.abs(moveX-downX)>mT){
                    return false;
                }
//
        }
        return super.onInterceptTouchEvent(e);

    }
}

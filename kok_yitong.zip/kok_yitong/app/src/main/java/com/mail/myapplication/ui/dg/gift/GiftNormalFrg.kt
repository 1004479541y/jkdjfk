package com.mail.myapplication.ui.dg.gift

import android.annotation.SuppressLint
import android.graphics.Color
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.mail.comm.app.AppConfig
import com.mail.comm.base.BaseAty
import com.mail.comm.image.ImageLoader
import com.mail.comm.net.AESCBCCrypt
import com.mail.comm.utils.JSONUtils
import com.mail.comm.view.load.XLoadTip
import com.mail.myapplication.BaseXFrg
import com.mail.myapplication.R
import com.mail.myapplication.databinding.FrgGiftNormalBinding
import com.mail.myapplication.databinding.ItemGiftBinding
import com.mail.myapplication.interfaces.Home
import com.mail.myapplication.ui.dg.GiftInfoDialog
import com.mail.myapplication.ui.mine.person.cp.PersonCpDetails01Frg
import com.yhz.adaptivelayout.utils.AutoUtils
import org.xutils.common.util.LogUtil

class GiftNormalFrg: BaseXFrg() {

    var home = Home()
    lateinit var mBinding: FrgGiftNormalBinding
    var list = ArrayList<MutableMap<String, String>>()
    var mAdapter: GoldRecyclerAdapter? = null
    var index_check = -1

    var type =""

    var mGiftInfoDialog: GiftInfoDialog? =null

    var mGiftNormalFrgListen:GiftNormalFrgListen?=null

    override fun getLayoutId() =0

    override fun initView() {
        type = arguments?.getString("type").toString()
    }

//    fun getCheckIndex() = index_check

    fun getCheckIndexData():MutableMap<String, String>?{
        if (index_check == -1)return null
        return list[index_check]
    }

    fun getCpValue():String{
        if (list.size>0&&index_check!=-1){
            return list[index_check]["cp_value"].toString()
        }
        return  ""
    }

    override fun getLayoutView(): View {
        mBinding = FrgGiftNormalBinding.inflate(layoutInflater);
        return mBinding.root
    }

    override fun onResume() {
        super.onResume()
//      requestData()
    }

    companion object {

        fun create(type: String): GiftNormalFrg {
            val fragment = GiftNormalFrg()
            val bundle = Bundle()
            bundle.putString("type", type)
            fragment.arguments = bundle
            return fragment
        }
    }

    interface GiftNormalFrgListen{
        fun showCpValue(value:String)
    }

    fun setGiftNormalFrgListen(mGiftNormalFrgListen:GiftNormalFrgListen){
        this.mGiftNormalFrgListen =mGiftNormalFrgListen
    }

    override fun requestData() {
        mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.loading)
        home.a56(type,this)
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)

        var mLayoutManager = GridLayoutManager(requireContext(), 4)
        mLayoutManager.orientation = RecyclerView.VERTICAL
        mBinding.recyclerview.layoutManager = mLayoutManager
        mAdapter = GoldRecyclerAdapter()
        mBinding.recyclerview.adapter = mAdapter

        mBinding.loading.setLoadingTipXReloadCallback(object : XLoadTip.LoadingTipXReloadCallback {
            override fun reload() {
                requestData()
            }
        })

    }

    override fun onComplete(var2: String?, type: String?) {
        super.onComplete(var2, type)

        LogUtil.e("onComplete")
        if (type == "gift/list") {
            var map = JSONUtils.parseKeyAndValueToMap(var2)
            if (map["code"] == "200") {
                mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.finish)
                var str = AESCBCCrypt.aesDecrypt(map["data"])
                var mList = JSONUtils.parseKeyAndValueToMapList(str)
//                index_check = 0
                list.clear()
                list.addAll(mList)
                mAdapter?.notifyDataSetChanged()
            } else {
                mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.error)

            }
        }

    }


    override fun onExceptionType(type: String?) {
        super.onExceptionType(type)
        stopProgressDialog()
        if (type == "gift/list") {
            mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.error)
        }
    }


    inner class GoldRecyclerAdapter : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
            return fGoldViewHolder(ItemGiftBinding.inflate(LayoutInflater.from(context)))
        }

        override fun getItemCount(): Int = list.size

        override fun getItemViewType(position: Int): Int {
            return position
        }

        override fun onBindViewHolder(holder: RecyclerView.ViewHolder, @SuppressLint("RecyclerView") position: Int) {

            if (holder is fGoldViewHolder) {

                with(holder) {
                    with(mBinding) {

                        itemView.setOnClickListener {
                            mGiftNormalFrgListen?.showCpValue(list[position]["cp_value"].toString())
                            index_check = position
                            notifyDataSetChanged()
                        }

                        itemView.setOnLongClickListener {
                            if (position == index_check&&this@GiftNormalFrg.type == "2") {
//                                showToastS("ddd")
                                if (mGiftInfoDialog == null){

                                    mGiftInfoDialog = GiftInfoDialog(requireActivity() as BaseAty)

                                }
                                mGiftInfoDialog?.show()
                                mGiftInfoDialog?.setData(list[position]["remark"].toString(),
                                    list[position]["title"].toString())
                            }

                            true
                        }

                        if (position == index_check) {
                            linlayBg.setBackgroundResource(R.drawable.shape_54)
                            if (this@GiftNormalFrg.type == "2"){
                                tvInfo.visibility = View.VISIBLE
                            }

                        } else {

                            tvInfo.visibility = View.GONE
                            if (AppConfig.model == "wanou"){
                                linlayBg.setBackgroundColor(Color.parseColor("#272935"))
                            }else{
                                linlayBg.setBackgroundColor(Color.parseColor("#ffffff"))
                            }
                        }

                        var maxW = AutoUtils.getPercentWidthSizeBigger(300)
                        ImageLoader.loadImageAes(requireActivity(), list[position]["cover"], imgv, maxW, maxW)
                        mBinding.tvCoins.text = list[position]["coins"]
                        mBinding.tvTitle.text = list[position]["title"]

                    }
                }

            }

        }

        inner class fGoldViewHolder(binding: ItemGiftBinding) :
            RecyclerView.ViewHolder(binding.root) {
            var mBinding: ItemGiftBinding = binding

            init {
                AutoUtils.autoSize(binding.root)

            }
        }

    }

}
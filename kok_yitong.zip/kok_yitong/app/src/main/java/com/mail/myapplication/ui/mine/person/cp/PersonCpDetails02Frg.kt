package com.mail.myapplication.ui.mine.person.cp

import android.graphics.Color
import android.os.Bundle
import android.text.TextUtils
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.mail.comm.image.ImageLoader
import com.mail.comm.net.AESCBCCrypt
import com.mail.comm.utils.JSONUtils
import com.mail.comm.view.load.XLoadTip
import com.mail.comm.view.refresh.XRefreshInterface
import com.mail.myapplication.BaseXFrg
import com.mail.myapplication.R
import com.mail.myapplication.databinding.FrgPersonCpDetails01Binding
import com.mail.myapplication.databinding.ItemPersonCpDetails02Binding
import com.mail.myapplication.interfaces.Home
import com.mail.myapplication.ui.home.active.HistoryActiveListAty
import com.mail.myapplication.ui.mine.person.PersonDetailsAty
import com.mail.myapplication.ui.mine.person.PersonOtherDetailsAty
import com.mail.myapplication.ui.utils.ClickListener
import com.mail.myapplication.ui.utils.MyUtils3
import com.yhz.adaptivelayout.utils.AutoUtils

class PersonCpDetails02Frg: BaseXFrg() {

    var home = Home()
    lateinit var mBinding: FrgPersonCpDetails01Binding
    var list = ArrayList<MutableMap<String, String>>()
    var mAdapter: GoldRecyclerAdapter? = null
    var room_id =""
    var page = 1
    override fun getLayoutId() =0

    override fun initView() {
        room_id = arguments?.getString("room_id").toString()
    }

    companion object {

        fun create(room_id: String): PersonCpDetails02Frg {
            val fragment = PersonCpDetails02Frg()
            val bundle = Bundle()
            bundle.putString("room_id", room_id)
            fragment.arguments = bundle
            return fragment
        }

    }

    override fun getLayoutView(): View {
        mBinding = FrgPersonCpDetails01Binding.inflate(layoutInflater);
        return mBinding.root
    }

    override fun requestData() {
        page = 1
        mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.loading)
        home.a82(page,room_id,this)
    }

    fun requestData2() {
        home.a82(page,room_id,this)
    }

    override fun onComplete(var2: String?, type: String?) {
        super.onComplete(var2, type)
        if (type== "former/list"){

            mBinding.swipeRefreshLayout.finishRefreshing()
            mBinding.swipeRefreshLayout.finishLoadmore()
            mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.finish)
            var map = JSONUtils.parseKeyAndValueToMap(var2)
            if(map["code"]=="200"){
                var str = AESCBCCrypt.aesDecrypt(map["data"])
                var mList = JSONUtils.parseKeyAndValueToMapList(str)
                if (page == 1){
                    list.clear()
                    list.addAll(mList)

                }else{
                    list.addAll(mList)
                }

                if (page==1&&mList.size==0){

                    mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.empty)
                }else{
                    mAdapter?.notifyDataSetChanged()
                }
            }else{
                if (page==1){
                    mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.error)
                }
            }
        }
    }

    override fun onExceptionType(type: String?) {
        super.onExceptionType(type)
        if (type== "former/list"){
            mBinding.swipeRefreshLayout.finishRefreshing()
            mBinding.swipeRefreshLayout.finishLoadmore()
            if (page==1&&list.size==0){
                mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.error)
            }else{
                mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.finish)
            }
        }
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)

        var mLayoutManager = GridLayoutManager(requireContext(), 1)
        mLayoutManager.orientation = RecyclerView.VERTICAL
        mBinding.recyclerview.layoutManager = mLayoutManager
        mAdapter = GoldRecyclerAdapter()
        mBinding.recyclerview.adapter = mAdapter

        mBinding.loading.setLoadingTipXReloadCallback(object : XLoadTip.LoadingTipXReloadCallback {
            override fun reload() {
                requestData()
            }
        })

        mBinding.swipeRefreshLayout.setEnableLoadmore(true)
        mBinding.swipeRefreshLayout.setEnableRefresh(true)
        mBinding.swipeRefreshLayout.setXRefreshAndLoadListen(object : XRefreshInterface {
            override fun refreshStart() {
                page =1
                requestData2()
            }

            override fun loadMoreStart() {
                page++
                requestData2()
            }

        })
    }


    inner class GoldRecyclerAdapter : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
            return fGoldViewHolder(ItemPersonCpDetails02Binding.inflate(LayoutInflater.from(context)))
        }

        override fun getItemCount(): Int = list.size

        override fun getItemViewType(position: Int): Int {
            return position
        }

        override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {

            if (holder is fGoldViewHolder) {

                with(holder) {
                    with(mBinding) {

                        var maxW = AutoUtils.getPercentWidthSizeBigger(400)
                        ImageLoader.loadImageAes(requireActivity(), list[position]["avatar"], mBinding.ivHead,maxW,maxW)

                        tvNick.text = list[position]["nick"]
                        tvTime.text = list[position]["created_at"]

                        if (list[position]["content"]!!.contains("[")){
                            var listContent = JSONUtils.parseKeyAndValueToMapList(list[position]["content"])
                            var str_list =  ArrayList<String>();
                            var color_list =  ArrayList<Int>()
                            var text_size_list =  ArrayList<Float>()
                            for ( i in listContent.indices){
                                text_size_list.add(AutoUtils.getPercentHeightSize(40).toFloat())

                                var sp = ""
                                if (i!=0){
                                    sp = "  "
                                }

                                if (TextUtils.isEmpty(listContent[i]["code"])){
                                    color_list.add(Color.parseColor(getString(R.string.c_3)))
                                    str_list.add(sp+"" + listContent[i]["content"]!! + " ")
                                }else{
                                    color_list.add(Color.parseColor(resources.getString(R.string.main_05)))
                                    str_list.add(sp+"@" + listContent[i]["content"]!!)
                                }
                            }

                            MyUtils3.setText(requireContext(), tvContent, str_list, color_list, text_size_list, object : ClickListener {
                                override fun click(position: Int) {

                                }
                            })

                        }else{
                            tvContent?.text = list[position]["content"]
                        }

                    }
                }

            }

        }

        inner class fGoldViewHolder(binding: ItemPersonCpDetails02Binding) :
            RecyclerView.ViewHolder(binding.root) {
            var mBinding: ItemPersonCpDetails02Binding = binding

            init {
                AutoUtils.autoSize(binding.root)

            }
        }

    }

}
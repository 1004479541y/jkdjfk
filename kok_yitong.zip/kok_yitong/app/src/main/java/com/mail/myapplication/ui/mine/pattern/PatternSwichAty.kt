package com.mail.myapplication.ui.mine.pattern

import android.os.Bundle
import android.view.View
import android.widget.CompoundButton
import com.mail.comm.utils.JSONUtils
import com.mail.comm.utils.PreferencesUtils
import com.mail.myapplication.BaseXAty
import com.mail.myapplication.R
import com.mail.myapplication.databinding.*
import com.mail.myapplication.interfaces.Lar
import org.xutils.common.util.LogUtil

class PatternSwichAty : BaseXAty() {

    lateinit var mBinding: AtyPatternSwichBinding
    var lar = Lar()

    override fun getLayoutId(): Int = 0

    override fun getLayoutView(): View {
        mBinding = AtyPatternSwichBinding.inflate(layoutInflater);
        return mBinding.root
    }

    override fun initView() {
    }

    override fun requestData() {
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        initTopview2(mBinding.include.relayTopBg, resources.getString(R.string.c_4))
        mBinding.include.tvTitle.text = "手势設置"
        mBinding.include.tvRight.text = "保存"
        mBinding.include.tvRight.visibility = View.VISIBLE
        mBinding.switch1.isChecked = isPattern()

        mBinding.switch1.setOnCheckedChangeListener(object: CompoundButton.OnCheckedChangeListener{
            override fun onCheckedChanged(buttonView: CompoundButton?, isChecked: Boolean) {
            }

        })
    }

    fun mainClick(v: View) {

        when (v.id) {

            R.id.relay_back -> {
                finish()
            }

            R.id.tv_ok ->{
                var bundle = Bundle()
                bundle.putString("type","reset_pattern")
                startActivity(PatternAty::class.java,bundle)
                finish()
            }

            R.id.tv_right ->{
                var switch = 0
                if ( mBinding.switch1.isChecked){
                    switch = 1
                }
                startProgressDialog()
                lar.b22(switch.toString(),this)
            }
        }
    }

    override fun onComplete(var2: String?, type: String?) {
        super.onComplete(var2, type)

        if (type=="user/update"){
            stopProgressDialog()
            var map = JSONUtils.parseKeyAndValueToMap(var2)
            LogUtil.e("========="+var2)
            if (map["code"] == "200") {
                setPattern(mBinding.switch1.isChecked)
                finish()
            }else{
                showToastS(map["message"])
            }

        }
    }

    override fun onExceptionType(type: String?) {
        super.onExceptionType(type)
        stopProgressDialog()
    }


}
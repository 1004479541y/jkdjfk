package com.mail.myapplication.ui.mine.person

import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.text.TextUtils
import android.util.TypedValue
import android.view.View
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.lifecycle.Lifecycle
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.adapter.FragmentStateAdapter
import androidx.viewpager2.widget.ViewPager2
import com.google.android.material.appbar.AppBarLayout
import com.google.android.material.appbar.CollapsingToolbarLayout
import com.mail.comm.app.AppConfig
import com.mail.comm.app.AppManager
import com.mail.comm.image.ImageLoader
import com.mail.comm.net.AESCBCCrypt
import com.mail.comm.utils.JSONUtils
import com.mail.comm.utils.MyUtils2
import com.mail.comm.view.load.XLoadTip
import com.mail.myapplication.BaseXAty
import com.mail.myapplication.R
import com.mail.myapplication.databinding.AtyPerOtherDetailsBinding
import com.mail.myapplication.interfaces.Home
import com.mail.myapplication.interfaces.Lar
import com.mail.myapplication.ui.MainWalletAty
import com.mail.myapplication.ui.dg.RechargeDgFrg
import com.mail.myapplication.ui.home.HomeListFrg
import com.mail.myapplication.ui.mine.BlackListAty
import com.mail.myapplication.ui.mine.EditInfoAty
import com.mail.myapplication.ui.mine.EditInfoBannerAdapter
import com.mail.myapplication.ui.mine.fans.FansGroupDetailsAty
import com.mail.myapplication.ui.mine.fans.FansGroupMyJoinAty
import com.mail.myapplication.ui.mine.person.cp.PersonCpAty
import com.mail.myapplication.ui.mine.person.cp.PersonCpDetailsAty
import com.mail.myapplication.ui.mine.person.giftwall.GiftWallAty
import com.mail.myapplication.ui.msg.chat.ChatAty
import com.mail.myapplication.ui.msg.chat.ChatReportAty
import com.mail.myapplication.ui.utils.MyUtils3
import com.yhz.adaptivelayout.utils.AutoUtils
import java.lang.Math.abs

class PersonOtherDetailsAty : BaseXAty() {

    lateinit var mBinding: AtyPerOtherDetailsBinding
    lateinit var list_tv: Array<TextView>
    lateinit var list_v: Array<View>

    var user_id = ""
    var is_join_group = ""
    var home = Home()
    var lar = Lar()
    var map_info: MutableMap<String, String>? = null
    var rechargeDg2: RechargeDgFrg? = null
    var list_frg = ArrayList<Fragment>()
    var mPersonOtherMoreDg: PersonOtherMoreDg? = null
    var is_follow =""
    var is_send_pic =""

    override fun getLayoutId(): Int = 0

    fun getIsJoinGroup() = is_join_group

    override fun getLayoutView(): View {
        mBinding = AtyPerOtherDetailsBinding.inflate(layoutInflater);
        return mBinding.root
    }

    override fun initView() {
        user_id = intent.getStringExtra("user_id").toString()
        with(mBinding) {
            list_tv = arrayOf(tv00,tv01, tv02, tv03,tv04)
            list_v = arrayOf(v00,v01, v02, v03,v04)
        }
        initLayout()
    }

    override fun requestData() {
        mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.loading)
        home.a17(user_id, this)
    }

    fun requestData2(){
        home.a172(user_id, this)
    }

    override fun onComplete(var2: String?, type: String?) {
        super.onComplete(var2, type)

        if (type == "post/block"){
            stopProgressDialog()
            var map = JSONUtils.parseKeyAndValueToMap(var2)
            if (map["code"] == "200") {
                showToastS("已拉黑")
            }else{
                showToastS(map["message"])
            }
        }

        if (type == "message/auth") {
            stopProgressDialog()
            var map = JSONUtils.parseKeyAndValueToMap(var2)
            if (map["code"] == "200") {
                var str = AESCBCCrypt.aesDecrypt(map["data"])
                var map_data = JSONUtils.parseKeyAndValueToMap(str)

                if (map_data["status"] != "0") {
//                    showToastS(map_data["message"])
                }

                is_send_pic = map_data["map_data"].toString()

                when (map_data["status"]) {

                    "0" -> {
                        var bundle = Bundle()
                        bundle.putString("code", map_info!!["code"]!!)
                        bundle.putString("nick", map_info!!["nick"]!!)
                        bundle.putString("avatar", map_info!!["avatar"]!!)
                        bundle.putString("is_send_pic", map_data["is_send_pic"])
                        AppManager.getInstance().killActivity(ChatAty::class.java)
                        startActivity(ChatAty::class.java, bundle)
                    }

                    "1" -> {

                        if (rechargeDg2 == null) {
                            rechargeDg2 = RechargeDgFrg(this)
                            rechargeDg2?.setRechargeListen(object : RechargeDgFrg.RechargeListen {
                                override fun onclik01() {
                                    rechargeDg2?.dismiss()
                                }

                                override fun onclik02() {
                                    rechargeDg2?.dismiss()
                                    var bundle = Bundle()
                                    bundle.putString("page_type", "pay")
                                    startActivity(MainWalletAty::class.java, bundle)
                                }

                                override fun onCancel() {
                                }

                            })
                        }
                        rechargeDg2?.show()
                        rechargeDg2?.setData(map_data["message"]!!, "2")

                    }

                    "2" -> {
                        startActivity(BlackListAty::class.java)
                        showToastS(map_data["message"])
                    }

                    "3" -> {
                        showToastS(map_data["message"])
                    }

                    "4" -> {
                        showToastS(map_data["message"])
                    }

                }

            } else {
                showToastS(map["message"])
            }
        }

        if (type == "cancel/follow"){
            stopProgressDialog()
            var map = JSONUtils.parseKeyAndValueToMap(var2)
            if (map["code"] == "200") {
                is_follow = "0"
                mBinding.imgvAtten.visibility = View.VISIBLE

            }else{
                showToastS(map["message"])
            }
        }

        if (type == "follow"){
            stopProgressDialog()
            var map = JSONUtils.parseKeyAndValueToMap(var2)
            if (map["code"] == "200") {
                is_follow = "1"
                mBinding.imgvAtten.visibility = View.GONE

            }else{
                showToastS(map["message"])
            }
        }

        if (type == "other/info"||type == "other/info2") {
            var map = JSONUtils.parseKeyAndValueToMap(var2)
            if (map["code"] == "200") {
                mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.finish)

//                mBinding.relayBack2.visibility = View.GONE
                var strs = AESCBCCrypt.aesDecrypt(map["data"])
                var map = JSONUtils.parseKeyAndValueToMap(strs)
                map_info = JSONUtils.parseKeyAndValueToMap(strs)

                is_follow = map!!["is_follow"].toString()

                if (is_follow == "1") {
                    mBinding.imgvAtten.visibility = View.GONE
                } else {
                    mBinding.imgvAtten.visibility = View.VISIBLE
                }

                with(mBinding) {

                    var info_nick = map["nick"]
                    var info_flow = map["flow"]
                    var info_fans = map["fans"]
                    var info_avatar = map["avatar"]
                    var info_intro = map["intro"]
                    var info_city = map["city"]
                    var info_years = map["years"]
                    var info_job = map["job"]
                    var info_gender = map["gender"]
                    var info_is_creator = map["is_creator"]
                    var info_vip_level = map["vip_level"]
                    var is_add_fans_group = map["is_add_fans_group"]
//                    var fans_count_num = map["fans_count_num"]
                    var jon_group_num = map["join_group_num"]
                     is_join_group = map["is_join_group"]!!
                    var cp_user_avatar = map["cp_user_avatar"]
//                    var list_fans_group = JSONUtils.parseKeyAndValueToMapList(map["fans_group_list"])
                    var maxW = AutoUtils.getPercentWidthSizeBigger(300)

//                  ImageLoader.loadImageAes(this@PersonOtherDetailsAty, info_avatar, ivHead, maxW, maxW)
                    mBinding.tvName.text = info_nick
                    mBinding.tvName2.text = info_nick
                    mBinding.tvAttenNum.text = info_flow
                    mBinding.tvFansNum.text = info_fans
                    mBinding.tvFanstuanNum.text = jon_group_num
                    mBinding.tvId.text = "${map["code"]}"

                    if (is_join_group == "0"){
                        mBinding.tvIsJoinGroup.text = "加入私密圈>>"
                    }else{
                        mBinding.tvIsJoinGroup.text = "他的私密圈>>"
                    }

                    if (!TextUtils.isEmpty(cp_user_avatar)&&cp_user_avatar != "null"){
                        ImageLoader.loadImageAes(this@PersonOtherDetailsAty, cp_user_avatar, ivHead, maxW, maxW)
                        mBinding.imgvCp.setImageResource(R.drawable.ia_55)
                    }

                    MyUtils3.setVipLevel(info_vip_level, mBinding.imgvVipLevel, 0)

                    if (is_add_fans_group =="1"){
                        imgvIsAddFansGroup.visibility = View.VISIBLE
                    }else{
                        imgvIsAddFansGroup.visibility = View.GONE
                    }

                    if (info_is_creator=="1"){
                        mBinding.imgvCreator.visibility = View.VISIBLE
                        var maxW_head = AutoUtils.getPercentWidthSizeBigger(400)
                        ImageLoader.loadImageAes(this@PersonOtherDetailsAty, map["creator_icon"], imgvCreator,maxW_head,maxW_head)
                    }else{
                        mBinding.imgvCreator.visibility = View.GONE
                    }

                    when (info_gender) {

                        "1" -> {
                            mBinding.imgvGender.setImageResource(R.drawable.ia_74)
                        }

                        "0" -> {
                            mBinding.imgvGender.setImageResource(R.drawable.ia_75)
                        }

                        "10" -> {
                            mBinding.imgvGender.setImageResource(R.drawable.ia_73)
                        }

                        else -> {
                            mBinding.imgvGender.visibility = View.GONE
                        }

                    }

                    var list_head = ArrayList<MutableMap<String,String>>()

                    var map_1 = HashMap<String,String>()
                    map_1["avatar"] = map["avatar"].toString()
                    list_head.add(map_1)
                    var avatar_log = map["avatar_log"].toString()
                    var avatar_log_list = JSONUtils.parseKeyAndValueToMapList(avatar_log)
                    if (avatar_log_list!=null &&avatar_log_list.size>0){
                        list_head.addAll(avatar_log_list)
                    }

                    var adapterImg = EditInfoBannerAdapter(list_head,this@PersonOtherDetailsAty)
                    mBinding.banner1.setAdapter(adapterImg)

                }
                if (type =="other/info"){
                    initFrg()
                }

            } else {
                if (type =="other/info"){
                    mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.error)
                }
            }
        }

    }

    override fun onExceptionType(type: String?) {
        super.onExceptionType(type)
        stopProgressDialog()
        if (type == "other/info"){
            mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.error)
        }
    }

    fun initFrg(){

        list_frg.add(PersonOtherDetailsFrg.create(user_id))
        list_frg.add(HomeListFrg.create2("mine_like", user_id))
        list_frg.add(HomeListFrg.create2("mine_my", user_id))
        list_frg.add(HomeListFrg.create2("mine_buy", user_id))
        list_frg.add(HomeListFrg.create2("fans", user_id,is_join_group))

        mBinding.viewPager.adapter = PersonListAdataper(
            supportFragmentManager,
            this@PersonOtherDetailsAty.lifecycle,
            list_frg
        )

        mBinding.viewPager.offscreenPageLimit = list_frg.size

    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setTranslanteBar()
        if (AppConfig.model == "wanou"){
            setAndroidNativeLightStatusBar(false)
        }else{
            setAndroidNativeLightStatusBar(true)
        }
        with(mBinding) {

            banner1.addBannerLifecycleObserver(this@PersonOtherDetailsAty)

            banner1.isAutoLoop(true)

            loading.setLoadingTipXReloadCallback(object : XLoadTip.LoadingTipXReloadCallback {
                override fun reload() {
                    requestData()
                }
            })

            var mLayoutManager2 = GridLayoutManager(this@PersonOtherDetailsAty, 1)
            mLayoutManager2.orientation = RecyclerView.VERTICAL

            appbar.addOnOffsetChangedListener(AppBarLayout.OnOffsetChangedListener { appBarLayout, verticalOffset ->
                val Offset = abs(verticalOffset).toFloat()
                val totalScrollRange = appBarLayout?.totalScrollRange
                var a = (Offset / totalScrollRange!!)
                linlayName.alpha = a
                relayBack2.alpha= a
                relayMore2.alpha = a
//                relayReport.alpha = a
//                imgvAtten2.alpha = a
            })

            linlay00.setOnClickListener {
                viewPager.setCurrentItem(0,true)
            }
            linlay01.setOnClickListener {
                viewPager.setCurrentItem(1,true)
            }
            linlay02.setOnClickListener {
                viewPager.setCurrentItem(2,true)
            }

            linlay03.setOnClickListener {
                viewPager.setCurrentItem(3,true)
            }
            linlay04.setOnClickListener {
                viewPager.setCurrentItem(4,true)
            }

            viewPager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
                override fun onPageSelected(position: Int) {
                    when (position) {
                        0 -> {
                            setSelector(tv00)
                        }
                        1 -> {
                            setSelector(tv01)
                        }
                        2 -> {
                            setSelector(tv02)
                        }
                        3 -> {
                            setSelector(tv03)
                        }
                        4 -> {
                            setSelector(tv04)
                        }

                    }
                }
            })

            viewPager.setCurrentItem(1, false)
        }
    }

    inner class PersonListAdataper(
        fa: FragmentManager,
        lifecycle: Lifecycle,
        val docs: ArrayList<Fragment>
    ) :

        FragmentStateAdapter(fa, lifecycle) {

        override fun getItemCount(): Int = docs.size

        override fun createFragment(position: Int): Fragment = docs[position]

    }

    private fun setSelector(tv: TextView) {
        for (i in list_tv.indices) {
            if (tv === list_tv[i]) {
                list_tv[i].setTextColor(Color.parseColor(getString(R.string.c_01)))
                list_tv[i].setTypeface(Typeface.defaultFromStyle(Typeface.BOLD));//加粗

                list_tv[i].setTextSize(
                    TypedValue.COMPLEX_UNIT_PX,
                    AutoUtils.getPercentWidthSizeBigger(55).toFloat()
                )
                list_v[i].visibility = View.VISIBLE
            } else {
                list_tv[i].setTextColor(Color.parseColor(getString(R.string.c_02)))
                list_tv[i].setTypeface(Typeface.defaultFromStyle(Typeface.NORMAL));//加粗
                list_tv[i].setTextSize(
                    TypedValue.COMPLEX_UNIT_PX,
                    AutoUtils.getPercentWidthSizeBigger(45).toFloat()
                )
                list_v[i].visibility = View.INVISIBLE
            }
        }
    }

    fun initLayout() {
        with(mBinding) {
            var params = toolbar.layoutParams as CollapsingToolbarLayout.LayoutParams
            var StatusBarHeight = MyUtils2.getStateBar(this@PersonOtherDetailsAty)
            if (StatusBarHeight <= 0) {
                StatusBarHeight = MyUtils2.dip2px(this@PersonOtherDetailsAty, 20F)
            }
            params.topMargin = StatusBarHeight
            params.height = AutoUtils.getPercentHeightSizeBigger(120)
            toolbar.setPadding(0, 0, 0, 0)
            toolbar.layoutParams = params
        }
        initLayout2()
    }

    fun initLayout2() {
//        with(mBinding) {
//            var params = linlayTop.layoutParams as LinearLayout.LayoutParams
//            var StatusBarHeight = MyUtils2.getStateBar(this@PersonOtherDetailsAty)
//            if (StatusBarHeight <= 0) {
//                StatusBarHeight = MyUtils2.dip2px(this@PersonOtherDetailsAty, 20F)
//            }
//            params.topMargin = StatusBarHeight + AutoUtils.getPercentHeightSizeBigger(150)
//            linlayTop.layoutParams = params
//        }
    }

    fun mainClick(v: View) {

        when (v.id) {

            R.id.relay_cp ->{
                var bundle = Bundle()
                bundle.putString("user_code",user_id)
                startActivity(PersonCpAty::class.java,bundle)
            }

            R.id.relay_gift_wall ->{

                var bundle = Bundle()
                bundle.putString("user_code", user_id)
                bundle.putString("nick", map_info!!["nick"]!!)
                bundle.putString("avatar", map_info!!["avatar"]!!)
                bundle.putString("is_send_pic", is_send_pic)
                startActivity(GiftWallAty::class.java, bundle)
            }

            R.id.imgv_cp ->{
                startActivity(PersonCpDetailsAty::class.java)
            }

            R.id.relay_more2 ,R.id.relay_more->{
                if (mPersonOtherMoreDg == null){
                    mPersonOtherMoreDg = PersonOtherMoreDg(this)
                }
                mPersonOtherMoreDg?.setPersonOtherMoreDgListen(object :
                    PersonOtherMoreDg.PersonOtherMoreDgListen {
                    override fun onClickAtten() {
                        startProgressDialog()
                        lar.b20(user_id, this@PersonOtherDetailsAty)
                    }

                    override fun onClickReport() {
                        var bundle = Bundle()
                        bundle.putString("to_user_code",user_id)
                        startActivity(ChatReportAty::class.java,bundle)
                    }

                    override fun onClickBlack() {
                        startProgressDialog()
                        home.a28("2",user_id,this@PersonOtherDetailsAty)
                    }

                })

                mPersonOtherMoreDg?.show()
                mPersonOtherMoreDg?.setData(is_follow,mBinding.tvName.text.toString())
            }


            R.id.tv_fans_group ,R.id.tv_fanstuan_num->{
                var bundle = Bundle()
                bundle.putString("uid",user_id)
//                showToastS(user_id)
                startActivity(FansGroupMyJoinAty::class.java,bundle)
            }

            R.id.relay_fans_group -> {
                var bundle = Bundle()
                bundle.putString("user_id",user_id)
                bundle.putString("is_join_group",is_join_group)
                bundle.putString("user_name",mBinding.tvName.text.toString())
                startActivity(FansGroupDetailsAty::class.java,bundle)
            }
//
//            R.id.relay_fans_group2, R.id.imgv_fans_group  -> {
//                var bundle = Bundle()
//                bundle.putString("user_id",user_id)
//                bundle.putString("is_join_group",is_join_group)
//                bundle.putString("user_name",mBinding.tvName.text.toString())
//                startActivity(FansGroupDetailsAty::class.java,bundle)
//            }

            R.id.imgv_chat -> {
//                var bundle = Bundle()
//                bundle.putString("code",map_info!!["code"]!!)
//                bundle.putString("nick",map_info!!["nick"]!!)
//                bundle.putString("avatar",map_info!!["avatar"]!!)
//                startActivity(ChatAty::class.java,bundle)
                startProgressDialog()
                home.a47(map_info!!["code"]!!, this)
            }

            R.id.relay_back, R.id.relay_back2 -> {
                finish()
            }

            R.id.relay_edit -> {
                startActivity(EditInfoAty::class.java)
            }

            R.id.framlay_head -> {
//                startActivity(MyHeadAty::class.java)
            }

            R.id.imgv_atten-> {
                startProgressDialog()
                lar.b19(user_id, this@PersonOtherDetailsAty)
            }
        }
    }


}
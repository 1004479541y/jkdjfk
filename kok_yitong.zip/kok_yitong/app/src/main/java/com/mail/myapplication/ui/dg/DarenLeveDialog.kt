package com.mail.myapplication.ui.dg

import android.app.Dialog
import android.os.Bundle
import android.text.TextUtils
import android.view.Gravity
import com.mail.comm.base.BaseAty
import com.mail.comm.base.BaseDialog
import com.mail.comm.net.AESCBCCrypt
import com.mail.comm.utils.JSONUtils
import com.mail.myapplication.R
import com.mail.myapplication.databinding.DgDarenLevelBinding
import com.mail.myapplication.interfaces.Lar
import com.mail.myapplication.ui.wallet.RechargeAty


class DarenLeveDialog(context: BaseAty) : BaseDialog(context) {

    var listener :DarenLeveDialogListen? =null
    lateinit var mBinding: DgDarenLevelBinding
    var info = ""
    var lar = Lar()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        mBinding = DgDarenLevelBinding.inflate(layoutInflater);
        setContentView(mBinding.root)
        window?.setWindowAnimations(R.style.dialogFullscreen2)
        window!!.setBackgroundDrawable(null)
        window!!.setGravity(Gravity.CENTER)
        setCanceledOnTouchOutside(true)
        val m = baseAty.windowManager
        val d = m.defaultDisplay// 获取屏幕宽、高
        val p = window!!.attributes
        window?.getDecorView()?.setPadding(0, 0, 0, 0)
//        p.height =  (d.height * 1) // 高度设置为屏幕的0.6
        p.width = (d.width * 1) // 宽度设置为屏幕的0.85
        window!!.attributes = p

//        mBinding.imgvCancel.setOnClickListener {
//            dismiss()
//        }
        mBinding.tvOk.setOnClickListener {
            if (TextUtils.isEmpty(mBinding.edit.text.toString())){
                ( baseAty as BaseAty).showToastS("联系方式不能为空")
                return@setOnClickListener
            }
            dismiss()
            listener?.buy(mBinding.edit.text.toString())
        }

        mBinding.tvBuy.setOnClickListener {
            dismiss()
            if (baseAty is BaseAty){
                (baseAty as BaseAty).startActivity(RechargeAty::class.java)
            }
        }
//
    }

    fun setData(money: String) {
        if (isShowing){
            mBinding.tvMoney.text = "我要缴纳${money}元保证金"
            lar.b102(this)

        }

    }

    override fun onComplete(var2: String?, type: String?) {
        super.onComplete(var2, type)

        if (type == "coins/wallet") {
            var map = JSONUtils.parseKeyAndValueToMap(var2)
            if (map["code"] == "200") {
                var str_wallet = AESCBCCrypt.aesDecrypt(map["data"])
                var map_info = JSONUtils.parseKeyAndValueToMap(str_wallet)
                mBinding.tvCoins.text = "金幣餘額："+map_info["user_coins"]+"  "
            }
        }
    }


    interface  DarenLeveDialogListen{
        fun buy(info:String)
    }

    fun setRechargeListen(listener:DarenLeveDialogListen){
        this.listener =listener
    }


}
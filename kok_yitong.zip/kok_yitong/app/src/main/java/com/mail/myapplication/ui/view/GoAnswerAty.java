//package com.mail.myapplication.ui.view;
//
//import android.Manifest;
//import android.content.ComponentName;
//import android.content.Context;
//import android.content.Intent;
//import android.content.ServiceConnection;
//import android.content.pm.PackageManager;
//import android.os.Build;
//import android.os.Bundle;
//import android.os.Handler;
//import android.os.IBinder;
//import android.support.v4.app.ActivityCompat;
//import android.support.v4.content.ContextCompat;
//import android.view.View;
//import android.widget.ImageView;
//import android.widget.TextView;
//
//import com.langji.xiniu.R;
//import com.langji.xiniu.app.BasAty;
//import com.langji.xiniu.services.MusicServices;
//import com.langji.xiniu.view.voice.AudioRecordManager;
//import com.langji.xiniu.view.voice.StringUtil;
//import com.toocms.dink5.mylibrary.commonutils.FileSizeUtil;
//
//import org.xutils.common.util.LogUtil;
//import org.xutils.view.annotation.Event;
//import org.xutils.view.annotation.ViewInject;
//
//import java.io.File;
//import java.util.ArrayList;
//import java.util.List;
//import java.util.Timer;
//import java.util.TimerTask;
//import java.util.UUID;
//
///**
// * Created by Administrator on 2017/11/9 0009.
// */
//
//public class GoAnswerAty extends BasAty implements MusicServices.musicListen {
//
//
//    @ViewInject(R.id.imgv_voice)
//    public ImageView imgv_voice;
//    @ViewInject(R.id.tv_time)
//    public TextView tv_time;
//    @ViewInject(R.id.tv_reset_voice)
//    public TextView tv_reset_voice;
//    @ViewInject(R.id.tv_ok_voice)
//    public TextView tv_ok_voice;
//    @ViewInject(R.id.arc2)
//    public CycleView arc2;
//
//
//    private String audioFileName;
//    private AudioRecordManager audioRecordManager;
//    private boolean isRecording;
//    private long recordTotalTime;
//    private long minRecordTime = DEFAULT_MIN_RECORD_TIME;
//    public static final long DEFAULT_MAX_RECORD_TIME = 120000;
//    public static final long DEFAULT_MIN_RECORD_TIME = 2000;
//    protected static final int DEFAULT_MIN_TIME_UPDATE_TIME = 1000;
//    private long maxRecordTime = DEFAULT_MAX_RECORD_TIME;
//    public MusicServices musicServices;
//
//    private Timer timer;
//    private TimerTask timerTask;
//    private Handler mainHandler;
//    private Intent intent;
//
//
//    private int voiceStatus;
//
//    private static String[] PERMISSIONS_STORAGE = {
//            Manifest.permission.READ_EXTERNAL_STORAGE,
//            Manifest.permission.RECORD_AUDIO,
//            Manifest.permission.WRITE_EXTERNAL_STORAGE};
//
//    private List<String> mPermissionList = new ArrayList<>();
//
//    @Override
//    public int getLayoutId() {
//        return R.layout.aty_go_answer;
//    }
//
//    @Override
//    public void initPresenter() {
//
//    }
//
//    @Override
//    public void initView() {
//
//    }
//
//    @Override
//    public void requestData() {
//
//    }
//
//    /**
//     * voiceStatus = 0 没有录音 1正在录音2 录音完成 3正在播放
//     *
//     * @param view
//     */
//    @Event(value = {R.id.imgv_back, R.id.imgv_voice, R.id.tv_reset_voice, R.id.tv_ok_voice})
//    private void onTestBaidulClick(View view) {
//
//        switch (view.getId()) {
//            case R.id.imgv_back:
//                finish();
//                break;
//            case R.id.imgv_voice:
//                if (voiceStatus == 0) {
//                    voiceStatus = 1;
//                    arc2.setVisibility(View.VISIBLE);
//                    onRecordStart();
//                    imgv_voice.setImageResource(R.drawable.aio_record_stop);
//                } else if (voiceStatus == 1) {
//                    voiceStatus = 2;
//                    stopRecordAudio();
//                    if (timer != null) {
//                        timer.cancel();
//                    }
//                    imgv_voice.setImageResource(R.drawable.aio_record_play_nor);
//                } else if (voiceStatus == 2) {
////                    LogUtil.e("ddddddddddaudioFileName" + audioFileName);
//                    musicServices.startPlaying(audioFileName);
//                    voiceStatus = 3;
//                    imgv_voice.setImageResource(R.drawable.aio_record_stop);
////                    LogUtil.e("dddddddddddddddstart");
//                } else if (voiceStatus == 3) {
//                    voiceStatus = 2;
//                    musicServices.stopPlaying();
//                    tv_reset_voice.setVisibility(View.VISIBLE);
//                    tv_ok_voice.setVisibility(View.VISIBLE);
//                    imgv_voice.setImageResource(R.drawable.aio_record_play_nor);
//                }
//                break;
//            case R.id.tv_reset_voice:
//                tv_time.setText("点击录音，最多录制120秒");
//                voiceStatus = 0;
//                imgv_voice.setImageResource(R.drawable.aio_record_start_nor);
//                arc2.setVisibility(View.GONE);
//                musicServices.stopPlaying();
//                stopRecordAudio();
//                tv_reset_voice.setVisibility(View.GONE);
//                tv_ok_voice.setVisibility(View.GONE);
//                break;
//            case R.id.tv_ok_voice:
//                break;
//        }
//    }
//
//    @Override
//    public void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//
//        mPermissionList.clear();
//        for (int i = 0; i < PERMISSIONS_STORAGE.length; i++) {
//            if (ContextCompat.checkSelfPermission(this, PERMISSIONS_STORAGE[i]) != PackageManager.PERMISSION_GRANTED) {
//                mPermissionList.add(PERMISSIONS_STORAGE[i]);
//
//            }
//        }
//        if (mPermissionList.isEmpty() || Build.VERSION.SDK_INT < Build.VERSION_CODES.JELLY_BEAN) {
//        } else {
//            String[] permissions = mPermissionList.toArray(new String[mPermissionList.size()]);//将List转为数组
//            ActivityCompat.requestPermissions(this, permissions, 101);
//        }
//
//        audioRecordManager = AudioRecordManager.getInstance();
//        mainHandler = new Handler();
//        intent = new Intent(this, MusicServices.class);
//        startService(intent);
//        bindService(intent, serviceConnection, Context.BIND_AUTO_CREATE);
//    }
//
//    ServiceConnection serviceConnection = new ServiceConnection() {
//        @Override
//        public void onServiceConnected(ComponentName componentName, IBinder iBinder) {
//            MusicServices.MyBinder binder = (MusicServices.MyBinder) iBinder;
//            musicServices = binder.getService();// 获取到的Service即MyService
//            musicServices.setMusicListen(GoAnswerAty.this);
//        }
//
//        @Override
//        public void onServiceDisconnected(ComponentName componentName) {
//
//        }
//    };
//
//    public String createAudioName() {
//        long time = System.currentTimeMillis();
//        String fileName = UUID.randomUUID().toString() + time + ".amr";
//        return fileName;
//    }
//
//
//    /**
//     * 检查是否ready录制,如果已经ready则开始录制
//     */
//    private void startRecordAudio() throws RuntimeException {
//        try {
//            audioRecordManager.init(audioFileName);
//            audioRecordManager.startRecord();
//            isRecording = true;
//        } catch (Exception e) {
//        }
//    }
//
//
//    public void onRecordStart() {
//        onRecordCancel();
//        recordTotalTime = 0;
//        initTimer();
//        timer.schedule(timerTask, 0, DEFAULT_MIN_TIME_UPDATE_TIME);
//        audioFileName = getApplicationContext().getExternalCacheDir() + File.separator + createAudioName();
////        mHorVoiceView.startRecord();
//        startRecordAudio();
//    }
//
//    /**
//     * 停止录音
//     */
//    private void stopRecordAudio() throws RuntimeException {
//        try {
//            audioRecordManager.stopRecord();
//            tv_reset_voice.setVisibility(View.VISIBLE);
//            tv_ok_voice.setVisibility(View.VISIBLE);
//            if (timer != null) {
//                timer.cancel();
//            }
//        } catch (Exception e) {
//        }
//    }
//
//    /**
//     * 初始化计时器用来更新倒计时
//     */
//    private void initTimer() {
//        timer = new Timer();
//        timerTask = new TimerTask() {
//            @Override
//            public void run() {
//                mainHandler.post(new Runnable() {
//                    @Override
//                    public void run() {
//                        //每隔1000毫秒更新一次ui
//                        recordTotalTime += 1000;
//                        float l = recordTotalTime / (float) maxRecordTime;
//                        arc2.setProgress((int) (l * 100));
//                        updateTimerUI();
//                    }
//                });
//            }
//        };
//    }
//
//    private void updateTimerUI() {
//        if (recordTotalTime >= maxRecordTime) {
//            stopRecordAudio();
//            voiceStatus = 2;
//            LogUtil.e("ddddddddddddddddddd文件大侠" + FileSizeUtil.getFileOrFilesSize(audioFileName, FileSizeUtil.SIZETYPE_KB));
//            imgv_voice.setImageResource(R.drawable.aio_record_play_nor);
//        } else {
//            String string = String.format(" 倒计时 %s ", StringUtil.formatRecordTime(recordTotalTime, maxRecordTime));
//            tv_time.setText(string);
//        }
//    }
//
//    private void deleteTempFile() {
//        //取消录制后删除文件
//        if (audioFileName != null) {
//            File tempFile = new File(audioFileName);
//            if (tempFile.exists()) {
//                tempFile.delete();
//            }
//        }
//    }
//
//    public void onRecordCancel() {
//        if (timer != null) {
//            timer.cancel();
//        }
//        deleteTempFile();
//    }
//
//    @Override
//    public void playCompletion() {
//        voiceStatus = 2;
//        imgv_voice.setImageResource(R.drawable.aio_record_play_nor);
//        LogUtil.e("ddddddddddddplayCompletion");
//    }
//
//    @Override
//    protected void onDestroy() {
//        super.onDestroy();
//        onRecordCancel();
//        if (serviceConnection != null) {
//            unbindService(serviceConnection);// 解除绑定，断开连接
//            stopService(intent);
//        }
//    }
//
//}

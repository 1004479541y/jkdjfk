package com.mail.myapplication.ui.websocket

import android.app.Service
import android.content.Intent
import android.os.Binder
import android.os.IBinder
import com.mail.comm.app.AppConfig
import org.xutils.common.util.LogUtil

class SocketService : Service() {


    private val stepBinder = StepBinder()

    override fun onBind(intent: Intent?): IBinder? = stepBinder

    /**
     * 向Activity传递数据的纽带
     */
    inner class StepBinder : Binder() {
        fun getService() = this@SocketService
    }

    override fun onCreate() {
        super.onCreate()
        startConnect()
    }

    override fun onDestroy() {
        super.onDestroy()
        LogUtil.e("service=====被销毁")
        SocketClient.getInstance()?.closeConnect()
    }

//  fun registerCallback(paramICallback: UpdateUiCallBack) {
//        SocketClient.getInstance()?.registerCallback(paramICallback)
//  }

    fun sendMsg(msg: String, timeSend: String) {
        SocketClient.getInstance()?.sendMsg(msg)
//        val msgId = StringUtils.getMD5Str(msg + timeSend + AppConfig.userId)
    }

    private fun startConnect() {
        LogUtil.e("startConnect0")
        LogUtil.e("startConnect1=" + AppConfig.Host_Url_Socket)
        SocketClient.getInstance()?.startHeartbeat(AppConfig.Host_Url_Socket)
    }


}
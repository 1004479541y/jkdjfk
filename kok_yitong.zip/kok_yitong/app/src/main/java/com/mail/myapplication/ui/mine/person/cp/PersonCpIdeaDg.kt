package com.mail.myapplication.ui.mine.person.cp

import android.content.Context
import android.os.Bundle
import android.text.TextUtils
import android.view.Gravity
import android.view.inputmethod.InputMethodManager
import com.mail.comm.base.BaseAty
import com.mail.comm.base.BaseDialog
import com.mail.myapplication.BaseXAty
import com.mail.myapplication.R
import com.mail.myapplication.databinding.DgPersonIdeaBinding

class PersonCpIdeaDg(context: BaseAty) : BaseDialog(context) {

    lateinit var mBinding: DgPersonIdeaBinding

    var mPersonCpIdeaDgListen: PersonCpIdeaDgListen? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        mBinding = DgPersonIdeaBinding.inflate(layoutInflater);
        setContentView(mBinding.root)
        window?.setWindowAnimations(R.style.dialogFullscreen3)
        val dialogWindow = window

        dialogWindow!!.setBackgroundDrawable(null)
        dialogWindow.setGravity(Gravity.BOTTOM)
        setCanceledOnTouchOutside(true)
        val m = baseAty.windowManager
        val d = m.defaultDisplay// 获取屏幕宽、高
        val p = dialogWindow.attributes
        window?.getDecorView()?.setPadding(0, 0, 0, 0)
        p.width = (d.width * 1) // 宽度设置为屏幕的0.85
        dialogWindow.attributes = p

        mBinding.tvSend.setOnClickListener {
            if (TextUtils.isEmpty(mBinding.editSend.text.toString())){
                (baseAty as BaseXAty).showToastS("评论内容不能为空！")
                return@setOnClickListener
            }
            dismiss()
            mPersonCpIdeaDgListen?.send(mBinding.editSend.text.toString())
        }
    }

    fun showInuput(){

        if (isShowing) {
            mBinding.editSend.setText("")
            mBinding.editSend.requestFocus()
            mBinding.editSend.post {
                val imm = context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
                imm.showSoftInput(mBinding.editSend, InputMethodManager.SHOW_IMPLICIT)
            }
        }

    }


    interface PersonCpIdeaDgListen{
       fun  send(content:String)
    }

    fun setPersonCpIdeaDgListen(mPersonCpIdeaDgListen: PersonCpIdeaDgListen){
        this.mPersonCpIdeaDgListen = mPersonCpIdeaDgListen;
    }

    fun setData(follow:String,nickname:String){

    }


}
package com.mail.myapplication.ui.lar

import android.os.Bundle
import android.view.View
import com.mail.comm.utils.JSONUtils
import com.mail.comm.utils.PreferencesUtils
import com.mail.myapplication.BaseXAty
import com.mail.myapplication.R
import com.mail.myapplication.databinding.AtyBindPhoneBinding
import com.mail.myapplication.databinding.AtyCodeBinding
import com.mail.myapplication.databinding.AtyCodeHelpBinding
import com.mail.myapplication.ui.msg.CustomerServiceAty
import com.mail.myapplication.ui.utils.MyUtils3
import com.yhz.adaptivelayout.utils.AutoUtils

class CodeHelpAty : BaseXAty() {

    lateinit var mBinding: AtyCodeHelpBinding
    var map_service_info:MutableMap<String,String>? = null

    override fun getLayoutId(): Int = 0

    override fun initView() {
        var service_info = PreferencesUtils.getString(this,"service_info")
        map_service_info = JSONUtils.parseKeyAndValueToMap(service_info)
    }

    override fun requestData() {}

    override fun getLayoutView(): View {
        mBinding = AtyCodeHelpBinding.inflate(layoutInflater);
        return mBinding.root
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        with(mBinding) {
            initTopview2(include.relayTopBg, resources.getString(R.string.c_4))
            include.tvTitle.text = "收不到验证码"
        }

        var str_list = ArrayList<String>();
        var color_list = ArrayList<Int>()
        var text_size_list = ArrayList<Float>()
        str_list.add("若无法解决，联系 ")
        str_list.add("官方客服>>")
        color_list.add(this@CodeHelpAty.resources.getColor(R.color.c_15))
        color_list.add(this@CodeHelpAty.resources.getColor(R.color.main_03))
        text_size_list.add(AutoUtils.getPercentHeightSize(38).toFloat())
        text_size_list.add(AutoUtils.getPercentHeightSize(42).toFloat())

        MyUtils3.setText(this@CodeHelpAty, mBinding.tv01, str_list, color_list, text_size_list) { position->

            if (position==1){
                var bundle = Bundle()
                bundle.putString("code",map_service_info!!["code"])
                bundle.putString("nick",map_service_info!!["nick"])
                bundle.putString("avatar",map_service_info!!["avatar"])
                startActivity(CustomerServiceAty::class.java,bundle)
            }

        }
    }

    fun mainClick(v: View) {

        when (v.id) {

            R.id.relay_back -> {
                finish()
            }
        }
    }



}
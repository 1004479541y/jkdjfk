package com.mail.myapplication.ui.mine.shop

import android.os.Bundle
import android.view.Gravity
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.mail.comm.base.BaseAty
import com.mail.comm.base.BaseDialog
import com.mail.comm.image.ImageLoader
import com.mail.myapplication.R
import com.mail.myapplication.databinding.DgShop2Binding
import com.mail.myapplication.databinding.DgShopBinding
import com.mail.myapplication.databinding.ItemDgPersonCpBinding
import com.yhz.adaptivelayout.utils.AutoUtils

class Shop2Dg(context: BaseAty) : BaseDialog(context) {

    lateinit var mBinding: DgShop2Binding
    var mShop2DgListen:Shop2DgListen?=null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        mBinding = DgShop2Binding.inflate(layoutInflater);
        setContentView(mBinding.root)
        window?.setWindowAnimations(R.style.dialogFullscreen3)
        val dialogWindow = window

        dialogWindow!!.setBackgroundDrawable(null)
        dialogWindow.setGravity(Gravity.BOTTOM)
        setCanceledOnTouchOutside(true)
        val m = baseAty.windowManager
        val d = m.defaultDisplay// 获取屏幕宽、高
        val p = dialogWindow.attributes
        window?.getDecorView()?.setPadding(0, 0, 0, 0)
        p.width = (d.width * 1) // 宽度设置为屏幕的0.85
        dialogWindow.attributes = p

        mBinding.tvAdDown.setOnClickListener {
            dismiss()
            mShop2DgListen?.click()
        }

    }

    interface Shop2DgListen{
        fun click()
    }

    fun setShop2DgListen(mShop2DgListen:Shop2DgListen){
        this.mShop2DgListen = mShop2DgListen
    }

    fun setData(is_select:String,frame_name:String,frame_url:String,head:String){
        if (isShowing){

            if (is_select == "1"){
                mBinding.tvAdDown.text = "卸下"
            }else{
                mBinding.tvAdDown.text = "佩戴"
            }

            mBinding.tvName.text = frame_name

            var maxW = AutoUtils.getPercentWidthSizeBigger(500)
            ImageLoader.loadImageAes(baseAty,head,mBinding.ivHead,maxW,maxW)
            ImageLoader.loadImageAes(baseAty,frame_url,mBinding.ivCover,maxW,maxW)
            mBinding.tvName.text = frame_name
        }
    }










}
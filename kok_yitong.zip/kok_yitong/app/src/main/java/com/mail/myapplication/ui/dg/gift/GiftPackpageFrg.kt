package com.mail.myapplication.ui.dg.gift

import android.annotation.SuppressLint
import android.graphics.Color
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.mail.comm.base.BaseAty
import com.mail.comm.image.ImageLoader
import com.mail.comm.net.AESCBCCrypt
import com.mail.comm.utils.JSONUtils
import com.mail.comm.utils.PreferencesUtils
import com.mail.comm.view.load.XLoadTip
import com.mail.myapplication.BaseXFrg
import com.mail.myapplication.R
import com.mail.myapplication.databinding.FrgGiftNormalBinding
import com.mail.myapplication.databinding.ItemGiftPackBinding
import com.mail.myapplication.interfaces.Home
import com.mail.myapplication.ui.dg.GiftInfoDialog
import com.mail.myapplication.ui.mine.shop.Shop2Dg
import com.yhz.adaptivelayout.utils.AutoUtils
import org.xutils.common.util.LogUtil

class GiftPackpageFrg: BaseXFrg() {

    var home = Home()
    lateinit var mBinding: FrgGiftNormalBinding
    var list = ArrayList<MutableMap<String, String>>()
    var mAdapter: GoldRecyclerAdapter? = null
    var index_check = -1
    var index_click = -1
    var mShopDg2: Shop2Dg? = null
    var mGiftInfoDialog: GiftInfoDialog? =null

    var type =""
    var info_avatar = ""

    var mGiftPackpageFrgListen: GiftPackpageFrgListen?=null

    interface GiftPackpageFrgListen{
        fun showCpValue(value:String)
    }

    fun setGiftNormalFrgListen(mGiftPackpageFrgListen:GiftPackpageFrgListen){
        this.mGiftPackpageFrgListen =mGiftPackpageFrgListen
    }

    override fun getLayoutId() =0

    override fun initView() {
        type = arguments?.getString("type").toString()
        info_avatar = PreferencesUtils.getString(requireActivity(), "info_avatar")
    }

//    fun getCheckIndex() = index_check

//    fun getCheckIndexData() = list[index_check]

    fun getCheckIndexData():MutableMap<String, String>?{
        if (index_check == -1)return null
        return list[index_check]
    }

    fun getCpValue():String{
        if (list.size>0&&index_check!=-1){
            return list[index_check]["cp_value"].toString()
        }
        return  ""
    }

    override fun getLayoutView(): View {
        mBinding = FrgGiftNormalBinding.inflate(layoutInflater);
        return mBinding.root
    }

    override fun onResume() {
        super.onResume()
//        requestData()
//        home.a88(this)
    }

    fun refreshData(){
        home.a88(this)
    }

    companion object {

        fun create(type: String): GiftPackpageFrg {
            val fragment = GiftPackpageFrg()
            val bundle = Bundle()
            bundle.putString("type", type)
            fragment.arguments = bundle
            return fragment
        }

    }

    override fun requestData() {
        mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.loading)
        home.a88(this)
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)

        var mLayoutManager = GridLayoutManager(requireContext(), 4)
        mLayoutManager.orientation = RecyclerView.VERTICAL
        mBinding.recyclerview.layoutManager = mLayoutManager
        mAdapter = GoldRecyclerAdapter()
        mBinding.recyclerview.adapter = mAdapter

        mBinding.loading.setLoadingTipXReloadCallback(object : XLoadTip.LoadingTipXReloadCallback {
            override fun reload() {
                requestData()
            }
        })

    }

    override fun onComplete(var2: String?, type: String?) {
        super.onComplete(var2, type)

        LogUtil.e("onComplete")
        if (type == "user/package") {
            var map = JSONUtils.parseKeyAndValueToMap(var2)
            if (map["code"] == "200") {
                mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.finish)
                var str = AESCBCCrypt.aesDecrypt(map["data"])
                var mList = JSONUtils.parseKeyAndValueToMapList(str)
//                index_check = 0
                list.clear()
                list.addAll(mList)
                mAdapter?.notifyDataSetChanged()
            } else {
                mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.error)
            }
        }
        if (type == "select/frame") {
            stopProgressDialog()
            var map = JSONUtils.parseKeyAndValueToMap(var2)
            showToastS(map["message"])
            if (map["code"] == "200") {
                requestData()
//                mAdapter?.notifyItemChanged(index_click)
            }else{

            }
        }

    }

    override fun onExceptionType(type: String?) {
        super.onExceptionType(type)
        stopProgressDialog()
        if (type == "user/package") {
            mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.error)
        }
    }

    inner class GoldRecyclerAdapter : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
            return fGoldViewHolder(ItemGiftPackBinding.inflate(LayoutInflater.from(context)))
        }

        override fun getItemCount(): Int = list.size

        override fun getItemViewType(position: Int): Int {
            return position
        }

        override fun onBindViewHolder(holder: RecyclerView.ViewHolder, @SuppressLint("RecyclerView") position: Int) {

            if (holder is fGoldViewHolder) {

                with(holder) {
                    with(mBinding) {

                        var maxW = AutoUtils.getPercentWidthSizeBigger(400)
                        ImageLoader.loadImageAes(requireActivity(), list[position]["cover"], ivCover, maxW, maxW)
                        tvName.text = list[position]["title"]
                        if (list[position]["module"] == "frame") {
                            tvTime.text = list[position]["expired_at"].toString().substring(0,10) + "\n过期"
                            if (list[position]["is_select"] == "1") {
                                tvHasFrame.text = "已佩戴"
                            } else {
                                tvHasFrame.text = "已拥有"
                            }
                        }else{
                            tvHasFrame.visibility = View.GONE
                            tvTime.text = "x"+list[position]["num"]

                            if (position == index_check) {
                                relayBg.setBackgroundResource(R.drawable.shape_54)
                                tvInfo.visibility = View.VISIBLE

                            } else {
                                tvInfo.visibility = View.GONE
//                                relayBg.setBackgroundColor(Color.parseColor("#ffffff"))
                                relayBg.setBackgroundResource(R.drawable.shape_97)
                            }
                        }

                        itemView.setOnLongClickListener {
                            if (position == index_check) {
//                                showToastS("ddd")
                                if (mGiftInfoDialog == null){
                                    mGiftInfoDialog = GiftInfoDialog(requireActivity() as BaseAty)

                                }
                                mGiftInfoDialog?.show()
                                mGiftInfoDialog?.setData(list[position]["remark"].toString(),
                                    list[position]["title"].toString())
                            }

                            true
                        }

                        itemView.setOnClickListener {
                            index_click = position
                            if (list[position]["module"] == "frame"){
                                if (mShopDg2 == null){
                                    mShopDg2 = Shop2Dg(this@GiftPackpageFrg.requireActivity() as BaseAty)
                                }
                                mShopDg2?.show()
                                mShopDg2?.setShop2DgListen(object : Shop2Dg.Shop2DgListen{
                                    override fun click() {

                                        if (index_click == -1){
                                            return
                                        }

                                        var is_select =""

                                        if (list[position]["is_select"] == "1"){
                                            is_select ="0"
                                        }else{
                                            is_select ="1"
                                        }

                                        startProgressDialog()
                                        home.a87(list[index_click]["related_id"].toString(),is_select,this@GiftPackpageFrg)

                                    }

                                })

                                mShopDg2?.setData(
                                    list[position]["is_select"].toString(),
                                    list[position]["title"].toString(),
                                    list[position]["cover"].toString(),
                                    info_avatar)

                            }else{

                                mGiftPackpageFrgListen?.showCpValue(list[position]["cp_value"].toString())
                                index_check = position
                                notifyDataSetChanged()

                            }
                        }

                    }
                }

            }

        }

        inner class fGoldViewHolder(binding: ItemGiftPackBinding) :
            RecyclerView.ViewHolder(binding.root) {
            var mBinding: ItemGiftPackBinding = binding

            init {
                AutoUtils.autoSize(binding.root)

            }
        }

    }

}
package com.mail.myapplication.ui.websocket


import android.util.Log
import com.mail.comm.utils.JSONUtils


import org.java_websocket.client.WebSocketClient
import org.java_websocket.drafts.Draft_6455
import org.java_websocket.handshake.ServerHandshake

import java.net.URI

class JWebSClient(serverUri: URI, socketClient: SocketClient?, map: java.util.HashMap<String, String>) : WebSocketClient(serverUri, Draft_6455(), map, 1000 * 100) {


    private var socketClient:SocketClient?=null
    init {
        this.socketClient =socketClient
    }

    override fun onOpen(handshakedata: ServerHandshake) {
        Log.e("JWebSClient", "连接打开onOpen")
    }

    override fun onMessage(message: String) {
        Log.e("JWebSClient", message)
//        if(message == "Pong"){
//            return
//        }
//        socketClient?.returnMsg(message)
//        val map = JSONUtils.parseKeyAndValueToMap(message)
//        if (map["event_id"]=="10013"){
//            SocketClient.getInstance()?.sendMsg(MsgUtils.getLoginMsgGson())
//        }
    }

    override fun onClose(code: Int, reason: String, remote: Boolean) {}

    override fun onError(ex: Exception) {
        Log.e("JWebSClient", "错误 onError"+ex.toString())
    }
}

package com.mail.myapplication.ui.mine.person

import android.os.Bundle
import android.view.Gravity
import android.view.View
import com.mail.comm.base.BaseAty
import com.mail.comm.base.BaseDialog
import com.mail.myapplication.R
import com.mail.myapplication.databinding.DgPersonOtherMoreBinding

class PersonOtherMoreDg(context: BaseAty) : BaseDialog(context) {

    lateinit var mBinding: DgPersonOtherMoreBinding

    var mPersonOtherMoreDgListen: PersonOtherMoreDgListen? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        mBinding = DgPersonOtherMoreBinding.inflate(layoutInflater);
        setContentView(mBinding.root)
        window?.setWindowAnimations(R.style.dialogFullscreen3)
        val dialogWindow = window

        dialogWindow!!.setBackgroundDrawable(null)
        dialogWindow.setGravity(Gravity.BOTTOM)
        setCanceledOnTouchOutside(true)
        val m = baseAty.windowManager
        val d = m.defaultDisplay// 获取屏幕宽、高
        val p = dialogWindow.attributes
        window?.getDecorView()?.setPadding(0, 0, 0, 0)
        p.width = (d.width * 1) // 宽度设置为屏幕的0.85
        dialogWindow.attributes = p

        mBinding.tvCancel.setOnClickListener {
            dismiss()
        }

        mBinding.tvAtten.setOnClickListener {
            dismiss()
            mPersonOtherMoreDgListen?.onClickAtten()
        }

        mBinding.tvReport.setOnClickListener {
            dismiss()
            mPersonOtherMoreDgListen?.onClickReport()
        }

        mBinding.tvBlack.setOnClickListener {
            dismiss()
            mPersonOtherMoreDgListen?.onClickBlack()
        }

    }

    interface PersonOtherMoreDgListen{
       fun  onClickAtten()
       fun  onClickReport()
       fun  onClickBlack()
    }

    fun setPersonOtherMoreDgListen(mPersonOtherMoreDgListen: PersonOtherMoreDgListen){
        this.mPersonOtherMoreDgListen = mPersonOtherMoreDgListen;
    }

    fun setData(follow:String,nickname:String){
        if (isShowing){
            mBinding.tvNickname.text = nickname
            if (follow == "1"){
                mBinding.tvAtten.visibility = View.VISIBLE
                mBinding.tvAtten.visibility = View.VISIBLE
            }else{
                mBinding.tvAtten.visibility = View.GONE
                mBinding.tvAtten.visibility = View.GONE
            }
        }
    }

    fun setDataChat(follow:String){
        if (isShowing){
            mBinding.tvNickname.visibility = View.GONE
            if (follow == "1"){
                mBinding.tvAtten.text = "取消关注"
            }else{
                mBinding.tvAtten.text = "关注"
            }
        }
    }


}
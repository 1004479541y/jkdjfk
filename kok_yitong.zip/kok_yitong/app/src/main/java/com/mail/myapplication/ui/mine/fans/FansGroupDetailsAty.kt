package com.mail.myapplication.ui.mine.fans

import android.os.Bundle
import android.text.TextUtils
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.mail.comm.app.BaseApp
import com.mail.comm.image.ImageLoader
import com.mail.comm.net.AESCBCCrypt
import com.mail.comm.utils.JSONUtils
import com.mail.comm.view.load.XLoadTip
import com.mail.comm.view.refresh.XRefreshInterface
import com.mail.myapplication.BaseXAty
import com.mail.myapplication.R
import com.mail.myapplication.databinding.*
import com.mail.myapplication.interfaces.Lar
import com.mail.myapplication.ui.dg.FansDialog
import com.mail.myapplication.ui.dg.JoinGroupDialog
import com.mail.myapplication.ui.dg.QuitGroupDialog
import com.mail.myapplication.ui.mine.person.PersonDetailsAty
import com.mail.myapplication.ui.mine.person.PersonOtherDetailsAty
import com.yhz.adaptivelayout.utils.AutoUtils

class FansGroupDetailsAty : BaseXAty() {

    lateinit var mBinding: AtyFansGroupDetailsBinding

    var rate = ""
    var page = 1
    var user_id =""
    var user_id_my =""
    var id_group =""
    var user_name =""
    var lar = Lar()
    var str_group = ""
    var has_fans_group = ""
    var info_is_creator = ""

    var fansDialog: FansDialog? = null
    var mAdapter: GoldRecyclerAdapter? = null
    var joinGroupDialog: JoinGroupDialog? = null
    var quitGroupDialog: QuitGroupDialog? = null
    var list = ArrayList<MutableMap<String, String>>()

    override fun getLayoutId(): Int = 0

    override fun getLayoutView(): View {
        mBinding = AtyFansGroupDetailsBinding.inflate(layoutInflater);
        return mBinding.root
    }

    override fun initView() {
        user_id = intent.getStringExtra("user_id").toString()
        user_name = intent.getStringExtra("user_name").toString()
        user_id_my = BaseApp.instance?.getOneMapData("info_code").toString()
        info_is_creator =BaseApp.instance?.getOneMapData("info_is_creator").toString()
    }

    override fun requestData() {
        mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.loading)
        requestData2()
    }

    fun requestData2(){
        lar.b25(page,user_id,this)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        initTopview2(mBinding.include.relayTopBg, resources.getString(R.string.c_4))

        mBinding.include.tvTitle.text = user_name

        var mLayoutManager2 = GridLayoutManager(this, 1)
        mLayoutManager2.orientation = RecyclerView.VERTICAL
        mBinding.recyclerview.layoutManager = mLayoutManager2
        mAdapter = GoldRecyclerAdapter()
        mBinding.recyclerview.adapter = mAdapter

        with(mBinding){
            swipeRefreshLayout.setEnableLoadmore(true)
            swipeRefreshLayout.setEnableRefresh(true)
            swipeRefreshLayout.setXRefreshAndLoadListen(object : XRefreshInterface {
                override fun refreshStart() {
                    page =1
                    requestData2()
                }

                override fun loadMoreStart() {
                    page++
                    requestData2()
                }

            })

            loading.setLoadingTipXReloadCallback(object: XLoadTip.LoadingTipXReloadCallback{
                override fun reload() {
                    requestData()
                }
            })

        }

    }

    override fun onComplete(var2: String?, type: String?) {
        super.onComplete(var2, type)

        if (type== "group/list"){
            mBinding.swipeRefreshLayout.finishRefreshing()
            mBinding.swipeRefreshLayout.finishLoadmore()
            mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.finish)
            var map = JSONUtils.parseKeyAndValueToMap(var2)
            if(map["code"]=="200"){
                lar.b26(user_id,this)
                var str = AESCBCCrypt.aesDecrypt(map["data"])
                var mList = JSONUtils.parseKeyAndValueToMapList(str)
                if (page == 1){
                    list.clear()
                    list.addAll(mList)
                }else{
                    list.addAll(mList)
                }

                mAdapter?.notifyDataSetChanged()

            }else{
//                if (page==1){
//                    mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.error)
//                }
            }
        }

        if (type == "group/info"){
            var map = JSONUtils.parseKeyAndValueToMap(var2)
            if(map["code"]=="200"){
                str_group = AESCBCCrypt.aesDecrypt(map["data"])

                var map_data_group = JSONUtils.parseKeyAndValueToMap(str_group)
                has_fans_group = map_data_group["has_fans_group"]!!

                if (has_fans_group == "n") {
                    mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.finish)
                    mBinding.relayEmpty.visibility = View.VISIBLE
                    if (user_id == user_id_my) {
                        mBinding.tvJoin.visibility = View.GONE
                        mBinding.tvCreate.visibility = View.VISIBLE
                        mBinding.tvEmpty.text = "開始創建屬於自己的私密團吧\n" +
                                "豐厚收益等你來拿，趕緊創建哦"
                    }else{
                        mBinding.tvJoin.visibility = View.GONE
                        mBinding.tvCreate.visibility = View.GONE
                        mBinding.tvEmpty.text = "TA还没创建私密團！"
                    }
                    return
                }

                mBinding.include.tvTitle.text = map_data_group["title"]
                id_group = map_data_group["id"].toString()
                lar.b28(id_group, this)

            }else{
                showToastS(map["message"])
                mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.error)
            }
        }

        if (type=="group/join"){
            stopProgressDialog()
            var map = JSONUtils.parseKeyAndValueToMap(var2)
            if(map["code"]=="200"){
                requestData()
            }else{
                showToastS(map["message"])
            }
        }

        if (type=="group/quit"){
            stopProgressDialog()
            var map = JSONUtils.parseKeyAndValueToMap(var2)
            if(map["code"]=="200"){
                requestData()
            }else{
                showToastS(map["message"])
            }
        }

        if (type == "user/rate") {
            var map = JSONUtils.parseKeyAndValueToMap(var2)
            if (map["code"] == "200") {
                mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.finish)

                var str = AESCBCCrypt.aesDecrypt(map["data"])
                var map_data = JSONUtils.parseKeyAndValueToMap(str)

                var maxW = AutoUtils.getPercentWidthSizeBigger(200)
                ImageLoader.loadImageAes(this@FansGroupDetailsAty, map_data["avatar"], mBinding.ivHead, maxW, maxW)


                when (map_data["type"]) {

                    "month" -> {
                        mBinding.imgvStatus.setImageResource(R.mipmap.ic_141)
                    }
                    "season" -> {
                        mBinding.imgvStatus.setImageResource(R.mipmap.ic_143)
                    }
                    "year" -> {
                        mBinding.imgvStatus.setImageResource(R.mipmap.ic_144)
                    }
                }

                mBinding.tvNick.text = map_data["nick"]
                mBinding.tvTotalDays.text = map_data["total_days"] + "亲密度"
                rate = map_data["rate"]!!

                if (rate == "0") {
                    mBinding.tvRate.text = "入團特權"
                } else {
                    mBinding.tvRate.text = "我的排名：" + map_data["rate"]
                }

                if (user_id != user_id_my) {
                    if (rate == "0") {
                        mBinding.tvCreate.visibility = View.GONE
                        mBinding.tvJoin.visibility = View.VISIBLE
                        mBinding.linlay01.visibility = View.VISIBLE
                        mBinding.relay01.visibility = View.GONE
                    } else {
                        mBinding.tvCreate.visibility = View.GONE
                        mBinding.tvJoin.visibility = View.GONE
                        mBinding.linlay01.visibility = View.GONE
                        mBinding.relay01.visibility = View.VISIBLE
                    }
                }

                if (list.size ==0&&user_id != user_id_my){
                    mBinding.relayEmpty.visibility = View.VISIBLE
                    mBinding.tvEmpty.text = "私密團虛位以待\n立即加入成為TA的第一位粉絲吧!"
                }else{
                    mBinding.relayEmpty.visibility = View.GONE
                }

            } else {
                mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.error)
                showToastS(map["message"])
            }

        }
    }

    override fun onExceptionType(type: String?) {
        super.onExceptionType(type)
        stopProgressDialog()
        if (type== "group/list"){
            mBinding.swipeRefreshLayout.finishRefreshing()
            mBinding.swipeRefreshLayout.finishLoadmore()
            if (page==1&&list.size==0){
                mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.error)
            }else{
                mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.finish)
            }
        }

        if (type == "group/info"){
            mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.error)
        }
        if (type == "user/rate"){
            mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.error)
        }
    }

    fun joinGroup(goldNum:String,type:String){
        if (joinGroupDialog == null) {
            joinGroupDialog = JoinGroupDialog(this)
            joinGroupDialog?.setRechargeListen(object : JoinGroupDialog.RechargeListen{
                override fun onclik01() {
                }

                override fun onclik02(type: String) {
                    startProgressDialog()
                    lar.b27(id_group,type,this@FansGroupDetailsAty)
                }

            })
        }
        joinGroupDialog?.show()
        joinGroupDialog?.setData(goldNum,user_name,type)
    }

    fun mainClick(v: View) {

        when (v.id) {

            R.id.relay_back -> {
                finish()
            }

            R.id.tv_create -> {
                if (info_is_creator == "0"){
                    showCommonDialog("1005",true,"创建私密團需要开通认证！是否要开通认证？","取消","去开通")
                    return
                }
                if (info_vip_level =="0"){
                    showCommonDialog("1006",true,"创建私密團需要开通VIP！是否要开通？","取消","去开通")
                    return
                }
                startActivity(FansGroupCreateAty::class.java)
            }

            R.id.tv_join -> {

                if (TextUtils.isEmpty(id_group)){
                    showToastS("该用户未创建私密團")
                    return
                }
                if (fansDialog == null) {
                    fansDialog = FansDialog(this)
                    fansDialog?.setPayListen(object : FansDialog.PayListen{
                        override fun toPay(type: String,goldNum:String) {
                            joinGroup(goldNum,type)
                            fansDialog?.cancel()
                        }
                    })
                }

                fansDialog?.show()
                fansDialog?.setData(str_group)
            }

            R.id.relay_fans_group_intro -> {
                startActivity(FansGroupIntroAty::class.java)
            }

            R.id.tv_quit_group->{

                if (quitGroupDialog == null) {
                    quitGroupDialog = QuitGroupDialog(this)
                    quitGroupDialog?.setRechargeListen(object: QuitGroupDialog.RechargeListen{
                        override fun onclik02() {
                            startProgressDialog()
                            lar.b29(id_group,this@FansGroupDetailsAty)
                        }

                    })
                }

                quitGroupDialog?.show()

            }

        }
    }

    inner class GoldRecyclerAdapter : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {

            return fGoldViewHolder(ItemFansGroupDetailsBinding.inflate(LayoutInflater.from(this@FansGroupDetailsAty)))

        }

        override fun getItemCount(): Int = list.size

        override fun getItemViewType(position: Int): Int {
            return position
        }

        override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {

            if (holder is fGoldViewHolder) {

                with(holder) {

                    with(mBinding){
                        var maxW = AutoUtils.getPercentWidthSizeBigger(200)
                        ImageLoader.loadImageAes(this@FansGroupDetailsAty,list[position]["avatar"],ivHead,maxW,maxW)

                        when(list[position]["type"]){

                            "month"->{
                                imgvStatus.setImageResource(R.mipmap.ic_141)
                            }
                            "season"->{
                                imgvStatus.setImageResource(R.mipmap.ic_143)
                            }
                            "year"->{
                                imgvStatus.setImageResource(R.mipmap.ic_144)
                            }
                        }

                        tvNick.text = list[position]["nick"]
                        tv02.text = list[position]["total_days"]+"亲密度"
                        tvRank.text = (position+1).toString()

                        when (position) {
                            0 -> {
                                tvRank.visibility = View.GONE
                                imgvRank.visibility = View.VISIBLE
                                imgvRank.setImageResource(R.mipmap.ic_160)
                            }
                            1 -> {
                                tvRank.visibility = View.GONE
                                imgvRank.visibility = View.VISIBLE
                                imgvRank.setImageResource(R.mipmap.ic_161)
                            }
                            2 -> {
                                tvRank.visibility = View.GONE
                                imgvRank.visibility = View.VISIBLE
                                imgvRank.setImageResource(R.mipmap.ic_162)
                            }
                            else -> {
                                tvRank.visibility = View.VISIBLE
                                imgvRank.visibility = View.GONE
                            }
                        }

                        itemView.setOnClickListener {

                            var bundle = Bundle()
                            if (list[position]["code"]==user_id_my){
                                bundle.putString("typePage","my")
                                startActivity(PersonDetailsAty::class.java,bundle)
                            }else{
                                bundle.putString("user_id",list[position]["code"])
                                startActivity(PersonOtherDetailsAty::class.java,bundle)
                            }

                        }
                    }
                }

            }

        }

        inner class fGoldViewHolder(binding: ItemFansGroupDetailsBinding) :
            RecyclerView.ViewHolder(binding.root) {
            var mBinding: ItemFansGroupDetailsBinding = binding

            init {
                AutoUtils.autoSize(binding.root)
            }
        }

    }


}
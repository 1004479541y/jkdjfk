package com.mail.myapplication.ui.dg

import android.os.Bundle
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.mail.comm.base.BaseAty
import com.mail.comm.base.BaseDialog
import com.mail.comm.net.AESCBCCrypt
import com.mail.comm.utils.JSONUtils
import com.mail.comm.utils.TimeUtils
import com.mail.comm.view.load.XLoadTip
import com.mail.myapplication.R
import com.mail.myapplication.databinding.DgVoiceRenewBinding
import com.mail.myapplication.databinding.ItemVoiceRenewBinding
import com.mail.myapplication.interfaces.Home
import com.mail.myapplication.interfaces.Lar
import com.yhz.adaptivelayout.utils.AutoUtils
import org.xutils.common.util.LogUtil

class VoiceRenewDialog(context: BaseAty) : BaseDialog(context) {

    lateinit var mBinding: DgVoiceRenewBinding
    var mAdapter:GoldRecyclerAdapter? = null
    var list = ArrayList<MutableMap<String, String>>()
    var home = Home()
    var lar = Lar()
    var index_check = 0
    var mVoiceRenewDialogListen:VoiceRenewDialogListen?=null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        mBinding = DgVoiceRenewBinding.inflate(layoutInflater);
        setContentView(mBinding.root)
        window?.setWindowAnimations(R.style.dialogFullscreen2)

        window!!.setBackgroundDrawable(null)
        window!!.setGravity(Gravity.CENTER)
        setCanceledOnTouchOutside(true)
        val m = baseAty.windowManager
        val d = m.defaultDisplay// 获取屏幕宽、高
        val p = window!!.attributes
        window?.getDecorView()?.setPadding(0, 0, 0, 0)
//        p.height =  (d.height * 1) // 高度设置为屏幕的0.6
        p.width = (d.width * 1) // 宽度设置为屏幕的0.85
        window!!.attributes = p

        with(mBinding){
            var mLayoutManager2 = GridLayoutManager(baseAty, 1)
            mLayoutManager2.orientation = RecyclerView.HORIZONTAL
            recyclerview.layoutManager = mLayoutManager2
            mAdapter = GoldRecyclerAdapter()
            recyclerview.adapter = mAdapter

            tvCoins.setOnClickListener {
                dismiss()
                mVoiceRenewDialogListen?.recharge()
            }

            tvBuy.setOnClickListener {
                dismiss()
                mVoiceRenewDialogListen?.buyTime(list[index_check]["id"])
            }

            relayCancel.setOnClickListener {
                dismiss()
            }
        }
    }

    interface VoiceRenewDialogListen {
        fun recharge()
        fun buyTime(time_id:String?)
    }

    fun setVoiceRenewDialogListen(mVoiceRenewDialogListen:VoiceRenewDialogListen){
        this.mVoiceRenewDialogListen =mVoiceRenewDialogListen
    }

    fun requestData() {
        if (isShowing) {
            home.a59(this)
            lar.b10(this)
        }
    }

    override fun onComplete(var2: String?, type: String?) {
        super.onComplete(var2, type)
        LogUtil.e("onComplete")
        if (type == "time/list") {
            var map = JSONUtils.parseKeyAndValueToMap(var2)
            if (map["code"] == "200") {
                mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.finish)
                var str = AESCBCCrypt.aesDecrypt(map["data"])
                var mList = JSONUtils.parseKeyAndValueToMapList(str)
                list.clear()
                list.addAll(mList)
                mAdapter?.notifyDataSetChanged()
            } else {
                mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.error)
            }
        }

        if (type == "wallet/info") {
            var map = JSONUtils.parseKeyAndValueToMap(var2)
            if (map["code"] == "200") {
                var str_wallet = AESCBCCrypt.aesDecrypt(map["data"])
                var map_info = JSONUtils.parseKeyAndValueToMap(str_wallet)
                mBinding.tvCoins.text = "金幣餘額：${map_info["coins"]} 立即充值>>"
            }
        }

    }


    override fun onExceptionType(type: String?) {
        super.onExceptionType(type)
        if (type == "time/list") {
            mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.error)
        }
    }


    inner class GoldRecyclerAdapter : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
            return fGoldViewHolder(ItemVoiceRenewBinding.inflate(LayoutInflater.from(context)))
        }

        override fun getItemCount(): Int = list.size

        override fun getItemViewType(position: Int): Int {
            return position
        }

        override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {

            if (holder is fGoldViewHolder) {

                with(holder) {
                    with(mBinding) {

                        itemView.setOnClickListener {
                            index_check = position
                            notifyDataSetChanged()
                        }

                        if (position == index_check) {
                            linlayBg.setBackgroundResource(R.drawable.shape_54)
                            imgvCheck.visibility = View.VISIBLE
                        } else {
                            linlayBg.setBackgroundResource(R.drawable.shape_73)
                            imgvCheck.visibility = View.GONE
                        }
//                       var time = TimeUtils.formatSecond5(list[position]["second"]?.toDouble())
                        tvTime.text = list[position]["title"]
                        tvCoins.text = list[position]["coins"]

                    }
                }

            }

        }

        inner class fGoldViewHolder(binding: ItemVoiceRenewBinding) :
            RecyclerView.ViewHolder(binding.root) {
            var mBinding: ItemVoiceRenewBinding = binding

            init {
                AutoUtils.autoSize(binding.root)

            }
        }

    }


}
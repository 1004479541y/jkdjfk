package com.mail.myapplication.ui.app;

import android.content.Context;
import android.text.TextUtils;
import android.util.Log;

import com.mail.comm.app.BaseApp;
import com.mail.comm.net.AESCBCCrypt;
import com.mail.comm.utils.JSONUtils;
import com.mail.comm.utils.PreferencesUtils;
import com.mail.comm.utils.TimeUtils;
import com.mail.myapplication.ui.msg.database.ChatUtils;
import com.mail.myapplication.ui.utils.VirateUtil;

import org.xutils.common.util.LogUtil;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import io.agora.rtm.RtmClient;
import io.agora.rtm.RtmClientListener;
import io.agora.rtm.RtmFileMessage;
import io.agora.rtm.RtmImageMessage;
import io.agora.rtm.RtmMediaOperationProgress;
import io.agora.rtm.RtmMessage;
import io.agora.rtm.SendMessageOptions;

public class RtmManager {

    private static final String TAG = RtmManager.class.getSimpleName();
    private Context mContext;
    private RtmClient mRtmClient;
    private SendMessageOptions mSendMsgOptions;
    private List<RtmClientListener> mListenerList = new ArrayList<>();

    public RtmManager(Context context) {
        mContext = context;
    }

    public void init() {

        String appID = PreferencesUtils.getString(mContext, "rtm_app_id");
        try {
            mRtmClient = RtmClient.createInstance(mContext, appID, new RtmClientListener() {

                @Override
                public void onConnectionStateChanged(int state, int reason) {

                    for (RtmClientListener listener : mListenerList) {
                        listener.onConnectionStateChanged(state, reason);
                    }
                }

                @Override
                public void onMessageReceived(RtmMessage rtmMessage, String peerId) {
                    String str = AESCBCCrypt.aesDecrypt(rtmMessage.getText());
                    LogUtil.e("onMessageReceived ChatManager=" + str + "," + peerId);
                    Map<String, String> map = JSONUtils.parseKeyAndValueToMap(str);
                    if (map.get("type").equals("20")) {
                        String notice_type = map.get("notice_type");
                        if (notice_type.equals("201") || notice_type.equals("203")) {

                            double c_time = Double.parseDouble(TimeUtils.getBeijinTime());

                            String time_end_notice = BaseApp.Companion.getInstance().getEndNoticeTime();

                            if (!TextUtils.isEmpty(time_end_notice)){

                                double end_time = Double.parseDouble(BaseApp.Companion.getInstance().getEndNoticeTime());

                                if (c_time < end_time) {
                                    return;
                                }

                            }

                            String  is_chat =BaseApp.Companion.getInstance().getOneMapData("is_chat");

                            if (is_chat == "1"){
                                return;
                            }

                            String  isVibrate =BaseApp.Companion.getInstance().getOneMapData("isVibrate");

                            if (isVibrate =="1"||TextUtils.isEmpty(isVibrate)){
                                VirateUtil.vibrate(new long[]{1000, 1000, 1000, 1000}, -1);
                            }

                            Double time_end = c_time + 1000 * 15;
                            HashMap<String, String> map_msg = new HashMap<>();
                            map_msg.put("is_read", "0");
                            map_msg.put("time_end", time_end + "");
                            map_msg.put("msg", rtmMessage.getText());
                            BaseApp.Companion.getInstance().addOneNoticeMsg(map_msg);
                        }
                    }

                    if (mListenerList.isEmpty()) {
                        ChatUtils.Companion.saveChatpannel(rtmMessage.getText(), false);
//                      mMessagePool.insertOfflineMessage(rtmMessage, peerId);
                    } else {
                        for (RtmClientListener listener : mListenerList) {
                            listener.onMessageReceived(rtmMessage, peerId);
                        }
                    }
                }

                @Override
                public void onImageMessageReceivedFromPeer(final RtmImageMessage rtmImageMessage, final String peerId) {
                    if (mListenerList.isEmpty()) {
                        // If currently there is no callback to handle this
                        // message, this message is unread yet. Here we also
                        // take it as an offline message.
//                        mMessagePool.insertOfflineMessage(rtmImageMessage, peerId);
                    } else {
                        for (RtmClientListener listener : mListenerList) {
                            listener.onImageMessageReceivedFromPeer(rtmImageMessage, peerId);
                        }
                    }
                }

                @Override
                public void onFileMessageReceivedFromPeer(RtmFileMessage rtmFileMessage, String s) {

                }

                @Override
                public void onMediaUploadingProgress(RtmMediaOperationProgress rtmMediaOperationProgress, long l) {

                }

                @Override
                public void onMediaDownloadingProgress(RtmMediaOperationProgress rtmMediaOperationProgress, long l) {

                }

                @Override
                public void onTokenExpired() {

                }

                @Override
                public void onPeersOnlineStatusChanged(Map<String, Integer> status) {

                }
            });

//            if (BuildConfig.DEBUG) {
//                mRtmClient.setParameters("{\"rtm.log_filter\": 65535}");
//            }
        } catch (Exception e) {
            Log.e(TAG, Log.getStackTraceString(e));
            throw new RuntimeException("NEED TO check rtm sdk init fatal error\n" + Log.getStackTraceString(e));
        }

        // Global option, mainly used to determine whether
        // to support offline messages now.
        mSendMsgOptions = new SendMessageOptions();
    }

    public RtmClient getRtmClient() {
        return mRtmClient;
    }

    public void registerListener(RtmClientListener listener) {
        mListenerList.add(listener);
    }

    public void unregisterListener(RtmClientListener listener) {
        mListenerList.remove(listener);
    }

    public void enableOfflineMessage(boolean enabled) {
        mSendMsgOptions.enableOfflineMessaging = enabled;
    }

    public void enableHistoricalMessage(boolean enabled) {
        mSendMsgOptions.enableHistoricalMessaging = enabled;
    }

    public SendMessageOptions getSendMessageOptions() {
        return mSendMsgOptions;
    }


}

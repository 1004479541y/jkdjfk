package com.mail.myapplication.ui.mine.daresquare

import android.os.Build
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.PagerSnapHelper
import androidx.recyclerview.widget.RecyclerView
import com.mail.comm.image.ImageLoader
import com.mail.comm.net.AESCBCCrypt
import com.mail.comm.utils.JSONUtils
import com.mail.comm.view.load.XLoadTip
import com.mail.comm.view.refresh.XRefreshInterface
import com.mail.myapplication.BaseXAty
import com.mail.myapplication.R
import com.mail.myapplication.databinding.*
import com.mail.myapplication.interfaces.Home
import com.mail.myapplication.interfaces.Lar
import com.mail.myapplication.ui.dg.DarenLeveDialog
import com.mail.myapplication.ui.mine.apply.AuthAty
import com.yhz.adaptivelayout.utils.AutoUtils
import org.xutils.common.util.LogUtil


class DarenSquareLeveAty : BaseXAty() {

    lateinit var mBinding: AtyDarenLeveBinding
    var lar = Lar()
    var list = ArrayList<MutableMap<String, String>>()
    var list2 = ArrayList<MutableMap<String, String>>()
    var home = Home()
    var vip_level = 0
    var group_value = 0
    var currentPositon = 0
    var creator_status =""

    lateinit var mAdapter: GoldRecyclerAdapter
    lateinit var mAdapter2: GoldRecyclerAdapter2

    var map_user_data: MutableMap<String, String>? = null

    var mDarenLeveDialog: DarenLeveDialog? = null

    override fun getLayoutId(): Int = 0

    override fun getLayoutView(): View {
        mBinding = AtyDarenLeveBinding.inflate(layoutInflater);
        return mBinding.root
    }

    override fun initView() {
        creator_status = intent.getStringExtra("creator_status").toString()
    }

    override fun requestData() {
        currentPositon = 0
        mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.loading)
        home.a89(this)
    }

    fun requestData2(){
        currentPositon = 0
        home.a89(this)
    }


    override fun onComplete(var2: String?, type: String?) {
        super.onComplete(var2, type)

        if (type == "pay/guarantee"){
            stopProgressDialog()
            var map = JSONUtils.parseKeyAndValueToMap(var2)
            if (map["code"] == "200") {
                requestData()
            }
            showToastS(map["message"])
        }

        if (type == "level/detail") {
            mBinding.swipeRefreshLayout.finishRefreshing()
            mBinding.swipeRefreshLayout.finishLoadmore()
            mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.finish)
            var map = JSONUtils.parseKeyAndValueToMap(var2)
            if (map["code"] == "200") {
                var str = AESCBCCrypt.aesDecrypt(map["data"])
                var map_data = JSONUtils.parseKeyAndValueToMap(str)
                map_user_data = JSONUtils.parseKeyAndValueToMap(map_data["user_data"])

                vip_level = map_user_data!!["vip_level"]!!.toInt()
                group_value = map_user_data!!["group_value"]!!.toInt()

                list = JSONUtils.parseKeyAndValueToMapList(map_data["level_data"])
                mAdapter.notifyDataSetChanged()
                updateData()

                var maxW = AutoUtils.getPercentWidthSizeBigger(200)
                ImageLoader.loadImageAes(this,
                    map_user_data!!["avatar"],
                    mBinding.ivHead,
                    maxW,
                    maxW)
                mBinding.tvNick.text = map_user_data!!["nick"]


            } else {
                mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.error)
            }
        }
    }

    override fun onExceptionType(type: String?) {
        super.onExceptionType(type)
        stopProgressDialog()
        if (type == "level/detail") {
            mBinding.swipeRefreshLayout.finishRefreshing()
            mBinding.swipeRefreshLayout.finishLoadmore()
            mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.error)
        }
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        initTopview2(mBinding.include.relayTopBg, resources.getString(R.string.c_4))
        mBinding.include.tvTitle.text = "達人等級"

        val layoutManager = LinearLayoutManager(this)
        layoutManager.orientation = LinearLayoutManager.HORIZONTAL
        mBinding.recyclerview.layoutManager = layoutManager

        mAdapter = GoldRecyclerAdapter()
        mBinding.recyclerview.adapter = mAdapter
        initLevel()

//      layoutManager.smoothScrollToPosition(mBinding.recyclerview, RecyclerView.State(), 1)
        //加在setAdapter后面
        //加在setAdapter后面
        val snapHelper = PagerSnapHelper()
        snapHelper.attachToRecyclerView( mBinding.recyclerview)

        mBinding.swipeRefreshLayout.setEnableLoadmore(false)
        mBinding.swipeRefreshLayout.setEnableRefresh(true)
        mBinding.swipeRefreshLayout.setXRefreshAndLoadListen(object : XRefreshInterface {
            override fun refreshStart() {
                requestData2()
            }

            override fun loadMoreStart() {
            }

        })

        mBinding.loading.setLoadingTipXReloadCallback(object : XLoadTip.LoadingTipXReloadCallback {
            override fun reload() {
                requestData()
            }

        })

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            mBinding.recyclerview.setOnScrollListener(object : RecyclerView.OnScrollListener() {

                override fun onScrollStateChanged(recyclerView: RecyclerView, newState: Int) {
                    super.onScrollStateChanged(recyclerView, newState)

                    if (newState == RecyclerView.SCROLL_STATE_IDLE){
                        var snapview= snapHelper.findSnapView(layoutManager)
                        if (layoutManager!=null && snapview!=null){
                            var currentIndex  = layoutManager.getPosition(snapview)
                            if (currentIndex!=currentPositon){
                                currentPositon = currentIndex
                                updateData()
//                                showToastS(currentPositon.toString())
                            }
                        }
                    }
                }

                override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
                    super.onScrolled(recyclerView, dx, dy)
                    var snapview= snapHelper.findSnapView(layoutManager)
                    if (layoutManager!=null && snapview!=null){
                        var currentIndex  = layoutManager.getPosition(snapview)
                        if (currentIndex!=currentPositon){
                            currentPositon = currentIndex
                            updateData()
//                            showToastS(currentPositon.toString())
                        }
                    }
                }
            })
        }
    }

    fun updateData() {
        list2 = JSONUtils.parseKeyAndValueToMapList(list[currentPositon]["with_level_right"])
        LogUtil.e("updateData=" + list[currentPositon]["with_level_right"])
        mAdapter2.notifyDataSetChanged()
    }

    fun initLevel() {
        val layoutManager = LinearLayoutManager(this)
        layoutManager.orientation = RecyclerView.VERTICAL
        mBinding.recyclerview2.layoutManager = layoutManager
        mAdapter2 = GoldRecyclerAdapter2()
        mBinding.recyclerview2.adapter = mAdapter2
        mBinding.recyclerview2?.isNestedScrollingEnabled = false
    }

    fun mainClick(v: View) {

        when (v.id) {

            R.id.relay_back -> {
                finish()
            }

        }
    }


    inner class GoldRecyclerAdapter : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
            return fGoldViewHolder(ItemDarenLeveBinding.inflate(LayoutInflater.from(this@DarenSquareLeveAty)))
        }

        override fun getItemCount(): Int = list.size


        override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {

            if (holder is fGoldViewHolder) {

                with(holder) {
                    with(mBinding) {

                        tvLevel.text = "Lv${list[position]["level"]}/${list[position]["title"]}"
                        tvVaule.text = "当前贡献值 ${map_user_data!!["group_value"]}"

                        var maxW = AutoUtils.getPercentWidthSizeBigger(400)

                        var is_pay_guarantee = list[position]["is_pay_guarantee"]
                        var guarantee_money = list[position]["guarantee_money"]
                        var is_current_level = list[position]["is_current_level"]

                        ImageLoader.loadImageAes(this@DarenSquareLeveAty,
                            list[position]["icon"],
                            mBinding.imgvSign,
                            maxW,
                            maxW)

                        var level = list[position]["level"]!!.toInt()
                        var level_max = list[list.size - 1]["level"]!!.toInt()

                        tv1.text = "Lv" + list[position]["level"]


                        if (is_current_level == "1") {
                            if (is_pay_guarantee == "1"){
                                imgvBuy.visibility = View.GONE
                                tvGuarantee.visibility = View.VISIBLE
                                tvGuarantee.text = "${guarantee_money}保证金"

                            }else{
                                tvDes.visibility = View.VISIBLE
                                imgvBuy.visibility = View.VISIBLE
                                imgvBuy.setImageResource(R.drawable.ia_60)
                                tvGuarantee.visibility = View.GONE
                            }

                            if (level_max != level) {
                                if (position < list.size - 1) {
                                    var group_value_next =
                                        list[position + 1]["min_group_value"]!!.toInt()
                                    var s = group_value_next - group_value.toInt()
                                    tvDes.text = "距下一等级还差  ${s} 贡献值"
                                }
                            }

                        } else {

                            if (level < vip_level) {
                                imgvBuy.visibility = View.GONE
                            } else {
                                imgvBuy.visibility = View.VISIBLE
                                imgvBuy.setImageResource(R.drawable.ia_13)
                            }
                            tvDes.visibility = View.GONE
                        }

                        if (creator_status != "1"){
                            imgvBuy.visibility = View.VISIBLE
                            imgvBuy.setImageResource(R.drawable.ia_76)
                        }

                        mBinding.imgvBuy.setOnClickListener {

                            if (creator_status != "1"){
                                var bundle = Bundle()
                                bundle.putString("creator_status", creator_status)
                                startActivity(AuthAty::class.java,bundle)
                                return@setOnClickListener
                            }

                            if (level > vip_level) {
                                if (mDarenLeveDialog == null) {
                                    mDarenLeveDialog = DarenLeveDialog(this@DarenSquareLeveAty)
                                }
                                mDarenLeveDialog?.show()
                                mDarenLeveDialog?.setRechargeListen(object :
                                    DarenLeveDialog.DarenLeveDialogListen{
                                    override fun buy(info:String) {
                                        startProgressDialog()
                                        home.a92(guarantee_money.toString(),level.toString(),info,this@DarenSquareLeveAty)
                                    }

                                })
                                mDarenLeveDialog?.setData(guarantee_money!!)
                            }

                        }
                    }
                }

            }

        }

        inner class fGoldViewHolder(binding: ItemDarenLeveBinding) :
            RecyclerView.ViewHolder(binding.root) {
            var mBinding: ItemDarenLeveBinding = binding

            init {
                AutoUtils.autoSize(binding.root)
            }
        }

    }


    inner class GoldRecyclerAdapter2 : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
            return fGoldViewHolder(ItemTestBinding.inflate(LayoutInflater.from(this@DarenSquareLeveAty)))
        }

        override fun getItemCount(): Int = list2.size

        override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {

            if (holder is fGoldViewHolder) {

                with(holder) {
                    with(mBinding) {
                        var maxW = AutoUtils.getPercentWidthSizeBigger(400)
                        ImageLoader.loadImageAes(this@DarenSquareLeveAty,
                            list2[position]["cover"],
                            imgv,
                            maxW,
                            maxW)
                        tvTitle.text = list2[position]["title"]
                        tvDes.text = list2[position]["remark"]
                        LogUtil.e("onBindViewHolder==" + list2[position]["cover"])

                    }
                }

            }

        }

        inner class fGoldViewHolder(binding: ItemTestBinding) :
            RecyclerView.ViewHolder(binding.root) {
            var mBinding: ItemTestBinding = binding

            init {
                AutoUtils.autoSize(binding.root)

            }
        }

    }


}
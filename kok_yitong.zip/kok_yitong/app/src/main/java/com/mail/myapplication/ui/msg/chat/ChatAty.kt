package com.mail.myapplication.ui.msg.chat

import android.annotation.SuppressLint
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Message
import android.text.TextUtils
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.Toast
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.mail.comm.app.AppConfig
import com.mail.comm.app.BaseApp
import com.mail.comm.function.chooseimg.ChooseImgAty
import com.mail.comm.image.ImageLoader
import com.mail.comm.net.AESCBCCrypt
import com.mail.comm.utils.*
import com.mail.comm.view.load.XLoadTip
import com.mail.comm.view.refresh.XRefreshInterface
import com.mail.myapplication.BaseXAty
import com.mail.myapplication.R
import com.mail.myapplication.databinding.*
import com.mail.myapplication.interfaces.Home
import com.mail.myapplication.interfaces.Lar
import com.mail.myapplication.ui.MainWalletAty
import com.mail.myapplication.ui.dg.gift.GiftDialog
import com.mail.myapplication.ui.bigimg.BigImgListAty
import com.mail.myapplication.ui.dg.AttenDialog
import com.mail.myapplication.ui.dg.ChatOrderAssessDialog
import com.mail.myapplication.ui.find.MatchVoiceAty
import com.mail.myapplication.ui.find.MatchVoiceCpDg
import com.mail.myapplication.ui.find.MatchVoiceCpRuleDg
import com.mail.myapplication.ui.mine.person.PersonOtherDetailsAty
import com.mail.myapplication.ui.mine.person.PersonOtherMoreDg
import com.mail.myapplication.ui.mine.person.cp.PersonCpAty
import com.mail.myapplication.ui.mine.person.cp.PersonCpDetailsAty
import com.mail.myapplication.ui.utils.SvgaUtils
import com.mail.myapplication.ui.msg.database.ChatUtils
import com.mail.myapplication.ui.utils.MyUtils3
import com.opensource.svgaplayer.SVGACallback
import com.yhz.adaptivelayout.utils.AutoUtils
import io.agora.rtm.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.xutils.common.util.LogUtil
import org.xutils.x

class ChatAty : BaseXAty() {

    var lar = Lar()
    var home = Home()

    var to_nick = ""           //对方信息
    var to_avatar = ""
    var to_user_code = ""
    var nick = ""             //我的信息
    var avatar = ""
    var user_code = ""

    var resource_cdn = ""        //图片域名
    var vip_level = ""
    var enter_type = ""          //进入类型 match = 文字匹配
    var match_voice_id = ""      // 匹配id
    var match_id = ""            // 匹配id

    var sendNum = 1
    var sendMaxNum = 3           //发送限制
    var receiveNum = 0
    var receiveMaxNum = 1        //接收限制

    var filter_data_list = ArrayList<String>()
    var pattern_data_list = ArrayList<String>()
    var map_json: MutableMap<String, String>? = null
    var list = ArrayList<MutableMap<String, String>>()
    var map_service_info: MutableMap<String, String>? = null

    var is_send_pic = "0"
    var is_follow = ""
    var min_unfollow_coins = ""
    var cp_value = 0
    var min_cp_value = 0

    lateinit var mBinding: AtyChatBinding
    lateinit var mAdapter: GoldRecyclerAdapter
    var mAdapter2: GoldRecyclerAdapter2? = null

    var svgUtils: SvgaUtils? = null
    var giftDialog: GiftDialog? = null
    var mAttenDialog: AttenDialog? = null
    var mMatchVoiceCpDg: MatchVoiceCpDg? = null
    var mMatchVoiceCpRuleDg: MatchVoiceCpRuleDg? = null
    var mPersonOtherMoreDg: PersonOtherMoreDg? = null
    var mChatOrderAssessDialog: ChatOrderAssessDialog? = null

    var cp_rule_content = ""
    var cp_detail_content = ""
    var is_enter_voice = ""

    override fun getLayoutId(): Int = 0

    override fun initView() {

        BaseApp.instance?.saveOneMapData("is_chat", "1")

        resource_cdn = PreferencesUtils.getString(this, "resource_cdn")
        user_code = PreferencesUtils.getString(this, "info_code")
        nick = PreferencesUtils.getString(this, "info_nick")
        avatar = PreferencesUtils.getString(this, "info_avatar")

        if (intent.hasExtra("enter_type")) {
            enter_type = intent.getStringExtra("enter_type").toString()
        }
//      enter_type = "match"

        if (intent.hasExtra("min_unfollow_coins")) {
            min_unfollow_coins = intent.getStringExtra("min_unfollow_coins").toString()
        }

        if (intent.hasExtra("match_id")) {
            match_id = intent.getStringExtra("match_id").toString()
        }

        if (intent.hasExtra("json")) {
            var json = intent.getStringExtra("json").toString()
            map_json = JSONUtils.parseKeyAndValueToMap(json)
            cp_value = map_json!!["cp_value"]!!.toInt()
            min_cp_value = map_json!!["min_cp_value"]!!.toInt()
            cp_rule_content = map_json!!["cp_rule_content"].toString()
            cp_detail_content = map_json!!["cp_detail_content"].toString()
        }

        if (intent.hasExtra("is_send_pic")) {
            is_send_pic = intent.getStringExtra("is_send_pic").toString()
        }

        if (intent.hasExtra("sendMaxNum")) {
            var mSendMaxNum = intent.getStringExtra("sendMaxNum").toString()
            sendMaxNum = mSendMaxNum.toInt()
        } else {
            var mSendMaxNum = BaseApp.instance?.getOneMapData("send_message_num")
            sendMaxNum = mSendMaxNum!!.toInt()
        }

        if (intent.hasExtra("receiveNum")) {
            var mReceiveNum = intent.getStringExtra("receiveNum").toString()
            receiveMaxNum = mReceiveNum.toInt()
        } else {
            var mReceiveNum = BaseApp.instance?.getOneMapData("receive_message_num")
            receiveMaxNum = mReceiveNum!!.toInt()
        }

        to_user_code = intent.getStringExtra("code").toString()
        to_nick = intent.getStringExtra("nick").toString()
        to_avatar = intent.getStringExtra("avatar").toString()

        vip_level = BaseApp.instance?.getOneMapData("info_vip_level").toString()

        var filter_data = MyUtils.getInfoDetails(this, "filter_data")
        var pattern_data = MyUtils.getInfoDetails(this, "android_pattern_data")

        if (!TextUtils.isEmpty(filter_data) && filter_data != "null") {
            filter_data_list = JSONUtils.parseKeyAndValueToListString(filter_data)
        }

        if (!TextUtils.isEmpty(pattern_data) && pattern_data != "null") {
            pattern_data_list = JSONUtils.parseKeyAndValueToListString(pattern_data)
        }

        setChatPannelIsRead()
        var service_info = PreferencesUtils.getString(this, "service_info")
        map_service_info = JSONUtils.parseKeyAndValueToMap(service_info)
        svgUtils = SvgaUtils()
        svgUtils?.loopAnimation(this, mBinding.mSVGAKninghtood)
        mBinding.mSVGAKninghtood.loops = 1
        mBinding.mSVGAKninghtood!!.callback = object : SVGACallback {
            override fun onPause() {}

            override fun onFinished() {
                svgUtils?.setIsPlay(false)
            }

            override fun onRepeat() {}

            override fun onStep(i: Int, v: Double) {}
        }
    }

    override fun onBackPressed() {
        if (enter_type == "match") {
            mBinding.relayBack.performClick()
            return
        }
        super.onBackPressed()
    }

    fun setChatPannelIsRead() {
        Thread {
            ChatUtils.setChatPannelIsRead(user_code, to_user_code)
        }.start()
    }

    var handler: Handler = @SuppressLint("HandlerLeak") object : Handler() {

        override fun handleMessage(msg: Message) {
            super.handleMessage(msg)

            when (msg.what) {

                1 -> {
                    mAdapter.notifyDataSetChanged()
                    mBinding.swipeRefreshLayout.finishLoadmore()
                    mBinding.swipeRefreshLayout.finishRefreshing()
                }

                2 -> {
                    mBinding.swipeRefreshLayout.finishRefreshing()
                }

                3 -> {
                    mAdapter.notifyItemRangeChanged(list.size, 1)
                    mBinding.recyclerview.scrollToPosition(list.size - 1)
                }
            }
        }
    }

    override fun requestData() {
        list.clear()
        mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.loading)
        home?.a45(1, to_user_code, "", this)
    }

    fun requestDataInfo() {
        home.a17(to_user_code, this)
    }

    fun requestDataInfoIsFllow() {
        home.a173(to_user_code, this)
    }


    fun requestDataMore() {
        var time = ""
        if (list != null && list.size > 0) {
            if (list[0].containsKey("ms")) {
                time = list[0]["ms"]!!
            } else {
                var msg = ""
                if (list[0].containsKey("msg")) {
                    msg = AESCBCCrypt.aesDecrypt(list[0]["msg"])
                } else {
                    msg = AESCBCCrypt.aesDecrypt(list[0]["payload"])
                }
                var map = JSONUtils.parseKeyAndValueToMap(msg)
                time = map["time"]!!
            }
        }
        home?.a45(1, to_user_code, time!!, this)
    }

    fun requestDataWallet() {
        lar.b10(this)
    }

    override fun getLayoutView(): View {
        mBinding = AtyChatBinding.inflate(layoutInflater);
        return mBinding.root
    }

    override fun onRestart() {
        super.onRestart()
        var vip_level_0 = BaseApp.instance?.getOneMapData("info_vip_level").toString()
        if (vip_level_0 != "0" && vip_level == "0") {
            list.clear()
            mAdapter?.notifyDataSetChanged()
            requestData()
        }
        vip_level = vip_level_0
        refreshVip()

        if (is_enter_voice == "1") {
            is_enter_voice = ""
            list.clear()
            mAdapter?.notifyDataSetChanged()
            requestData()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        svgUtils?.onDestroy()
    }

    fun initLayout() {

        if (enter_type == "match") {
            setAndroidNativeLightStatusBar(false)
            setStatusColor("#000000")
            mBinding.tvQmd.text = "亲密度：${cp_value}"

        } else {
            mBinding.tvQmd.visibility = View.GONE
            mBinding.relayOther1.visibility = View.GONE
            mBinding.recyclerviewHead.visibility = View.GONE
            mBinding.imgv1.visibility = View.GONE

            if (AppConfig.model == "wanou"){
                mBinding.relayTopBg.setBackgroundColor(Color.parseColor("#161A1A"))
            }else{
                mBinding.relayTopBg.setBackgroundColor(Color.parseColor("#ffffff"))
                mBinding.tvTitle.setTextColor(Color.parseColor("#000000"))
                mBinding.imgvBack.setImageResource(R.mipmap.ic_17)
                mBinding.imgvRight.setImageResource(R.drawable.ia_27)
                mBinding.v1.visibility = View.VISIBLE
            }
        }

        with(mBinding) {
            tvTitle.text = to_nick
        }

    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (AppConfig.model == "wanou") {
            window.navigationBarColor = Color.parseColor("#2A2A32")
        }

        initLayout()

        var mLayoutManager = LinearLayoutManager(this)
        mLayoutManager.orientation = RecyclerView.HORIZONTAL
        mBinding.recyclerviewHead.layoutManager = mLayoutManager
        mAdapter2 = GoldRecyclerAdapter2()
        mBinding.recyclerviewHead.adapter = mAdapter2

        initIm()

        with(mBinding) {
            var mLayoutManager = GridLayoutManager(this@ChatAty, 1)
            mLayoutManager.orientation = RecyclerView.VERTICAL
            recyclerview.layoutManager = mLayoutManager
            mAdapter = GoldRecyclerAdapter()
            recyclerview.adapter = mAdapter
            recyclerview.setItemViewCacheSize(200)
            recyclerview.setHasFixedSize(true)
            swipeRefreshLayout.setEnableLoadmore(true)
            swipeRefreshLayout.setEnableRefresh(true)
            swipeRefreshLayout.setXRefreshAndLoadListen(object : XRefreshInterface {
                override fun refreshStart() {
                    requestDataMore()
                }

                override fun loadMoreStart() {
                    requestDataWallet()
                }
            })

            refreshVip()

            loading.setLoadingTipXReloadCallback(object : XLoadTip.LoadingTipXReloadCallback {
                override fun reload() {
                    requestData()
                }
            })
        }
    }

    fun refreshVip() {
        with(mBinding) {
            if (map_service_info!!["code"]!! == to_user_code) {
                relayRight.visibility = View.GONE
                imgvGift.visibility = View.GONE
                relayIsVip.visibility = View.GONE
            } else {

                if (vip_level == "0") {
                    relayIsVip.visibility = View.VISIBLE
//                    if (enter_type == "match"){
//                        tvIsVip.text = "您还未开通会员! 可发${sendMaxNum}条,可看${receiveNum}条"
//                    }else{
//                        tvIsVip.text = "您还未开通会员！不可发,不可看"
//                    }
                    tvIsVip.text = "您还未开通会员! 可发${sendMaxNum}条,可看${receiveMaxNum}条"

                } else {
                    relayIsVip.visibility = View.GONE
                }
            }
        }
    }

    fun mainClick(v: View) {

        when (v.id) {
            R.id.tv_qmd -> {

                if (cp_value >= min_cp_value) {
                    var bundle = Bundle()
                    bundle.putString("user_code", to_user_code)
                    startActivity(PersonCpAty::class.java, bundle)
                    return
                }

                if (mMatchVoiceCpDg == null) {
                    mMatchVoiceCpDg = MatchVoiceCpDg(this)
                }

                mMatchVoiceCpDg?.setMatchVoiceCpDgListen(object :
                    MatchVoiceCpDg.MatchVoiceCpDgListen {
                    override fun onclik01() {
                        if (mMatchVoiceCpRuleDg == null) {
                            mMatchVoiceCpRuleDg = MatchVoiceCpRuleDg(this@ChatAty)
                        }
                        mMatchVoiceCpRuleDg?.show()
                        mMatchVoiceCpRuleDg?.setData(cp_rule_content, avatar, to_avatar, is_follow)
                    }

                    override fun sendGift() {
                        mBinding.imgvGift.performClick()
                    }

                    override fun addTime() {}
                })

                mMatchVoiceCpDg?.show()
                mMatchVoiceCpDg?.setData(cp_detail_content, avatar, to_avatar, is_follow)
                mMatchVoiceCpDg?.hideAddTime()

            }
            R.id.imgv_atten -> {
                if (mAttenDialog == null) {
                    mAttenDialog = AttenDialog(this)
                }
                mAttenDialog?.setAttenDialogListen(object : AttenDialog.AttenDialogListen {
                    override fun onclik01() {
                    }

                    override fun onclik02() {
                        startProgressDialog()
                        home.a93(min_unfollow_coins, to_user_code, this@ChatAty)
                    }
                })
                mAttenDialog?.show()
                mAttenDialog?.requestData(min_unfollow_coins)
            }

            R.id.tv_pay_vip -> {
                var bundle = Bundle()
                bundle.putString("page_type", "pay")
                startActivity(MainWalletAty::class.java, bundle)
            }

            R.id.imgv_gift -> {

                if (giftDialog == null) {
                    giftDialog = GiftDialog(this)
                    giftDialog?.setGiftDialogListen(object : GiftDialog.GiftDialogListen {
                        override fun recharge() {
                            var bundle = Bundle()
                            bundle.putString("page_type", "pay")
                            startActivity(MainWalletAty::class.java, bundle)
                        }

                        override fun sendGift(
                            gift_cover: String, gift_svga: String,
                            gift_title: String, gift_id: String,
                        ) {
                            this@ChatAty.sendGift(gift_cover, gift_svga, gift_title, gift_id)
                        }

                    })
                }

                giftDialog?.setGiftCpDialogListen(object : GiftDialog.GiftCpDialogListen {

                    override fun sendCpGift(map: MutableMap<String, String>, id: String) {

                        this@ChatAty.sendCpGift(map, id)
                    }

                })

                giftDialog?.show()
                giftDialog?.requestData()
            }

            R.id.relay_back -> {

                if (enter_type == "match") {
                    startProgressDialog()
                    home.a54(match_id, this)
                    return
                }

                finish()

            }

            R.id.relay_right -> {
                if (mPersonOtherMoreDg == null) {
                    mPersonOtherMoreDg = PersonOtherMoreDg(this)
                }
                mPersonOtherMoreDg?.setPersonOtherMoreDgListen(object :
                    PersonOtherMoreDg.PersonOtherMoreDgListen {
                    override fun onClickAtten() {

                        if (is_follow == "0") {
                            if (enter_type == "match") {
                                mBinding.imgvAtten.performClick()
                            } else {
                                startProgressDialog()

                                lar.b19(to_user_code, this@ChatAty)
                            }

                        } else {
                            startProgressDialog()

                            lar.b20(to_user_code, this@ChatAty)
                        }

                    }

                    override fun onClickReport() {
                        var bundle = Bundle()
                        bundle.putString("to_user_code", to_user_code)
                        startActivity(ChatReportAty::class.java, bundle)
                    }

                    override fun onClickBlack() {
                        startProgressDialog()
                        home.a28("2", to_user_code, this@ChatAty)
                    }

                })

                mPersonOtherMoreDg?.show()
                mPersonOtherMoreDg?.setDataChat(is_follow)
            }

            R.id.framlay_head -> {
                if (is_follow == "1") {
                    var bundle = Bundle()
                    bundle.putString("user_id", to_user_code)
                    startActivity(PersonOtherDetailsAty::class.java, bundle)
                }

            }

            R.id.imgv_send -> {

                if (map_service_info!!["code"]!! != to_user_code) {


                    if (vip_level == "0") {
                        if (sendNum > sendMaxNum) {
                            showCommonDialog("1006", true, "继续发送消息需要开通VIP！是否要开通？", "取消", "去开通")
                            return
                        }
                    }
                }

                if (TextUtils.isEmpty(mBinding.editChat.text.toString())) {
                    showToastS("请输入！")
                    return
                }

                if (map_service_info!!["code"]!! != to_user_code) {
                    lifecycleScope.launch {

                        var data = withContext(Dispatchers.IO) {
                            MyUtils3.containsWords(mBinding.editChat.text.toString(),
                                filter_data_list.toTypedArray(),
                                pattern_data_list)
                        }

                        withContext(Dispatchers.Main) {
                            if (data) {
                                showToastS("请勿发送违规内容和敏感词，请保持健康文明的聊天环境！")
                            } else {
                                sendMsg()
                            }
                        }
                    }

                } else {
                    sendMsg()
                }

            }

            R.id.imgv_add -> {

                if (mBinding.progressP.visibility == View.VISIBLE) {
                    return
                }

                if (map_service_info!!["code"]!! != to_user_code) {

                    if (is_send_pic == "0") {
                        showToastS("暂未开放，请咨询官方")
                        return
                    }

                    if (enter_type == "match" && vip_level == "0") {
                        if (sendNum > sendMaxNum) {
                            showToastS("最多免费发送${sendMaxNum}条")
                            return
                        }
                        sendNum++
                    }

                    if (enter_type != "match" && vip_level == "0") {
                        showToastS("请开通会员")
                        return
                    }
                }

                var bundle = Bundle()
                bundle.putInt("max_num", 1)
                bundle.putString("ratio", "0,0")
                startActivityForResult(ChooseImgAty::class.java, bundle, 100)
            }
        }
    }


    fun sendMsg() {

        var time = TimeUtils.getBeijinTime()
        var message_id = MyUtils3.getMD5Str(time + user_code)
        var json = MyUtils3.getTextMsg(to_user_code, to_avatar, to_nick, user_code, avatar, nick,
            mBinding.editChat.text.toString(), time, message_id)
        val message = mRtmClient?.createMessage()
        message?.text = json

        var map = HashMap<String, String>()
        map["user_code"] = user_code
        map["to_user_code"] = to_user_code
        map["time"] = time
        map["msg"] = json
        map["message_id"] = message_id
        list.add(map)
        mAdapter.notifyItemRangeChanged(list.size, 1)
        mBinding.recyclerview.scrollToPosition(list.size - 1)
        sendPeerMessage(message!!)
        mBinding.editChat.setText("")
        mBinding.imgvSend.visibility = View.GONE
        mBinding.progressP.visibility = View.VISIBLE
    }

    var message_gift: RtmMessage? = null

    var map_gift = HashMap<String, String>()
    var map_gift_cp: MutableMap<String, String>? = null
    var send_gift_type = "" //voice  room  cp_love
    var agree_gift_voice = ""

    fun sendGift(gift_cover: String, gift_svga: String, gift_title: String, gift_id: String) {
        var time = TimeUtils.getBeijinTime()
        var message_id = MyUtils3.getMD5Str(time + user_code)

        var json = MyUtils3.getGiftMsg(
            to_user_code, to_avatar, to_nick,
            user_code, avatar, nick,
            gift_cover, gift_svga, gift_title, gift_id,
            time, message_id
        )
        message_gift = mRtmClient?.createMessage()
        message_gift?.text = json
        map_gift = HashMap<String, String>()
        map_gift["user_code"] = user_code
        map_gift["to_user_code"] = to_user_code
        map_gift["time"] = time
        map_gift["msg"] = json
        map_gift["message_id"] = message_id

        mBinding.editChat.setText("")
        mBinding.imgvSend.visibility = View.GONE
        mBinding.progressP.visibility = View.VISIBLE
        home.a432(to_user_code, user_code, json, time, message_id, "", this@ChatAty)
    }

    fun sendCpGift(map: MutableMap<String, String>, id: String) {

        map_gift_cp = map
        send_gift_type = map["alias"].toString()

        mBinding.editChat.setText("")
        mBinding.imgvSend.visibility = View.GONE
        mBinding.progressP.visibility = View.VISIBLE
        home.a95(id, to_user_code, this@ChatAty)

    }

    fun requestDataVoice(match_id: String) {
        match_voice_id = match_id
        startProgressDialog()
        home.a55(match_id, this)
    }

    fun requestDataVoiceTo(match_id: String) {
        match_voice_id = match_id
        startProgressDialog()
        home.a552(match_id, this)
    }

    override fun onComplete(var2: String?, type: String?) {
        super.onComplete(var2, type)

        //取消关注
        if (type == "cancel/follow") {
            stopProgressDialog()
            var map = JSONUtils.parseKeyAndValueToMap(var2)
            if (map["code"] == "200") {
                is_follow = "0"
                mBinding.imgvAtten.visibility = View.VISIBLE

            } else {
                showToastS(map["message"])
            }
        }

        //关注
        if (type == "follow") {
            stopProgressDialog()
            var map = JSONUtils.parseKeyAndValueToMap(var2)
            if (map["code"] == "200") {
                is_follow = "1"

            } else {
                showToastS(map["message"])
            }
        }

        //拉黑
        if (type == "post/block") {
            stopProgressDialog()
            var map = JSONUtils.parseKeyAndValueToMap(var2)
            if (map["code"] == "200") {
                showToastS("已拉黑")
                mBinding.relayBack.performClick()
            } else {
                showToastS(map["message"])
            }
        }

        // 评价订单
        if (type == "gift/feedback") {
            stopProgressDialog()
            var map = JSONUtils.parseKeyAndValueToMap(var2)
            showToastS(map["message"])

            if (map["code"] == "200") {
                var str = AESCBCCrypt.aesDecrypt(map["data"])
//                var map_data = JSONUtils.parseKeyAndValueToMap(str)
                var time = TimeUtils.getBeijinTime()
                var message_id = MyUtils3.getMD5Str(time + user_code)
                var msg_title = "我已经确认完成了"
                var sub_msg_title = "期待再次与你共度美好时光！"

                var json = MyUtils3.getCpMsg(
                    to_user_code, to_avatar, to_nick,
                    user_code, avatar, nick,
                    agree_gift_voice, "", "",
                    "", "1",
                    msg_title, sub_msg_title,
                    "", "",
                    time, message_id)

                message_gift = mRtmClient?.createMessage()
                message_gift?.text = json
                var map_gift = HashMap<String, String>()
                map_gift["user_code"] = user_code
                map_gift["to_user_code"] = to_user_code
                map_gift["time"] = time
                map_gift["msg"] = json
                map_gift["message_id"] = message_id!!

                list.add(map_gift)
                mAdapter.notifyItemRangeChanged(list.size, 1)
                mBinding.recyclerview.scrollToPosition(list.size - 1)
                sendPeerMessage(message_gift!!)

            } else {
                showToastS(map["message"])
            }
        }

        // 语聊详情to
        if (type == "match/details/to") {
            stopProgressDialog()
            var map = JSONUtils.parseKeyAndValueToMap(var2)

            if (map["code"] == "200") {
                var str = AESCBCCrypt.aesDecrypt(map["data"])

                is_enter_voice = "1"
                var bundle = Bundle()
                bundle.putString("match_id", match_voice_id)
                bundle.putString("json", str)
                bundle.putString("user_type", "from")
                startActivity(MatchVoiceAty::class.java, bundle)

            } else {
                showToastS(map["message"])
            }
        }

        // 语聊详情
        if (type == "match/details") {
            stopProgressDialog()
            var map = JSONUtils.parseKeyAndValueToMap(var2)
            if (map["code"] == "200") {
                var str = AESCBCCrypt.aesDecrypt(map["data"])
                is_enter_voice = "1"
                var bundle = Bundle()
                bundle.putString("match_id", match_voice_id)
                bundle.putString("json", str)
                bundle.putString("user_type", "to")
                startActivity(MatchVoiceAty::class.java, bundle)
            } else {
                showToastS(map["message"])
            }
        }

        //接受语聊特殊礼物
        if (type == "gift/accept/voice") {
            stopProgressDialog()

            var map = JSONUtils.parseKeyAndValueToMap(var2)

            if (map["code"] == "200") {
                var str = AESCBCCrypt.aesDecrypt(map["data"])
                var map_data = JSONUtils.parseKeyAndValueToMap(str)
                var time = TimeUtils.getBeijinTime()
                var message_id = MyUtils3.getMD5Str(time + user_code)
                var status = map_data["status"]

                var msg_title = ""
                var sub_msg_title = ""
                when (status) {

                    "0" -> {
                        msg_title = "我拒绝你的礼物请求"
                        sub_msg_title = "礼物已自动返回背包中"
                    }

                    //已接受
                    "3" -> {
                        msg_title = "我接受了你的礼物请求"
                        sub_msg_title = "每一次的相遇都是新的开始"
                    }

                    //已完成
                    "1" -> {
                    }
                }

                var json = MyUtils3.getCpMsg(
                    to_user_code, to_avatar, to_nick,
                    user_code, avatar, nick,
                    agree_gift_voice, "", "",
                    "", map_data["status"],
                    msg_title, sub_msg_title,
                    map_data["match_id"], map_data["type"],
                    time, message_id)

                message_gift = mRtmClient?.createMessage()
                message_gift?.text = json
                var map_gift = HashMap<String, String>()
                map_gift["user_code"] = user_code
                map_gift["to_user_code"] = to_user_code
                map_gift["time"] = time
                map_gift["msg"] = json
                map_gift["message_id"] = message_id!!

                list.add(map_gift)
                mAdapter.notifyItemRangeChanged(list.size, 1)
                mBinding.recyclerview.scrollToPosition(list.size - 1)
                sendPeerMessage(message_gift!!)

                if (status == "3") {
                    when (map_data["type"]) {

                        "room" -> {
                        }

                        "voice" -> {
                            requestDataVoice(map_data["match_id"].toString())
                        }

                        "cp_love" -> {
                            var bundle = Bundle()
                            bundle.putString("user_code", user_code)
                            bundle.putString("cp_user_code", to_user_code)
                            startActivity(PersonCpDetailsAty::class.java, bundle)
                        }
                    }
                }

            } else {
                showToastS(map["message"])
            }

        }

        //发送特殊礼物请求
        if (type == "gift/reward/cp") {
            stopProgressDialog()
            var map = JSONUtils.parseKeyAndValueToMap(var2)
            if (map["code"] == "200") {
                var str = AESCBCCrypt.aesDecrypt(map["data"])
                var map_data = JSONUtils.parseKeyAndValueToMap(str)

                var time = TimeUtils.getBeijinTime()
                var message_id = map_data["message_id"]
                var msg_title = "送你一个${map_gift_cp!!["title"]}"
                var sub_msg_title = ""

                when (send_gift_type) {

                    "voice" -> {
                        sub_msg_title = "语音聊天礼物"
                    }

                    "room" -> {
                        sub_msg_title = "房间卡礼物"
                    }

                    "cp_love" -> {
                        sub_msg_title = "处CP礼物"
                    }

                }

                var json = MyUtils3.getCpMsg(
                    to_user_code, to_avatar, to_nick,
                    user_code, avatar, nick,
                    map_gift_cp!!["cover"], map_gift_cp!!["svga"], map_gift_cp!!["id"],
                    map_gift_cp!!["title"], "2",
                    msg_title, sub_msg_title,
                    "", send_gift_type,
                    time, message_id)

                message_gift = mRtmClient?.createMessage()
                message_gift?.text = json
                LogUtil.e(" message.serverReceivedTs=" + json)
                var map_gift = HashMap<String, String>()
                map_gift["user_code"] = user_code
                map_gift["to_user_code"] = to_user_code
                map_gift["time"] = time
                map_gift["msg"] = json
                map_gift["message_id"] = message_id!!

                list.add(map_gift)
                mAdapter.notifyItemRangeChanged(list.size, 1)
                mBinding.recyclerview.scrollToPosition(list.size - 1)
                sendPeerMessage(message_gift!!)
            } else {
                mBinding.imgvSend.visibility = View.VISIBLE
                mBinding.progressP.visibility = View.GONE
                showToastS(map["message"])
            }
        }

        if (type == "cp/feedback") {
            stopProgressDialog()

            var map = JSONUtils.parseKeyAndValueToMap(var2)
            showToastS(map["message"])

            if (map["code"] == "200") {
            } else {

            }

        }

        if (type == "wallet/info") {
            mBinding.swipeRefreshLayout.finishLoadmore()
            var map = JSONUtils.parseKeyAndValueToMap(var2)
            if (map["code"] == "200") {
                var str_wallet = AESCBCCrypt.aesDecrypt(map["data"])
                var map_info = JSONUtils.parseKeyAndValueToMap(str_wallet)
                var vip_level_0 = map_info["vip_level"]

                if (vip_level_0 != "0" && vip_level == "0") {
                    list.clear()
                    mAdapter?.notifyDataSetChanged()
                    requestData()
                }
                vip_level = vip_level_0!!
                refreshVip()
            } else {
                showToastS(map["message"])
            }
        }

        if (type == "match/cancel") {
            var map = JSONUtils.parseKeyAndValueToMap(var2)
            if (map["code"] == "200") {
                finish()
            } else {
                finish()
                Toast.makeText(this, map["message"], Toast.LENGTH_SHORT).show()
            }
        }

        if (type == "message/create") {
            stopProgressDialog()
            mBinding.imgvSend.visibility = View.VISIBLE
            mBinding.progressP.visibility = View.GONE
            sendNum++
        }

        if (type == "message/create/gift") {
            stopProgressDialog()
            var map = JSONUtils.parseKeyAndValueToMap(var2)
            if (map["code"] == "200") {
                list.add(map_gift)
                mAdapter.notifyItemRangeChanged(list.size, 1)
                mBinding.recyclerview.scrollToPosition(list.size - 1)
                sendPeerMessage(message_gift!!)
            } else {
                mBinding.imgvSend.visibility = View.VISIBLE
                mBinding.progressP.visibility = View.GONE
                showToastS(map["message"])
            }
        }

        if (type == "/app/api/message/user/list") {

            mBinding.swipeRefreshLayout.finishRefreshing()
            mBinding.swipeRefreshLayout.finishLoadmore()
            var map = JSONUtils.parseKeyAndValueToMap(var2)
            if (map["code"] == "200") {

                if (enter_type == "match" && list.size == 0) {
                    requestDataInfo()
                } else {
                    requestDataInfoIsFllow()
                    mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.finish)
                }

                var str = AESCBCCrypt.aesDecrypt(map["data"])
                var mList = JSONUtils.parseKeyAndValueToMapList(str)

                if (mList == null || mList.size == 0) {
                    return
                }

                list.addAll(0, mList)


                if (vip_level == "0" && list.size < 100) {
                    receiveNum = 0
                    for (index in list.indices) {
                        if (list[index]["src"] == user_code) {
                            sendNum++
                        } else {
                            var maps = list[index]

                            if (receiveNum < receiveMaxNum) {
                                receiveNum++
                                maps["is_show"] = "1"
                                list[index] = maps
                            } else {
                                maps["is_show"] = "0"
                                list[index] = maps
                            }

                        }
                    }
                }

                mAdapter?.notifyDataSetChanged()
                if (list.size > mList.size) {
                    mBinding.recyclerview.scrollToPosition(mList.size)
                } else {
                    mBinding.recyclerview.scrollToPosition(mList.size - 1)
                }
            }
        }

        if (type == "file/upload") {
            stopProgressDialog()

            var map = JSONUtils.parseKeyAndValueToMap(var2)
            if (map["code"] == "0") {
                var dataMap = JSONUtils.parseDataToMap(var2)
                var img = dataMap["file_path"]!!
                var thumbImage = dataMap["file_path"]!!
                var name = dataMap["file_path"]!!

                var time = TimeUtils.getBeijinTime()
                var message_id = MyUtils3.getMD5Str(time + user_code)

                var json = MyUtils3.getImgMsg(to_user_code,
                    to_avatar,
                    to_nick,
                    user_code,
                    avatar,
                    nick,
                    img,
                    thumbImage,
                    name,
                    time,
                    message_id)

                val message = mRtmClient!!.createMessage()
                message.text = json
                var map = HashMap<String, String>()
                map["user_code"] = user_code
                map["to_user_code"] = to_user_code
                map["time"] = time
                map["msg"] = json
                map["message_id"] = message_id
                list.add(map)

                mAdapter.notifyItemRangeChanged(list.size, 1)
                mBinding.recyclerview.scrollToPosition(list.size - 1)
                sendPeerMessage(message)

            } else {
                showToastS(map["message"])
                mBinding.imgvSend.visibility = View.VISIBLE
                mBinding.progressP.visibility = View.GONE
            }
        }

        if (type == "unlock/follow") {
            stopProgressDialog()
            var map = JSONUtils.parseKeyAndValueToMap(var2)
            if (map["code"] == "200") {
                is_follow = "1"
                mBinding.tvTitle.text = to_nick
                mBinding.imgvAtten.visibility = View.GONE

            } else {
                showToastS(map["message"])
            }
        }

        if (type == "other/info") {

            var map = JSONUtils.parseKeyAndValueToMap(var2)

            if (map["code"] == "200") {

                mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.finish)
                var strs = AESCBCCrypt.aesDecrypt(map["data"])
                var map_info = JSONUtils.parseKeyAndValueToMap(strs)

                is_follow = map_info["is_follow"].toString()

                var stringBuffer = StringBuffer()
                stringBuffer.append(map_info["city"])
//
                if (!TextUtils.isEmpty(stringBuffer.toString()) && !TextUtils.isEmpty(map_info["years"])) {
                    stringBuffer.append("-" + map_info["years"] + "岁")
                } else {
                    stringBuffer.append(map_info["years"])
                }

                if (!TextUtils.isEmpty(stringBuffer.toString()) && !TextUtils.isEmpty(map_info["job"])) {
                    stringBuffer.append("-" + map_info["job"])
                } else {
                    stringBuffer.append(map_info["job"])
                }

                mBinding.tvName.text = stringBuffer.toString()

                if (is_follow == "1") {
                    mBinding.imgvAtten.visibility = View.GONE
                } else {
                    mBinding.imgvAtten.visibility = View.VISIBLE
                    mBinding.tvTitle.text = "陌生的彩虹星人"
                }

                var maxW = AutoUtils.getPercentWidthSizeBigger(400)
                ImageLoader.loadImageAes(this, map_info["avatar"], mBinding.ivHead, maxW, maxW)

                if (!TextUtils.isEmpty(map_info["user_frame_avatar"])) {
                    ImageLoader.loadImageAes(this,
                        map_info["user_frame_avatar"],
                        mBinding.imgvFrame,
                        maxW,
                        maxW)
                    mBinding.imgvFrame.visibility = View.VISIBLE
                } else {
                    mBinding.imgvFrame.visibility = View.GONE
                }

                MyUtils3.setVipLevel(map_info["vip_level"], mBinding.imgvVipLevel, 0)

                if (map_info["is_add_fans_group"] == "1") {
                    mBinding.imgvIsAddFansGroup.visibility = View.VISIBLE
                } else {
                    mBinding.imgvIsAddFansGroup.visibility = View.GONE
                }

                if (map_info["is_creator"] == "1") {
                    mBinding.imgvCreator.visibility = View.VISIBLE
                    var maxW_head = AutoUtils.getPercentWidthSizeBigger(400)
                    ImageLoader.loadImageAes(this,
                        map_info["creator_icon"],
                        mBinding.imgvCreator,
                        maxW_head,
                        maxW_head)
                } else {
                    mBinding.imgvCreator.visibility = View.GONE
                }

                when (map_info["gender"]) {

                    "1" -> {
                        mBinding.tvGender.text = "1"
                        mBinding.linlayGender.setBackgroundResource(R.drawable.shape_77)
                    }

                    "0" -> {
                        mBinding.tvGender.text = "0"
                        mBinding.linlayGender.setBackgroundResource(R.drawable.shape_78)
                    }

                    "10" -> {
                        mBinding.tvGender.text = "10"
                        mBinding.linlayGender.setBackgroundResource(R.drawable.shape_79)
                    }

                    else -> {
                        mBinding.linlayGender.visibility = View.GONE
                    }

                }

                var avatar_log = map_info["avatar_log"].toString()
                var avatar_log_list = JSONUtils.parseKeyAndValueToMapList(avatar_log)

                if (avatar_log_list != null && avatar_log_list.size > 0) {
                    mAdapter2?.setData(avatar_log_list)
                } else {
                    mBinding.recyclerviewHead.visibility = View.GONE
                }

            } else {

                mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.error)

            }
        }

        //是否关注
        if (type == "other/info/atten") {

            var map = JSONUtils.parseKeyAndValueToMap(var2)
            if (map["code"] == "200") {
                var strs = AESCBCCrypt.aesDecrypt(map["data"])
                var map_info = JSONUtils.parseKeyAndValueToMap(strs)
                is_follow = map_info["is_follow"].toString()
            }
        }
    }

    override fun onExceptionType(type: String?) {
        super.onExceptionType(type)
        stopProgressDialog()
        mBinding.swipeRefreshLayout.finishRefreshing()

        if (type == "gift/reward/cp") {
            showToastS("发送失败")
            mBinding.imgvSend.visibility = View.VISIBLE
            mBinding.progressP.visibility = View.GONE
        }

        if (type == "message/create") {
            showToastS("发送失败")
            mBinding.imgvSend.visibility = View.VISIBLE
            mBinding.progressP.visibility = View.GONE
        }

        if (type == "message/create/gift") {
            showToastS("发送失败")
            mBinding.imgvSend.visibility = View.VISIBLE
            mBinding.progressP.visibility = View.GONE
        }

        if (type == "file/upload") {
            mBinding.imgvSend.visibility = View.VISIBLE
            mBinding.progressP.visibility = View.GONE
        }

        if (type == "wallet/info") {
            mBinding.swipeRefreshLayout.finishLoadmore()
        }
    }


    fun sendPeerMessage(message: RtmMessage) {
        mRtmClient?.sendMessageToPeer(to_user_code, message, mChatManager?.getSendMessageOptions(),
            object : ResultCallback<Void?> {
                override fun onSuccess(aVoid: Void?) {
                    LogUtil.e("sendPeerMessage=======发送成功")
                    ChatUtils.saveChatpannel(message.text)

                    runOnUiThread {
                        var str = AESCBCCrypt.aesDecrypt(message.text)
                        var map = JSONUtils.parseKeyAndValueToMap(str)
                        var map_f = JSONUtils.parseKeyAndValueToMap(map["from_user"])
                        var map_t = JSONUtils.parseKeyAndValueToMap(map["to_user"])

                        when (map["type"]) {
                            //图文
                            "1", "2" -> {
                                home.a43(map_t["user_code"]!!,
                                    map_f["user_code"]!!,
                                    message.text,
                                    map["time"]!!,
                                    map["message_id"]!!,
                                    this@ChatAty)
                            }
                            //普通礼物
                            "4" -> {
                                mBinding.imgvSend.visibility = View.VISIBLE
                                mBinding.progressP.visibility = View.GONE
                            }

                            //特殊礼物
                            "5" -> {
                                mBinding.imgvSend.visibility = View.VISIBLE
                                mBinding.progressP.visibility = View.GONE
                            }
                        }

                    }

                }

                override fun onFailure(errorInfo: ErrorInfo) {
                    LogUtil.e("sendPeerMessage=======发送失败" + errorInfo.errorCode)
                    val errorCode = errorInfo.errorCode
                    when (errorCode) {
                        RtmStatusCode.PeerMessageError.PEER_MESSAGE_ERR_TIMEOUT, RtmStatusCode.PeerMessageError.PEER_MESSAGE_ERR_FAILURE -> {
                            runOnUiThread {
                                mBinding.imgvSend.visibility = View.VISIBLE
                                mBinding.progressP.visibility = View.GONE
                            }

                        }
                        RtmStatusCode.PeerMessageError.PEER_MESSAGE_ERR_PEER_UNREACHABLE -> {
                            runOnUiThread {
                                mBinding.imgvSend.visibility = View.VISIBLE
                                mBinding.progressP.visibility = View.GONE
                            }
//                                showToastS("对方不在线")
                        }
                        RtmStatusCode.PeerMessageError.PEER_MESSAGE_ERR_CACHED_BY_SERVER -> {
                            ChatUtils.saveChatpannel(message.text)

                            runOnUiThread {
                                var str = AESCBCCrypt.aesDecrypt(message.text)
                                var map = JSONUtils.parseKeyAndValueToMap(str)
                                var map_f = JSONUtils.parseKeyAndValueToMap(map["from_user"])
                                var map_t = JSONUtils.parseKeyAndValueToMap(map["to_user"])

                                when (map["type"]) {
                                    "1", "2" -> {
                                        home.a43(map_t["user_code"]!!,
                                            map_f["user_code"]!!,
                                            message.text,
                                            map["time"]!!,
                                            map["message_id"]!!,
                                            this@ChatAty)
                                    }
                                    "4" -> {
                                        mBinding.imgvSend.visibility = View.VISIBLE
                                        mBinding.progressP.visibility = View.GONE
                                    }
                                    "5" -> {
                                        mBinding.imgvSend.visibility = View.VISIBLE
                                        mBinding.progressP.visibility = View.GONE
                                    }
                                }
//                                showToastS("消息已被服务器缓存")
                            }

                        }

                        else -> {

                            runOnUiThread {
                                mBinding.imgvSend.visibility = View.VISIBLE
                                mBinding.progressP.visibility = View.GONE
                            }

                        }
                    }
                }
            })
    }


    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (resultCode == RESULT_OK) {
            when (requestCode) {

                100 -> {
                    var type = data?.getStringExtra("type")

                    when (type) {

                        "img_photo" -> {
                            var list = data?.getStringArrayListExtra("data")
                            mBinding.imgvSend.visibility = View.GONE
                            mBinding.progressP.visibility = View.VISIBLE
                            lar.b7(list!![0], this)
                        }
                    }
                }
            }
        }
    }


    inner class GoldRecyclerAdapter : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
            return fGoldViewHolder(ItemChatBinding.inflate(LayoutInflater.from(this@ChatAty)))
        }

        override fun getItemCount(): Int = list.size

        override fun getItemViewType(position: Int): Int {
            return position
        }

        override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {

            if (holder is fGoldViewHolder) {

                with(holder) {
                    with(mBinding) {

                        var msg = ""

                        if (list[position].containsKey("msg")) {
                            msg = AESCBCCrypt.aesDecrypt(list[position]["msg"])
                        } else {
                            msg = AESCBCCrypt.aesDecrypt(list[position]["payload"])
                        }

                        LogUtil.e("AESCBCCrypt msg===" + msg)
                        var map = JSONUtils.parseKeyAndValueToMap(msg)
                        var map_form_user = JSONUtils.parseKeyAndValueToMap(map["from_user"])
                        var map_to_user = JSONUtils.parseKeyAndValueToMap(map["to_user"])

                        if (position > 0) {
//
                            var msgPre = ""
                            if (list[position - 1].containsKey("msg")) {
                                msgPre = AESCBCCrypt.aesDecrypt(list[position - 1]["msg"])
                            } else {
                                msgPre = AESCBCCrypt.aesDecrypt(list[position - 1]["payload"])
                            }
                            var mapPre = JSONUtils.parseKeyAndValueToMap(msgPre)
                            val preMsgTime = java.lang.Long.parseLong(mapPre["time"])
                            val cruMsgTime = java.lang.Long.parseLong(map["time"])
//
                            if (cruMsgTime - preMsgTime > 1000 * 60) {
                                tvTime.visibility = View.VISIBLE
                                var time = (TimeUtils.getBeijinTime()
                                    .toDouble() - map["time"]!!.toDouble()) / 1000
                                tvTime.text = TimeUtils.formatSecond3(time)
//
                            } else {
                                tvTime.visibility = View.GONE
                            }
                        }

                        when (map["type"]) {

                            //特殊礼物
                            "5" -> {
                                LogUtil.e("msgPre==" + msg)
                                linlayGift.visibility = View.GONE
                                var status = map["status"]

                                if (map_form_user["user_code"] == user_code) {
                                    relayMy.visibility = View.VISIBLE
                                    relayOther.visibility = View.GONE
                                    tvContentMy.visibility = View.GONE
                                    framlayImgvMy.visibility = View.GONE
                                    relayCpMy.visibility = View.VISIBLE

                                    var avatar = map_form_user["avatar"]
                                    var maxW_head = AutoUtils.getPercentWidthSizeBigger(200)
                                    ImageLoader.loadImageAes(this@ChatAty,
                                        avatar,
                                        ivHeadMy,
                                        maxW_head,
                                        maxW_head)

                                    var maxW = AutoUtils.getPercentWidthSizeBigger(300)
                                    ImageLoader.loadImageAes(this@ChatAty,
                                        map["cover"],
                                        imgvCpMy,
                                        maxW,
                                        maxW)
                                    tvCpTitleMy.text = map["msg_title"]
                                    tvCpSubTitleMy.text = map["sub_msg_title"]

                                } else {
                                    relayMy.visibility = View.GONE
                                    relayOther.visibility = View.VISIBLE
                                    tvContentMy.visibility = View.GONE
                                    framlayImgvMy.visibility = View.GONE
                                    relayCp.visibility = View.VISIBLE

                                    var status = map["status"]
                                    var maxW = AutoUtils.getPercentWidthSizeBigger(300)
                                    ImageLoader.loadImageAes(this@ChatAty,
                                        map["cover"],
                                        imgvCp,
                                        maxW,
                                        maxW)
                                    tvCpTitle.text = map["msg_title"]
                                    tvCpSubTitle.text = map["sub_msg_title"]

                                    var avatar = map_form_user["avatar"]
                                    var maxW_head = AutoUtils.getPercentWidthSizeBigger(200)
                                    ImageLoader.loadImageAes(this@ChatAty,
                                        avatar,
                                        ivHead,
                                        maxW_head,
                                        maxW_head)

//                                    var gift_type = map["gift_type"]

                                    relayCp.setOnClickListener {
                                        when (status) {
                                            "2" -> {
                                                agree_gift_voice = map["cover"].toString()
                                                showCommonDialog("1011", true, "给你发送了礼物请求\n要接受吗？",
                                                    "拒绝", "接受", object :
                                                        BaseCommonDialogListen {
                                                        override fun onclick01() {

                                                            startProgressDialog()
                                                            home.a96(map["message_id"].toString(),
                                                                "0",
                                                                this@ChatAty)
                                                        }

                                                        override fun onclick02() {
                                                            startProgressDialog()
                                                            home.a96(map["message_id"].toString(),
                                                                "3",
                                                                this@ChatAty)
                                                        }

                                                    })

                                            }

                                            "4" -> {
                                                agree_gift_voice = map["cover"].toString()

                                                if (mChatOrderAssessDialog == null) {
                                                    mChatOrderAssessDialog =
                                                        ChatOrderAssessDialog(this@ChatAty)
                                                }
                                                mChatOrderAssessDialog?.setChatOrderAssessDialogListen(
                                                    object :
                                                        ChatOrderAssessDialog.ChatOrderAssessDialogListen {
                                                        override fun assess(
                                                            is_satisfy: String,
                                                            content: String,
                                                        ) {
                                                            startProgressDialog()
                                                            home?.a97(map["message_id"].toString(),
                                                                to_user_code,
                                                                is_satisfy,
                                                                content,
                                                                this@ChatAty)
                                                        }
                                                    })
                                                mChatOrderAssessDialog?.show()
                                                mChatOrderAssessDialog?.setData(to_avatar, to_nick)
                                            }
                                        }
                                    }

                                    LogUtil.e("status===" + status)
                                    //0 已拒绝 1已完成 2待接收 3已接受  4待评价 5已取消
                                    when (status) {

                                        //FFB7B8C0
                                        "0" -> {
                                            tvCpSubTitle.setTextColor(Color.parseColor("#FFB7B8C0"))
                                        }

                                        "1" -> {
                                            tvCpSubTitle.setTextColor(Color.parseColor("#FFB7B8C0"))
                                        }

                                        "2" -> {
                                            tvCpSubTitle.text = "点击查看接受>>"
                                            tvCpSubTitle.setTextColor(Color.parseColor("#00A4FF"))
                                        }

                                        "3" -> {
                                            tvCpSubTitle.setTextColor(Color.parseColor("#FFB7B8C0"))
                                        }

                                        "4" -> {
                                            tvCpSubTitle.setTextColor(Color.parseColor("#00A4FF"))
                                        }

                                        "5" -> {
                                            tvCpSubTitle.setTextColor(Color.parseColor("#FFB7B8C0"))
                                        }
                                    }
                                }

                            }

                            //普通礼物
                            "4" -> {
                                relayMy.visibility = View.GONE
                                relayOther.visibility = View.GONE
                                linlayGift.visibility = View.VISIBLE
                                if (map_form_user["user_code"] == user_code) {
                                    tvGift.text = "送出礼物"
                                } else {
                                    tvGift.text = "收到礼物"
                                }

                                var maxW = AutoUtils.getPercentWidthSizeBigger(300)
                                ImageLoader.loadImageAes(this@ChatAty,
                                    map["cover"],
                                    imgvGift,
                                    maxW,
                                    maxW)

                            }

                            //图片
                            "2" -> {
                                linlayGift.visibility = View.GONE

                                if (map_form_user["user_code"] == user_code) {
                                    relayMy.visibility = View.VISIBLE
                                    relayOther.visibility = View.GONE
                                    tvContentMy.visibility = View.GONE
                                    framlayImgvMy.visibility = View.VISIBLE

                                    imgvMy.setImageResource(R.drawable.ib_01)

                                    var maxW = AutoUtils.getPercentWidthSizeBigger(500)
                                    ImageLoader.loadImageAes(this@ChatAty,
                                        resource_cdn + map["thumb_image"],
                                        imgvMy,
                                        maxW,
                                        maxW)
                                    var avatar = map_form_user["avatar"]

                                    var maxW_head = AutoUtils.getPercentWidthSizeBigger(200)
                                    ImageLoader.loadImageAes(this@ChatAty,
                                        avatar,
                                        ivHeadMy,
                                        maxW_head,
                                        maxW_head)

                                    imgvMy.setOnClickListener {
                                        var list = ArrayList<String>()
                                        list.add(resource_cdn + map["thumb_image"])
                                        var bundle = Bundle()
                                        bundle.putStringArrayList("data", list)
                                        startActivity(BigImgListAty::class.java, bundle, false)
                                    }
                                } else {
                                    relayMy.visibility = View.GONE
                                    relayOther.visibility = View.VISIBLE
                                    tvContent.visibility = View.GONE
                                    framlayImgv.visibility = View.VISIBLE

                                    imgv.setImageResource(R.drawable.ib_01)

                                    var maxW = AutoUtils.getPercentWidthSizeBigger(500)

                                    ImageLoader.loadImageAes(this@ChatAty,
                                        resource_cdn + map["thumb_image"],
                                        imgv,
                                        maxW,
                                        maxW)

                                    var avatar = map_form_user["avatar"]

                                    var maxW_head = AutoUtils.getPercentWidthSizeBigger(200)
                                    ImageLoader.loadImageAes(this@ChatAty,
                                        avatar,
                                        ivHead,
                                        maxW_head,
                                        maxW_head)
                                    imgv.setOnClickListener {
                                        if (vip_level == "0" && map_service_info!!["code"]!! != to_user_code) {
                                            showToastS("开通vip可看大图")
                                            return@setOnClickListener
                                        }
                                        var list = ArrayList<String>()
                                        list.add(resource_cdn + map["thumb_image"])
                                        var bundle = Bundle()
                                        bundle.putStringArrayList("data", list)
                                        startActivity(BigImgListAty::class.java, bundle, false)
                                    }
                                }
                            }

                            //文本
                            "1" -> {
                                linlayGift.visibility = View.GONE

                                if (map_form_user["user_code"] == user_code) {
                                    relayMy.visibility = View.VISIBLE
                                    relayOther.visibility = View.GONE
                                    var avatar = map_form_user["avatar"]
                                    tvContentMy.text = map["text"]
                                    var maxW_head = AutoUtils.getPercentWidthSizeBigger(200)
                                    ImageLoader.loadImageAes(this@ChatAty,
                                        avatar,
                                        ivHeadMy,
                                        maxW_head,
                                        maxW_head)

                                } else {
                                    relayMy.visibility = View.GONE
                                    relayOther.visibility = View.VISIBLE
                                    var avatar = map_form_user["avatar"]

                                    if (vip_level == "0" && map_service_info!!["code"]!! != to_user_code) {

                                        if (list[position].containsKey("is_show") && list[position]["is_show"] == "0") {
                                            MyUtils3.setTextMaskFilterSpan(tvContent,
                                                map["text"],
                                                0)
                                        } else {
                                            tvContent.text = map["text"]
                                        }
                                    } else {
                                        tvContent.text = map["text"]
                                    }

                                    var maxW_head = AutoUtils.getPercentWidthSizeBigger(200)
                                    ImageLoader.loadImageAes(this@ChatAty,
                                        avatar,
                                        ivHead,
                                        maxW_head,
                                        maxW_head)
                                }
                            }

                            else -> {

                            }
                        }
                    }
                }

            }

        }

        inner class fGoldViewHolder(binding: ItemChatBinding) :
            RecyclerView.ViewHolder(binding.root) {
            var mBinding: ItemChatBinding = binding

            init {
                AutoUtils.autoSize(binding.root)
            }
        }

    }

    override fun onMessageReceived(message: RtmMessage?, peerId: String?) {

        LogUtil.e("AESCBCCrypt==" + to_user_code + ",,," + peerId)

        if (message != null) {
            LogUtil.e("AESCBCCrypt-chataty=" + message.text)
        }

        var str = AESCBCCrypt.aesDecrypt(message!!.text)
        var map_str = JSONUtils.parseKeyAndValueToMap(str)

        LogUtil.e("AESCBCCrypt==" + str)
        if (peerId == to_user_code) {

            when (map_str["type"]) {

                "1", "2" -> {

                    var map = HashMap<String, String>()
                    map["user_code"] = user_code
                    map["to_user_code"] = to_user_code
                    map["msg"] = message!!.text
                    if (receiveNum < receiveMaxNum) {
                        receiveNum++
                        map["is_show"] = "1"
                    } else {
                        map["is_show"] = "0"
                    }
                    list.add(map)
                    handler.sendEmptyMessage(3)
                    ChatUtils.saveChatpannel(message!!.text, true)
                }

                "4" -> {
                    var map = HashMap<String, String>()
                    map["user_code"] = user_code
                    map["to_user_code"] = to_user_code
                    map["msg"] = message!!.text
                    list.add(map)
                    handler.sendEmptyMessage(3)
                    ChatUtils.saveChatpannel(message!!.text, true)
                }

                "5" -> {

                    var map = HashMap<String, String>()
                    map["user_code"] = user_code
                    map["to_user_code"] = to_user_code
                    map["msg"] = message!!.text
                    list.add(map)
                    handler.sendEmptyMessage(3)
                    ChatUtils.saveChatpannel(message!!.text, true)

                    LogUtil.e("saveChatpannel == " + map_str["status"])
                    if (map_str["status"] == "3") {
                        runOnUiThread {

                            when (map_str["gift_type"]) {

                                "room" -> {
                                }

                                "voice" -> {
                                    requestDataVoiceTo(map_str["match_id"].toString())
                                }

                                "cp_love" -> {
                                    var bundle = Bundle()
                                    bundle.putString("user_code", user_code)
                                    bundle.putString("cp_user_code", to_user_code)
                                    startActivity(PersonCpDetailsAty::class.java, bundle)
                                }
                            }
                        }
                    }
                }
            }

            runOnUiThread {

                when (map_str["type"]) {
                    "4" -> {

                        var url_svga = map_str["svaga"]
                        if (!url_svga!!.startsWith("http")) {
                            var resource_cdn = PreferencesUtils.getString(x.app(), "resource_cdn")
                            url_svga = resource_cdn + url_svga
                        }
                        var map1 = HashMap<String, String>()
                        map1["url_svga"] = url_svga
                        svgUtils?.addAnimation(map1)

                    }
                }

            }
        } else {
            ChatUtils.saveChatpannel(message!!.text, false)
        }
    }


    inner class GoldRecyclerAdapter2 : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

        var list = ArrayList<MutableMap<String, String>>()

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
            return fGoldViewHolder(ItemEditinfoHeadBinding.inflate(LayoutInflater.from(this@ChatAty)))
        }

        fun setData(list: ArrayList<MutableMap<String, String>>) {
            this.list.clear()
            this.list.addAll(list)
            notifyDataSetChanged()
        }

        override fun getItemCount(): Int = list.size

        override fun getItemViewType(position: Int): Int {
            return position
        }

        override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {

            if (holder is fGoldViewHolder) {

                with(holder) {
                    with(mBinding) {
                        var maxW = AutoUtils.getPercentWidthSizeBigger(400)
                        ImageLoader.loadImageAes(this@ChatAty,
                            list[position]["avatar"],
                            mBinding.ivHead,
                            maxW,
                            maxW)
                        mBinding.imgvDel.visibility = View.GONE
                    }
                }
            }

        }

        inner class fGoldViewHolder(binding: ItemEditinfoHeadBinding) :
            RecyclerView.ViewHolder(binding.root) {
            var mBinding: ItemEditinfoHeadBinding = binding

            init {
                AutoUtils.autoSize(binding.root)

            }
        }
    }

}
package com.mail.myapplication.ui.dg.gift

import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.lifecycle.Lifecycle
import androidx.viewpager2.adapter.FragmentStateAdapter
import androidx.viewpager2.widget.ViewPager2
import com.mail.comm.base.BaseAty
import com.mail.comm.base.BaseDialog
import com.mail.comm.net.AESCBCCrypt
import com.mail.comm.utils.JSONUtils
import com.mail.myapplication.R
import com.mail.myapplication.databinding.DgGiftBinding
import com.mail.myapplication.interfaces.Lar
import com.mail.myapplication.ui.wallet.RechargeAty
import com.yhz.adaptivelayout.utils.AutoUtils

class GiftDialog(context: BaseAty) : BaseDialog(context) {

    lateinit var mBinding: DgGiftBinding
    var mGiftDialogListen: GiftDialogListen? = null
    var mGiftCpDialogListen: GiftCpDialogListen? = null
    var lar = Lar()
    var list = ArrayList<Fragment>()
    lateinit var list_tv: Array<TextView>
    var type =""

    var mGiftDialogAdataper:GiftDialogAdataper?=null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        mBinding = DgGiftBinding.inflate(layoutInflater);
        setContentView(mBinding.root)
        window?.setWindowAnimations(R.style.dialogFullscreen3)
        val dialogWindow = window

        dialogWindow!!.setBackgroundDrawable(null)
        dialogWindow.setGravity(Gravity.BOTTOM)
        setCanceledOnTouchOutside(true)
        val m = baseAty.windowManager
        val d = m.defaultDisplay// 获取屏幕宽、高
        val p = dialogWindow.attributes
        window?.getDecorView()?.setPadding(0, 0, 0, 0)
        p.width = (d.width * 1) // 宽度设置为屏幕的0.85
        dialogWindow.attributes = p

        with(mBinding) {

            list_tv = arrayOf(tv01,tv02,tv03)

            if (type == "1"){

                var GiftNormalFrg1 = GiftNormalFrg.create("1")

                GiftNormalFrg1.setGiftNormalFrgListen(object : GiftNormalFrg.GiftNormalFrgListen{
                    override fun showCpValue(value: String) {
                        tvCpValue.text = "+${value}亲密度"
                        tvCpValue.visibility = View.VISIBLE
                    }
                })

                list.add(GiftNormalFrg1)
                mBinding.linlay0a2.visibility = View.GONE
                mBinding.linlay0a3.visibility = View.GONE

            }else{

               var GiftNormalFrg1 = GiftNormalFrg.create("1")
               var GiftNormalFrg2 = GiftNormalFrg.create("2")
               var GiftPackpageFrg3 = GiftPackpageFrg.create("3")

                GiftNormalFrg1.setGiftNormalFrgListen(object : GiftNormalFrg.GiftNormalFrgListen{
                    override fun showCpValue(value: String) {
                        tvCpValue.text = "+${value}亲密度"
                        tvCpValue.visibility = View.VISIBLE
                    }
                })

                GiftNormalFrg2.setGiftNormalFrgListen(object : GiftNormalFrg.GiftNormalFrgListen{
                    override fun showCpValue(value: String) {
                        tvCpValue.text = "+${value}亲密度"
                        tvCpValue.visibility = View.VISIBLE
                    }
                })

                GiftPackpageFrg3.setGiftNormalFrgListen(object :
                    GiftPackpageFrg.GiftPackpageFrgListen{
                    override fun showCpValue(value: String) {
                        tvCpValue.text = "+${value}亲密度"
                        tvCpValue.visibility = View.VISIBLE
                    }

                })

                list.add(GiftNormalFrg1)
                list.add(GiftNormalFrg2)
                list.add(GiftPackpageFrg3)
            }

            mGiftDialogAdataper = GiftDialogAdataper(baseAty.supportFragmentManager, baseAty.lifecycle)
            viewPager.adapter = mGiftDialogAdataper
            viewPager.offscreenPageLimit = list.size

            viewPager.registerOnPageChangeCallback(object: ViewPager2.OnPageChangeCallback() {
                override fun onPageSelected(position: Int) {

                    var frg = list[position]

                    if (frg is GiftNormalFrg){
                        if (TextUtils.isEmpty(frg.getCpValue())){
                            tvCpValue.visibility = View.GONE
                        }else{
                            tvCpValue.text = "+${frg.getCpValue()}亲密度"
                            tvCpValue.visibility = View.VISIBLE
                        }
                    }

                    if (frg is GiftPackpageFrg){
                        if (TextUtils.isEmpty(frg.getCpValue())){
                            tvCpValue.visibility = View.GONE
                        }else{
                            tvCpValue.text = "+${frg.getCpValue()}亲密度"
                            tvCpValue.visibility = View.VISIBLE
                        }
                    }

                    when(position){

                        0 -> {
                            setSelector(tv01)
                        }
                        1 -> {
                            setSelector(tv02)
                        }
                        2 ->{
                            setSelector(tv03)
                        }

                    }
                }
            })

            tv001.setOnClickListener {
                dismiss()
//                mGiftDialogListen?.recharge()
                if (baseAty is BaseAty){
                    (baseAty as BaseAty).startActivity(RechargeAty::class.java)
                }
            }

            tvAdDown.setOnClickListener {
                dismiss()
                var frg = list[viewPager.currentItem]
                if (frg is GiftNormalFrg){
                   var map = frg.getCheckIndexData()
                    if (map == null)return@setOnClickListener
                    when(viewPager.currentItem){
                        0->{
                            mGiftDialogListen?.sendGift(map["cover"]!!, map["svga"]!!,map["title"]!!, map["id"]!!)
                        }
                        1,2->{
                            mGiftCpDialogListen?.sendCpGift(map,map["id"]!!)
                        }
                    }
                }

                if (frg is GiftPackpageFrg){
                    var map = frg.getCheckIndexData()
                    if (map == null)return@setOnClickListener
                    when(viewPager.currentItem){
                        0->{
                            mGiftDialogListen?.sendGift(map["cover"]!!, map["svga"]!!,map["title"]!!, map["id"]!!)
                        }
                        1,2->{
                            mGiftCpDialogListen?.sendCpGift(map,map["related_id"].toString())
                        }
                    }
                }

            //                            mGiftDialogListen?.sendGift(list[index_check]["cover"]!!,
//                    list[index_check]["svga"]!!, list[index_check]["title"]!!, list[index_check]["id"]!!)
            }

            imgvCancel.setOnClickListener {
                dismiss()
            }

            linlay0a1.setOnClickListener {
                mBinding.viewPager.setCurrentItem(0,true)
            }
            linlay0a2.setOnClickListener {
                mBinding.viewPager.setCurrentItem(1,true)
            }
            linlay0a3.setOnClickListener {
                mBinding.viewPager.setCurrentItem(2,true)
            }
        }
    }

    fun setDataType(type:String){
        this.type = type
//        if (isShowing){
//            when(type){
//                "1"->{
//                    mBinding.linlay0a2.visibility = View.GONE
//                    mBinding.linlay0a3.visibility = View.GONE
////                    list.clear()
////                    list.add(GiftNormalFrg.create("1"))
////                    mGiftDialogAdataper?.notifyDataSetChanged()
//                }
//            }
//        }
    }

    private fun setSelector(tv: TextView) {
        for (i in list_tv.indices) {
            if (tv === list_tv[i]) {
                list_tv[i].setTextColor(Color.parseColor("#00F7AD"))
                list_tv[i].setTypeface(Typeface.defaultFromStyle(Typeface.BOLD));//加粗
                list_tv[i].setTextSize(TypedValue.COMPLEX_UNIT_PX, AutoUtils.getPercentWidthSizeBigger(45).toFloat())
            } else {
                list_tv[i].setTextColor(Color.parseColor("#B4B4B4"))
                list_tv[i].setTypeface(Typeface.defaultFromStyle(Typeface.NORMAL));//加粗
                list_tv[i].setTextSize(TypedValue.COMPLEX_UNIT_PX, AutoUtils.getPercentWidthSizeBigger(45).toFloat())
            }
        }
    }

    inner class GiftDialogAdataper(fa: FragmentManager, lifecycle: Lifecycle) :

        FragmentStateAdapter(fa, lifecycle) {

        override fun getItemCount(): Int =list.size

        override fun createFragment(position: Int): Fragment = list[position]

    }

    interface GiftDialogListen {
        fun recharge()
        fun sendGift(gift_cover: String, gift_svga: String, gift_title: String, gift_id: String)
//        fun sendCpGift(map:MutableMap<String,String>)
    }

    interface GiftCpDialogListen {
        fun sendCpGift(map:MutableMap<String,String>,id:String)
    }

    fun requestData() {
        if (isShowing) {
            lar.b102(this)

            if (list.size>2){
                var frg = list[2]
                if (frg is GiftPackpageFrg){
                    frg.refreshData()
                }
            }

        }
    }

    override fun onComplete(var2: String?, type: String?) {
        super.onComplete(var2, type)

        if (type == "coins/wallet") {
            var map = JSONUtils.parseKeyAndValueToMap(var2)
            if (map["code"] == "200") {
                var str_wallet = AESCBCCrypt.aesDecrypt(map["data"])
                var map_info = JSONUtils.parseKeyAndValueToMap(str_wallet)
                mBinding.tvCoins.text = map_info["user_coins"]
            }
        }
    }

    fun setGiftDialogListen(mGiftDialogListen: GiftDialogListen) {
        this.mGiftDialogListen = mGiftDialogListen
    }

    fun setGiftCpDialogListen(mGiftCpDialogListen: GiftCpDialogListen) {
        this.mGiftCpDialogListen = mGiftCpDialogListen
    }

}
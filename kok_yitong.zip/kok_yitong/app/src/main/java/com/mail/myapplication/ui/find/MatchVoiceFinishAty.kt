package com.mail.myapplication.ui.find

import android.os.Bundle
import android.os.Handler
import android.text.TextUtils
import android.view.View
import com.mail.comm.image.ImageLoader
import com.mail.comm.utils.JSONUtils
import com.mail.comm.utils.TimeUtils
import com.mail.myapplication.BaseXAty
import com.mail.myapplication.R
import com.mail.myapplication.databinding.AtyMatchVoiceFinishBinding
import com.mail.myapplication.interfaces.Home
import com.mail.myapplication.interfaces.Lar
import com.mail.myapplication.ui.dg.AttenDialog
import com.mail.myapplication.ui.msg.chat.ChatReportAty
import com.mail.myapplication.ui.utils.MyUtils3
import com.yhz.adaptivelayout.utils.AutoUtils

class MatchVoiceFinishAty:BaseXAty() {

    lateinit var mBinding: AtyMatchVoiceFinishBinding

    var to_avatar =""
    var to_nick =""
    var is_follow =""
    var to_year =""
    var to_user_code =""
    var start_time_join =""
    var lar = Lar()
    var home = Home()
    var match_id =""
    var mAttenDialog: AttenDialog?=null
    var min_unfollow_coins = ""

    var is_zan = "0"
    var maxW_head = AutoUtils.getPercentWidthSizeBigger(400)

    override fun getLayoutId()=0

    override fun getLayoutView(): View {
        mBinding = AtyMatchVoiceFinishBinding.inflate(layoutInflater);
        return mBinding.root
    }

    override fun initView() {
        to_avatar =intent.getStringExtra("to_avatar").toString()
        to_nick =intent.getStringExtra("to_nick").toString()
        is_follow =intent.getStringExtra("is_follow").toString()
        to_year =intent.getStringExtra("to_year").toString()
        start_time_join =intent.getStringExtra("start_time_join").toString()
        to_user_code =intent.getStringExtra("to_user_code").toString()
        match_id =intent.getStringExtra("match_id").toString()
        min_unfollow_coins =intent.getStringExtra("min_unfollow_coins").toString()
    }

    override fun requestData() {
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setStatusColor("#000000")
        setAndroidNativeLightStatusBar(false)
//        ImageLoader.loadImageAes(this,to_avatar,mBinding.ivHead,maxW_head,maxW_head)

        mBinding.tvYear.text = to_year+"岁"

        var time = System.currentTimeMillis()-start_time_join.toLong()
        var time_txt =TimeUtils.formatSecond2(time.toDouble()/1000)

        if (is_follow == "0"){
//          MyUtils3.setTextMaskFilterSpan(mBinding.tvName, to_nick, 0)
            mBinding.tvName.text = "陌生的彩虹星人"
            mBinding.imgvAtten.setImageResource(R.drawable.ia_23)

        }else{
            mBinding.tvName.text = to_nick
            mBinding.imgvAtten.setImageResource(R.drawable.ia_62)
            ImageLoader.loadImageAes(this,to_avatar,mBinding.ivHead,maxW_head,maxW_head)
        }

        mBinding.tvTime.text = "通话时长${time_txt}"

        if (TextUtils.isEmpty(start_time_join)||start_time_join == "0"){
            mBinding.tvTime.text = "通话时长0s"
        }

        mBinding.imgvAtten.setOnClickListener {
            if (is_follow == "0"){

                if (mAttenDialog == null){
                    mAttenDialog = AttenDialog(this)
                }
                mAttenDialog?.setAttenDialogListen(object : AttenDialog.AttenDialogListen{
                    override fun onclik01() {
                    }

                    override fun onclik02() {
                        startProgressDialog()
                        home.a93(min_unfollow_coins,to_user_code,this@MatchVoiceFinishAty)
                    }
                })
                mAttenDialog?.show()
                mAttenDialog?.requestData(min_unfollow_coins)
            }
        }
    }

    override fun onComplete(var2: String?, type: String?) {
        super.onComplete(var2, type)
        stopProgressDialog()

        if (type=="chat/like"){
            stopProgressDialog()
            var map = JSONUtils.parseKeyAndValueToMap(var2)
            if (map["code"] == "200") {
                is_zan = "1"
                Handler().postDelayed({
                    run {
                        mBinding.imgvZan.setImageResource(R.drawable.ia_63)

                        mBinding.imgvZan.visibility = View.VISIBLE
                        mBinding.imgvAnimationGif.visibility = View.GONE
                    }
                }, 2000)

            }else{
                showToastS(map["message"])
            }
        }

        if (type == "unlock/follow"){
            stopProgressDialog()
            var map = JSONUtils.parseKeyAndValueToMap(var2)
            if (map["code"] == "200") {
                is_follow = "1"
                mBinding.tvName.text = to_nick
                mBinding.imgvAtten.setImageResource(R.drawable.ia_62)
                ImageLoader.loadImageAes(this,to_avatar,mBinding.ivHead,maxW_head,maxW_head)

            }else{
                showToastS(map["message"])
            }
        }

    }

    override fun onExceptionType(type: String?) {
        super.onExceptionType(type)
        stopProgressDialog()
        if (type=="chat/like"){
            mBinding.imgvZan.visibility = View.VISIBLE
            mBinding.imgvAnimationGif.visibility = View.GONE
        }
    }

    fun mainClick(v: View) {

        when (v.id) {

            R.id.relay_back,R.id.tv_ok -> {
                finish()
            }

            R.id.linlay_report ->{
                var bundle = Bundle()
                bundle.putString("to_user_code",to_user_code)
                startActivity(ChatReportAty::class.java,bundle)
            }

            R.id.imgv_zan ->{
                if (is_zan == "1"){
                    return
                }
                mBinding.imgvZan.visibility = View.GONE
                mBinding.imgvAnimationGif.visibility = View.VISIBLE
//                startProgressDialog()
                home.a94(match_id,to_user_code,this)
            }

        }
    }

}
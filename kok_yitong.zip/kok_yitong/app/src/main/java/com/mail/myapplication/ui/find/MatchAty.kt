package com.mail.myapplication.ui.find

import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.text.TextUtils
import android.view.View
import android.view.animation.LinearInterpolator
import android.widget.Toast
import androidx.lifecycle.lifecycleScope
import com.google.android.exoplayer2.*
import com.google.android.exoplayer2.source.MediaSource
import com.google.android.exoplayer2.source.ProgressiveMediaSource
import com.google.android.exoplayer2.source.hls.HlsMediaSource
import com.google.android.exoplayer2.trackselection.AdaptiveTrackSelection
import com.google.android.exoplayer2.trackselection.DefaultTrackSelector
import com.google.android.exoplayer2.upstream.DefaultAllocator
import com.google.android.exoplayer2.upstream.DefaultBandwidthMeter
import com.mail.comm.app.AppConfig
import com.mail.comm.app.BaseApp
import com.mail.comm.net.AESCBCCrypt
import com.mail.comm.utils.JSONUtils
import com.mail.comm.utils.MyUtils
import com.mail.comm.utils.TimeUtils
import com.mail.comm.video.exo.CacheDataSourceFactory
import com.mail.comm.view.load.XLoadTip
import com.mail.myapplication.BaseXAty
import com.mail.myapplication.R
import com.mail.myapplication.databinding.AtyMatchBinding
import com.mail.myapplication.interfaces.Home
import com.mail.myapplication.ui.MainWalletAty
import com.mail.myapplication.ui.app.NoticeVh
import com.mail.myapplication.ui.dg.CommonDialog
import com.mail.myapplication.ui.msg.chat.ChatAty
import com.mail.myapplication.ui.utils.ImageUtil
import com.mail.myapplication.ui.wallet.ShareAty
import io.agora.rtm.RtmMessage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.xutils.common.util.LogUtil
import java.util.*

class MatchAty:BaseXAty() {

    var match_id =""
    var match_type ="" //voice  word
    var info_code =""
    var isMatch = false
    var isClickEnterChat = false
    var match_video_url =""
    var time_end:Double?=null
    var timerT: Timer? = null
    var timerTaskT: TimerTask? = null
    var noticeVh:NoticeVh?=null
    var mCommonDialog: CommonDialog?=null
    var objectAnimator: ObjectAnimator? = null

    var home = Home()

    lateinit var mBinding: AtyMatchBinding

    override fun getLayoutId(): Int =0

    override fun initView() {
        match_type = intent.getStringExtra("match_type").toString()
        info_code = MyUtils.getInfoDetails(this,"info_code")
        match_video_url = BaseApp.instance?.getOneMapData("match_video_url").toString()
        var resource_cdn =BaseApp.instance?.getOneMapData("resource_cdn").toString()
        if (!match_video_url.startsWith("http")){
            match_video_url = resource_cdn+match_video_url
        }
//        LogUtil.e("match_video_url="+match_video_url)
    }

    override fun getLayoutView(): View {
        mBinding = AtyMatchBinding.inflate(layoutInflater);
        return mBinding.root
    }

    override fun onResume() {
        super.onResume()
        if (isMatch){
            startLoop()
        }
        LogUtil.e("NoticeVh MatchAty onResume")
        noticeVh?.onResume()
        simpleExoPlayer?.play()
    }

    override fun onPause() {
        super.onPause()
        cancelTimerT()
        noticeVh?.onPause()
        simpleExoPlayer?.pause()
    }

    override fun onDestroy() {
        super.onDestroy()
        noticeVh?.onDestroy()
        simpleExoPlayer?.release()
    }

    fun startLoop(){
       var voice_time = 30
        if (time_end==null){
            var c_time =TimeUtils.getBeijinTime().toDouble()
            LogUtil.e("startLoop"+TimeUtils.getBeijinTime())
            time_end = c_time +1000*voice_time
        }
        startTime()
    }

    fun startTime() {
        cancelTimerT()
        timerT = Timer()
        timerTaskT = object : TimerTask() {
            override fun run() {
                var c_time = TimeUtils.getBeijinTime().toDouble()
                var t = (time_end!!  - c_time)/1000
                var text = TimeUtils.formatSecond2(t)

                lifecycleScope.launch {
                    withContext(Dispatchers.Main) {
                        if (t <= 0) {
                            cancelTimerT()
                            showTimeDialog()
                        }
                        mBinding.tvTime.text = text
                    }
                }
            }
        }
        timerT?.schedule(timerTaskT, 0, 500)
    }

    fun showTimeDialog(){
        if(mCommonDialog == null){
            mCommonDialog = CommonDialog(this)
        }
        mCommonDialog?.setCommonDialogListen(object : CommonDialog.CommonDialogListen{

            override fun onclik01() {
                mCommonDialog?.dismiss()
//                finish()
                mBinding.tvCancel.performClick()
            }

            override fun onclik02() {
                mCommonDialog?.dismiss()
                time_end = null
                startLoop()
                startProgressDialog()
                requestData2()
            }
        })

        mCommonDialog?.show()
        mCommonDialog?.setCancelViewVisibility(false)
        mCommonDialog?.setCommCanceled(false)
        mCommonDialog?.setData("当前服务器爆满，暂未匹配到合适的对象","取消匹配","继续等待")

    }

    fun cancelTimerT() {
        timerT?.cancel()
        timerT = null
        timerTaskT?.cancel()
        timerTaskT = null
    }

    override fun requestData() {
        mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.loading)
        requestData2()
    }

    fun requestData2(){
        var type = "2"
        if (match_type == "voice"){
            type ="1"
        }
        home.a53(type,match_id,this)
    }

    override fun onComplete(var2: String?, type: String?) {
        super.onComplete(var2, type)

        if (type =="match"){
            stopProgressDialog()
            var map = JSONUtils.parseKeyAndValueToMap(var2)
            if (map["code"] == "200") {
                mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.finish)
                var str = AESCBCCrypt.aesDecrypt(map["data"])
                var map_data = JSONUtils.parseKeyAndValueToMap(str)
                match_id = map_data["match_id"]!!
                isMatch = true
                startLoop()

            }else if(map["code"]=="206"){
                mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.finish)
                if (mCommonDialog == null){
                    mCommonDialog = CommonDialog(this)
                }

                mCommonDialog?.setCommonDialogListen(object : CommonDialog.CommonDialogListen{

                    override fun onclik01() {
                        mCommonDialog?.dismiss()
                        finish()
                    }

                    override fun onclik02() {
                        mCommonDialog?.dismiss()
                        if (info_vip_level=="0"){
                            var bundle = Bundle()
                            bundle.putString("page_type","pay")
                            startActivity(MainWalletAty::class.java,bundle)
                        }else{
                            startActivity(ShareAty::class.java)
                        }
                        finish()
                    }
                })

                mCommonDialog?.show()
                mCommonDialog?.setCancelViewVisibility(false)
                mCommonDialog?.setCommCanceled(false)
                if (info_vip_level=="0"){
                    mCommonDialog?.setData(map["message"]!!,"再想想","去开通")
                }else{
                    mCommonDialog?.setData(map["message"]!!,"取消","去分享")
                }
            } else if(map["code"]=="1008"){
                mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.finish)
                showCommonDialog("1009",false,map["message"],"","我知道了")
            } else{
                mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.error)
                Toast.makeText(this,map["message"],Toast.LENGTH_SHORT).show()
                finish()
            }
        }

        if (type == "cancle/match"){
            var map = JSONUtils.parseKeyAndValueToMap(var2)
            if (map["code"] == "200") {
                finish()
            }else{
                finish()
                Toast.makeText(this,map["message"],Toast.LENGTH_SHORT).show()
            }
        }

        if (type =="match/details"){
            stopProgressDialog()
            var map = JSONUtils.parseKeyAndValueToMap(var2)
            if (map["code"] == "200") {

                var str = AESCBCCrypt.aesDecrypt(map["data"])
                var map_data = JSONUtils.parseKeyAndValueToMap(str)

                var map_from_user = JSONUtils.parseKeyAndValueToMap(map_data["from_user"])
                var map_to_user = JSONUtils.parseKeyAndValueToMap(map_data["to_user"])

                if (map_from_user["user_code"]!=info_code){
                    showToastS("user_code != info_code")
                    return
                }
                if (map_to_user["user_code"]==info_code){
                    showToastS("user_code == info_code")
                    return
                }

                if (match_type == "word"){
                    var bundle = Bundle()
                    bundle.putString("code", map_to_user["user_code"])
                    bundle.putString("nick", map_to_user!!["nick"]!!)
                    bundle.putString("avatar", map_to_user!!["avatar"]!!)
                    bundle.putString("sendMaxNum", map_data!!["send_message_num"]!!)
                    bundle.putString("receiveNum", map_data!!["receive_message_num"]!!)
                    bundle.putString("min_unfollow_coins", map_data!!["min_unfollow_coins"]!!)
                    bundle.putString("enter_type", "match")
                    bundle.putString("match_id", match_id)
                    bundle.putString("json", str)
                    startActivity(ChatAty::class.java, bundle)
                    finish()
                }else{
                    var bundle = Bundle()
                    bundle.putString("match_id", match_id)
                    bundle.putString("json", str)
                    bundle.putString("user_type", "from")
                    startActivity(MatchVoiceAty::class.java,bundle)
                    finish()
                }

            }else{
                showToastS(map["message"])
            }
        }
    }

    override fun onBackPressed() {
        mBinding.tvCancel.performClick()
    }

    override fun onExceptionType(type: String?) {
        super.onExceptionType(type)
        stopProgressDialog()
        if (type =="match"){
            if (TextUtils.isEmpty(match_id)){
                mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.error)
            }else{
                mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.finish)
            }
        }
        if (type == "cancle/match"){
            stopProgressDialog()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        LogUtil.e("NoticeVh MatchAty onCreate")
        setTranslanteBar()
        if (AppConfig.model == "wanou"){
            window.navigationBarColor = Color.parseColor("#0a0b31")
        }
//        setStatusColor("#000000")
        setAndroidNativeLightStatusBar(false)
        mBinding.ivShowPic.setClipToOutline(true)
        mBinding.ivShowPic.setOutlineProvider(ImageUtil.getOutline(true, 20, 1))
        objectAnimator = ObjectAnimator.ofFloat( mBinding.ivShowPic, "rotation", 0f, 360f)
        objectAnimator?.setDuration((20 * 1000).toLong())
        objectAnimator?.setRepeatMode(ValueAnimator.RESTART)
        objectAnimator?.setInterpolator(LinearInterpolator())
        objectAnimator?.setRepeatCount(-1)
        objectAnimator?.start()

        initIm()
        mBinding.loading.setLoadingTipXReloadCallback(object: XLoadTip.LoadingTipXReloadCallback{
            override fun reload() {
                requestData()
            }
        })

        noticeVh = NoticeVh(this,mBinding.relay)
        noticeVh?.addToParent()
        noticeVh?.onCreate()
        noticeVh?.setNoticeVhListen(object : NoticeVh.NoticeVhListen{

            override fun onClickEnterChat() {
                isClickEnterChat = true
            }

        })

        if (AppConfig.model == "wanou"){
            video = match_video_url
//            video = "http://cdnimg.yt.xingtaole.com/ig/user_video/110214/RDvk/F3qW/40b5064a3f8071533cf030954d3123fd.m3u8"
//        video = "http://cdnimg.yt.xingtaole.com/ig/user_video/110123/Dvq5/2i72/b4e6ca243f3e7242b26f59abd9230b71.m3u8"
            initPlayer()
        }
    }

    var simpleExoPlayer: SimpleExoPlayer? = null
    var video = ""

    fun initPlayer() {
        var videoTrackSelectionFactory = AdaptiveTrackSelection.Factory()

        //轨道选择器
        var trackSelector = DefaultTrackSelector(this, videoTrackSelectionFactory)

        //用于控制MediaSource何时缓冲更多的媒体资源以及缓冲多少媒体资源
        var loadControl = DefaultLoadControl.Builder()
            .setAllocator(DefaultAllocator(true, C.DEFAULT_BUFFER_SEGMENT_SIZE))
            .setBufferDurationsMs(360000, 600000, 1000, 5000)
            .setPrioritizeTimeOverSizeThresholds(false)
            .setTargetBufferBytes(C.LENGTH_UNSET)
            .createDefaultLoadControl()

        //Provides estimates of the currently available bandwidth.
        var bandwidthMeter = DefaultBandwidthMeter.Builder(this).build()

        //渲染器，用于渲染媒体文件。
        var renderersFactory = DefaultRenderersFactory(this)

//        val cache: Cache = VideoCache.getInstance()

        simpleExoPlayer = SimpleExoPlayer.Builder(this, renderersFactory)
            .setTrackSelector(trackSelector)
            .setLoadControl(loadControl)
            .setBandwidthMeter(bandwidthMeter)
            .build()

//        var dataSourceFactory = DefaultDataSourceFactory(requireContext(), Util.getUserAgent(requireContext(), "壹同"))

        var dataSourceCacheFactory = CacheDataSourceFactory(this, 1024 * 1024 * 1024, 5 * 1024 * 1024,"壹同")

        var currUrl = video

        LogUtil.e("currUrl=="+currUrl)

        //播放的媒体文件
        var videoSource: MediaSource
        if (currUrl.contains(".m3u8")) {
            videoSource = HlsMediaSource.Factory(dataSourceCacheFactory)
                .createMediaSource(Uri.parse(currUrl));
            //addEventListener 这里只有两个参数都要传入值才可以成功设置
            // 否者会被断言 Assertions.checkArgument(handler != null && eventListener != null);
            // 并且报错  IllegalArgumentException()  所以不需要添加监听器时 注释掉
            //      videoSource .addEventListener( handler, null);
        } else {
            videoSource = ProgressiveMediaSource.Factory(dataSourceCacheFactory)
                .createMediaSource(Uri.parse(currUrl));
        }

//        var audioSource =  ExtractorMediaSource(Uri.parse(url), CacheDataSourceFactory(context, 100 * 1024 * 1024, 5 * 1024 * 1024),  DefaultExtractorsFactory(), null, null);

        simpleExoPlayer?.addListener(object : Player.EventListener {

            override fun onPlayerError(error: ExoPlaybackException) {
                super.onPlayerError(error)
//                showToastS("播放异常")
            }

            override fun onPlayerStateChanged(playWhenReady: Boolean, playbackState: Int) {
//
            }
        })

//        mBinding.playerView?.resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FILL
        simpleExoPlayer?.prepare(videoSource)
        simpleExoPlayer?.playWhenReady = true  //自动播放
        simpleExoPlayer?.repeatMode = Player.REPEAT_MODE_ONE   //循环播放
        mBinding.playerView.player = simpleExoPlayer;

    }

    fun mainClick(v: View) {

        when (v.id) {

            R.id.tv_cancel -> {
                startProgressDialog()
                home.a58(match_id,this)
            }

        }

    }

    override fun onMessageReceived(message: RtmMessage?, p1: String?) {
        super.onMessageReceived(message, p1)

        var str = AESCBCCrypt.aesDecrypt(message!!.text)

        if (message != null) {
            LogUtil.e("AESCBCCrypt-matchaty="+message.text)
        }
        var map = JSONUtils.parseKeyAndValueToMap(str)

        if (map["type"] != "20") {
            return
        }
//        if (map["match_id"] != match_id) {
//            requestData2()
//            return
//        }
        var notice_type = map["notice_type"]
        runOnUiThread {
            when (notice_type) {
                //202=语聊匹配成功;

                "202" -> {
                    if (isClickEnterChat){
                        return@runOnUiThread
                    }
                    if (map["match_id"] != match_id) {
                        requestData2()
                        return@runOnUiThread
                    }
                    startProgressDialog("进入聊天中..",false)
                    home.a55(match_id,this)
                }

                //文字聊天匹配成功
                "204" -> {
                    if (isClickEnterChat){
                        return@runOnUiThread
                    }
                    if (map["match_id"] != match_id) {
                        requestData2()
                        return@runOnUiThread
                    }
                    if (match_type !="word"){
                        return@runOnUiThread
                    }
                    startProgressDialog("进入聊天中..",false)
                    home.a55(match_id,this)
                }

                "201","203"->{
                    noticeVh?.onResume()
                }
            }
        }
    }
}
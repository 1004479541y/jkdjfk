package com.mail.myapplication.ui.web

import android.os.Bundle
import android.view.View
import android.widget.FrameLayout
import com.just.agentweb.AgentWeb
import com.just.agentweb.WebChromeClient
import com.just.agentweb.WebViewClient
import com.mail.myapplication.BaseXAty
import com.mail.myapplication.R
import com.mail.myapplication.databinding.*

class WebAty : BaseXAty() {


    lateinit var mBinding: AtyWebBinding
    var url =""
    var mAgentWeb:AgentWeb?=null
    override fun getLayoutId(): Int = 0

    override fun initView() {
    }

    override fun requestData() {
    }


    override fun getLayoutView(): View {
        mBinding = AtyWebBinding.inflate(layoutInflater);
        return mBinding.root
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        with(mBinding){
            initTopview2(include.relayTopBg, resources.getString(R.string.c_4))
            include.tvTitle.text = ""
            url = intent.getStringExtra("url").toString()

            mAgentWeb = AgentWeb.with(this@WebAty)
                .setAgentWebParent(flWebContainer, FrameLayout.LayoutParams(-1, -1))
                .useDefaultIndicator()
                .setWebChromeClient(mWebChromeClient)
                .setWebViewClient(mWebViewClient)
                .createAgentWeb()
                .ready()
                .go(url)

        }
    }


    override fun onPause() {
        mAgentWeb!!.webLifeCycle.onPause()
        super.onPause()
    }

    override fun onBackPressed() {
        if (!mAgentWeb!!.back()) {
            super.onBackPressed()
        }
    }

    override fun onResume() {
        mAgentWeb!!.webLifeCycle.onResume()
        super.onResume()
    }

    override fun onDestroy() {
        mAgentWeb!!.webLifeCycle.onDestroy()
        super.onDestroy()
    }


    val mWebChromeClient: WebChromeClient = object : WebChromeClient() {
    }

    var mWebViewClient: WebViewClient = object : WebViewClient() {
    }


    fun mainClick(v: View) {

        when (v.id) {

            R.id.relay_back -> {
                finish()
            }
        }
    }





}
package com.mail.myapplication.ui.wallet

import android.content.Context
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.RelativeLayout
import androidx.recyclerview.widget.RecyclerView
import com.mail.comm.image.ImageLoader
import com.mail.myapplication.R
import com.youth.banner.adapter.BannerAdapter
import com.youth.banner.util.BannerUtils
import com.yhz.adaptivelayout.config.AutoLayoutConifg
import com.yhz.adaptivelayout.utils.AutoUtils

class ImageAdapter(imageUrls: ArrayList<MutableMap<String,String>>,context:Context) : BannerAdapter<MutableMap<String,String>, ImageAdapter.ImageHolder>(imageUrls) {

    var context:Context?=null
    init {
        this.context = context
    }
    override fun onCreateHolder(parent: ViewGroup?, viewType: Int): ImageHolder {
        val imageView = BannerUtils.getView(parent!!, R.layout.item_frg_wallet2) as RelativeLayout
        return ImageHolder(imageView)
    }


    override fun onBindView(holder: ImageHolder, data: MutableMap<String,String>, position: Int, size: Int) {
        var maxW = AutoLayoutConifg.getInstance().screenWidth
        ImageLoader.loadImageAes(context!! ,data["cover"],holder.imageView,maxW,maxW)
    }

    class ImageHolder(view: View) : RecyclerView.ViewHolder(view) {
        var imageView: ImageView?=null
        init {
            AutoUtils.autoSize(view)
            imageView = view.findViewById(R.id.imgv_01)
        }
    }

}


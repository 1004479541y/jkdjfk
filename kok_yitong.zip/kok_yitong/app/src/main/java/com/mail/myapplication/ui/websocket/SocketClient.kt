package com.mail.myapplication.ui.websocket

import android.util.Log
import com.mail.comm.app.AppConfig
import org.xutils.common.util.LogUtil
import java.net.URI
import java.util.*

class SocketClient {

    private var timer: Timer? = null
    private var timerTask: TimerTask? = null
    private var client: JWebSClient? = null
    private var url: String? = null
//    private var mCallback: UpdateUiCallBack? = null

    companion object {
        private var socketClient: SocketClient? = null
        fun getInstance(): SocketClient? {
            if (null == socketClient) {
                synchronized(SocketClient::class.java) {
                    if (null == socketClient) socketClient = SocketClient()
                }
            }
            return socketClient
        }
    }

//    fun registerCallback(paramICallback: UpdateUiCallBack) {
//        this.mCallback = paramICallback
//    }

    fun startHeartbeat(url: String) {
        this.url =url
        timer = Timer()
        timerTask = object : TimerTask() {
            override fun run() {
                try {
                    client?.send("ping") ?: reConnects()
                }catch (e:java.lang.Exception){
                    reConnects()
                }
            }
        }
        if (AppConfig.debug){
            timer?.schedule(timerTask, 0, 5*1000)
        }else{
            timer?.schedule(timerTask, 0, 15*1000)
        }
    }

    fun reConnects() {
        client?.let {
            if (it.isClosed) reconnectWs()
        } ?: reConnect()
    }

    private fun reconnectWs() {
        object : Thread() {
            override fun run() {
                try {
                    Log.e("JWebSocketClientService", "开启重连")
                    client?.reconnectBlocking()
                } catch (e: InterruptedException) {
                    e.printStackTrace()
                }
            }
        }.start()
    }

    //ws://chats.lfjsjs.com:9701/0684105cd0111e27362b3403aab203f2/Android/15750916852DvgaH%7E_%23/2dab932b611abcc92eb156328a0f761b

    private fun reConnect() {
        url?.let {
            val uri = URI.create(it)
            val map = HashMap<String, String>()
            map["Origin"] = it
            map["User-Agent"] =  System.getProperty("http.agent")
            client = JWebSClient(uri, socketClient,map)
            connetToServer()
        }
    }

    private fun connetToServer() {
        object : Thread() {
            override fun run() {
                try {
                    client?.connectBlocking()
                } catch (e: InterruptedException) {
                    e.printStackTrace()
                }
            }
        }.start()
    }

    private fun cancelTimer() {
        timer?.cancel()
        timer = null
        timerTask?.cancel()
        timerTask = null
    }


    fun closeConnect() {
        cancelTimer()
        try {
            client?.close()
        } catch (e: Exception) {
            e.printStackTrace()
            Log.e("Socket", "断开连接异常")
        } finally {
            client = null
            socketClient = null
        }
    }

    fun  returnMsg(msg:String){
//        mCallback?.updateUi(msg)
    }


    fun sendMsg(msgGson: String) {
        Log.e("JWebSClientSocket_send:", msgGson)
        try {
            client?.send(msgGson)
        }catch (e:java.lang.Exception){

        }

    }
}
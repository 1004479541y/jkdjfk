package com.mail.myapplication.ui.mine.fans

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.mail.comm.app.BaseApp
import com.mail.comm.image.ImageLoader
import com.mail.comm.net.AESCBCCrypt
import com.mail.comm.utils.JSONUtils
import com.mail.comm.view.load.XLoadTip
import com.mail.comm.view.refresh.XRefreshInterface
import com.mail.myapplication.BaseXAty
import com.mail.myapplication.R
import com.mail.myapplication.databinding.*
import com.mail.myapplication.interfaces.Lar
import com.mail.myapplication.ui.mine.person.PersonOtherDetailsAty
import com.mail.myapplication.ui.utils.MyUtils3
import com.yhz.adaptivelayout.utils.AutoUtils

class FansGroupMyJoinAty : BaseXAty() {

    lateinit var mBinding: AtyFansGroupMyJoinBinding

    var uid=""
    var uid_my=""
    var page = 1
    var lar = Lar()

    var mAdapter: GoldRecyclerAdapter? = null
    var list = ArrayList<MutableMap<String, String>>()


    override fun getLayoutId(): Int = 0

    override fun getLayoutView(): View {
        mBinding = AtyFansGroupMyJoinBinding.inflate(layoutInflater)
        return mBinding.root
    }

    override fun initView() {
        if (intent.hasExtra("uid")){
            uid = intent.getStringExtra("uid").toString()
        }
        uid_my = BaseApp.instance?.getOneMapData("info_code").toString()
    }

    override fun requestData() {
        mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.loading)
        lar.b30(page,uid,this)
    }

    fun requestData2() {
        lar.b30(page,uid,this)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        initTopview2(mBinding.include.relayTopBg, resources.getString(R.string.c_4))
        if (uid_my == uid){
            mBinding.include.tvTitle.text = "我加入的私密團"
        }else{
            mBinding.include.tvTitle.text = "TA加入的私密團"
        }

        var mLayoutManager2 = GridLayoutManager(this, 1)
        mLayoutManager2.orientation = RecyclerView.VERTICAL
        mBinding.recyclerview.layoutManager = mLayoutManager2
        mAdapter = GoldRecyclerAdapter()
        mBinding.recyclerview.adapter = mAdapter

        mBinding.swipeRefreshLayout.setEnableLoadmore(true)
        mBinding.swipeRefreshLayout.setEnableRefresh(true)
        mBinding.swipeRefreshLayout.setXRefreshAndLoadListen(object : XRefreshInterface {
            override fun refreshStart() {
                page =1
                requestData2()
            }

            override fun loadMoreStart() {
                page++
                requestData2()
            }

        })

        mBinding.loading.setLoadingTipXReloadCallback(object: XLoadTip.LoadingTipXReloadCallback{
            override fun reload() {
                requestData()
            }

        })
    }


    fun mainClick(v: View) {

        when (v.id) {

            R.id.relay_back -> {
                finish()
            }
        }
    }


    override fun onComplete(var2: String?, type: String?) {
        super.onComplete(var2, type)

//        if (type=="group/quit"){
//            stopProgressDialog()
//            var map = JSONUtils.parseKeyAndValueToMap(var2)
//            if(map["code"]=="200"){
//                showToastS("退团成功")
//                quitGroupDialog?.cancel()
//
//                if (index_check==-1||index_check>=list.size){
//                    return
//                }
//
//                list.removeAt(index_check)
//                mAdapter?.notifyItemRemoved(index_check)
//                mAdapter?.notifyItemRangeChanged(index_check, mAdapter?.itemCount!!) //刷新被删除数据，以及其后面的数据
//
//            }else{
//                showToastS(map["message"])
//            }
//        }

        if (type== "user/list"){
            mBinding.swipeRefreshLayout.finishRefreshing()
            mBinding.swipeRefreshLayout.finishLoadmore()
            mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.finish)
            var map = JSONUtils.parseKeyAndValueToMap(var2)
            if(map["code"]=="200"){
                var str = AESCBCCrypt.aesDecrypt(map["data"])
                var mList = JSONUtils.parseKeyAndValueToMapList(str)
                if (page == 1){
                    list.clear()
                    list.addAll(mList)

                }else{
                    list.addAll(mList)
                }

                if (page==1&&mList.size==0){
                    mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.empty)
                }else{
                    if (mList!=null&&mList.size>0){
                        mAdapter?.notifyDataSetChanged()
                    }
                }
            }else{
                if (page==1){
                    mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.error)
                }
            }
        }
    }

    override fun onExceptionType(type: String?) {
        super.onExceptionType(type)
        stopProgressDialog()
        if (type== "user/list"){
            mBinding.swipeRefreshLayout.finishRefreshing()
            mBinding.swipeRefreshLayout.finishLoadmore()
            if (page==1&&list.size==0){
                mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.error)
            }else{
                mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.finish)
            }
        }
    }

    inner class GoldRecyclerAdapter : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {

            return fGoldViewHolder(ItemFansGroupMyJoinBinding.inflate(LayoutInflater.from(this@FansGroupMyJoinAty)))

        }

        override fun getItemCount(): Int = list.size

        override fun getItemViewType(position: Int): Int {
            return position
        }

        override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {

            if (holder is fGoldViewHolder) {

                with(holder) {
                    with(mBinding) {

                        var map = list[position]
                        var map_user = map

                        var maxW_head = AutoUtils.getPercentWidthSizeBigger(200)
                        ImageLoader.loadImageAes(this@FansGroupMyJoinAty, map_user["avatar"], ivHead,maxW_head,maxW_head)
                        tvName.text = map_user["nick"]

                        tvContent.text = list[position]["intro"]


                        ivHead.setOnClickListener {
                            var bundle = Bundle()
                            bundle.putString("user_id",map_user["code"])
                            startActivity(PersonOtherDetailsAty::class.java,bundle)
                        }

                        MyUtils3.setVipLevel(map_user["vip_level"], mBinding.imgvVipLevel,0)

                        when (map_user["gender"]) {
                            "1" -> {
                                mBinding.imgvGender.visibility = View.VISIBLE
                                mBinding.imgvGender.setImageResource(R.mipmap.ic_60)
                            }
                            "0" -> {
                                mBinding.imgvGender.visibility = View.VISIBLE
                                mBinding.imgvGender.setImageResource(R.mipmap.ic_61)
                            }
                            "10" -> {
                                mBinding.imgvGender.visibility = View.VISIBLE
                                mBinding.imgvGender.setImageResource(R.mipmap.ic_18)
                            }
                            else -> {
                                mBinding.imgvGender.visibility = View.GONE
                            }
                        }

                        if (map_user["is_creator"]=="1"){
                            mBinding.imgvCreator.visibility = View.VISIBLE
                        }else{
                            mBinding.imgvCreator.visibility = View.GONE
                        }

                        if (map["is_add_fans_group"]=="1"){
                            imgvQuit.text = "退团"
                            imgvQuit.setTextColor(resources.getColor(R.color.c_16))
                            imgvQuit.setBackgroundResource(R.drawable.shape_59)
                        }else{
                            imgvQuit.setTextColor(resources.getColor(R.color.c_2))
                            imgvQuit.setBackgroundResource(R.drawable.shape_65)
                            imgvQuit.text = "加团"
                        }

                        itemView.setOnClickListener {
                            var bundle = Bundle()
                            bundle.putString("user_id",map_user["code"])
                            bundle.putString("is_join_group",map["is_add_fans_group"])
                            bundle.putString("user_name",map_user["nick"])
                            startActivity(FansGroupDetailsAty::class.java,bundle)

                        }
                    }
                }


            }

        }

        inner class fGoldViewHolder(binding: ItemFansGroupMyJoinBinding) :
            RecyclerView.ViewHolder(binding.root) {
            var mBinding: ItemFansGroupMyJoinBinding = binding

            init {
                AutoUtils.autoSize(binding.root)

            }
        }

    }


}
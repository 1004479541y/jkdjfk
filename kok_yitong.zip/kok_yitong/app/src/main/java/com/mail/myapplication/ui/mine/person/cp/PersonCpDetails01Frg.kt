package com.mail.myapplication.ui.mine.person.cp

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.mail.comm.image.ImageLoader
import com.mail.comm.net.AESCBCCrypt
import com.mail.comm.utils.JSONUtils
import com.mail.comm.view.load.XLoadTip
import com.mail.comm.view.refresh.XRefreshInterface
import com.mail.myapplication.BaseXFrg
import com.mail.myapplication.databinding.FrgPersonCpDetails01Binding
import com.mail.myapplication.databinding.ItemPersonCpDetails01Binding
import com.mail.myapplication.interfaces.Home
import com.yhz.adaptivelayout.utils.AutoUtils

class PersonCpDetails01Frg: BaseXFrg() {

    var home = Home()
    lateinit var mBinding: FrgPersonCpDetails01Binding
    var list = ArrayList<MutableMap<String, String>>()
    var mAdapter: GoldRecyclerAdapter? = null
    var room_id =""
    var page = 1

    override fun getLayoutId() =0

    override fun initView() {
        room_id = arguments?.getString("room_id").toString()
    }

    companion object {

        fun create(room_id: String): PersonCpDetails01Frg {
            val fragment = PersonCpDetails01Frg()
            val bundle = Bundle()
            bundle.putString("room_id", room_id)
            fragment.arguments = bundle
            return fragment
        }
    }

    override fun getLayoutView(): View {
        mBinding = FrgPersonCpDetails01Binding.inflate(layoutInflater);
        return mBinding.root
    }

    override fun requestData() {
        page = 1
        mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.loading)
        home.a80(page,room_id,this)
    }

    fun requestData2() {
        home.a80(page,room_id,this)
    }

    override fun onComplete(var2: String?, type: String?) {
        super.onComplete(var2, type)
        if (type== "gift/list"){

            mBinding.swipeRefreshLayout.finishRefreshing()
            mBinding.swipeRefreshLayout.finishLoadmore()
            mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.finish)
            var map = JSONUtils.parseKeyAndValueToMap(var2)
            if(map["code"]=="200"){
                var str = AESCBCCrypt.aesDecrypt(map["data"])
                var mList = JSONUtils.parseKeyAndValueToMapList(str)
                if (page == 1){
                    list.clear()
                    list.addAll(mList)

                }else{
                    list.addAll(mList)
                }

                if (page==1&&mList.size==0){

                    mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.empty)
                }else{
                    mAdapter?.notifyDataSetChanged()
                }
            }else{
                if (page==1){
                    mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.error)
                }
            }
        }
    }

    override fun onExceptionType(type: String?) {
        super.onExceptionType(type)
        if (type== "gift/list"){
            mBinding.swipeRefreshLayout.finishRefreshing()
            mBinding.swipeRefreshLayout.finishLoadmore()
            if (page==1&&list.size==0){
                mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.error)
            }else{
                mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.finish)
            }
        }
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)

        var mLayoutManager = GridLayoutManager(requireContext(), 1)
        mLayoutManager.orientation = RecyclerView.VERTICAL
        mBinding.recyclerview.layoutManager = mLayoutManager
        mAdapter = GoldRecyclerAdapter()
        mBinding.recyclerview.adapter = mAdapter

        mBinding.loading.setLoadingTipXReloadCallback(object : XLoadTip.LoadingTipXReloadCallback {
            override fun reload() {
                requestData()
            }
        })

        mBinding.swipeRefreshLayout.setEnableLoadmore(true)
        mBinding.swipeRefreshLayout.setEnableRefresh(true)
        mBinding.swipeRefreshLayout.setXRefreshAndLoadListen(object : XRefreshInterface {
            override fun refreshStart() {
                page =1
                requestData2()
            }

            override fun loadMoreStart() {
                page++
                requestData2()
            }

        })
    }


    inner class GoldRecyclerAdapter : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
            return fGoldViewHolder(ItemPersonCpDetails01Binding.inflate(LayoutInflater.from(context)))
        }

        override fun getItemCount(): Int =list.size

        override fun getItemViewType(position: Int): Int {
            return position
        }

        override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {

            if (holder is fGoldViewHolder) {

                with(holder) {
                    with(mBinding) {

                        var maxW = AutoUtils.getPercentWidthSizeBigger(400)
                        ImageLoader.loadImageAes(requireActivity(), list[position]["avatar"], mBinding.ivHead,maxW,maxW)
                        ImageLoader.loadImageAes(requireActivity(), list[position]["gift_cover"], mBinding.imgv01,maxW,maxW)

                        tvName.text = list[position]["nick"]
                        tvTime.text = list[position]["created_at"]
                        tvNum.text = list[position]["gift_title"]+"x1"

                    }
                }

            }

        }

        inner class fGoldViewHolder(binding: ItemPersonCpDetails01Binding) :
            RecyclerView.ViewHolder(binding.root) {
            var mBinding: ItemPersonCpDetails01Binding = binding

            init {
                AutoUtils.autoSize(binding.root)

            }
        }

    }

}
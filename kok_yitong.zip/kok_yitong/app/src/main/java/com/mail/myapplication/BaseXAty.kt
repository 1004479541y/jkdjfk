package com.mail.myapplication

import android.annotation.SuppressLint
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.graphics.Color
import android.os.Bundle
import android.os.IBinder
import android.text.TextUtils
import android.widget.ImageView
import android.widget.RelativeLayout
import android.widget.TextView
import com.mail.comm.app.AppConfig
import com.mail.comm.app.BaseApp
import com.mail.comm.base.BaseAty
import com.mail.comm.utils.JSONUtils
import com.mail.comm.utils.PreferencesUtils
import com.mail.myapplication.interfaces.Home
import com.mail.myapplication.ui.MainWalletAty
import com.mail.myapplication.ui.app.MyApp
import com.mail.myapplication.ui.app.RtmManager
import com.mail.myapplication.ui.dg.CommonDialog
import com.mail.myapplication.ui.mine.daresquare.DarenSquareAty
import com.mail.myapplication.ui.mine.fans.FansGroupDetailsAty
import com.mail.myapplication.ui.websocket.SocketService
import com.yhz.adaptivelayout.utils.AutoUtils
import io.agora.rtm.*

abstract  class BaseXAty :BaseAty(), RtmClientListener {

    var mRtmClient: RtmClient? = null
    var mChatManager: RtmManager? = null
    var isBind = false
    var socketService: SocketService? = null
    var mBaseCommonDialog: CommonDialog?=null
    var info_vip_level =""
    var home_baee:Home?=null

    fun requestAdCount(id:String){
        if (home_baee == null){
            home_baee = Home()
        }
        home_baee?.a64(id,this)
    }

    fun initTopview2(relay: RelativeLayout?, bgColor: String = "#ffffff") {
        val lp = relay?.layoutParams as RelativeLayout.LayoutParams
        lp.height = AutoUtils.getPercentHeightSize(150)
        relay.layoutParams = lp
      var imgv_back =relay.findViewById<ImageView>(R.id.imgv_back)
      var tv_title =relay.findViewById<TextView>(R.id.tv_title)
      if (AppConfig.model == "wanou"){
          imgv_back.setImageResource(R.mipmap.ic_wo_3)
          tv_title.setTextColor(Color.parseColor("#ffffff"))
      }
        relay.setBackgroundColor(Color.parseColor(bgColor))
    }

    fun initTopview3(relay: RelativeLayout?, bgColor: String, tvTitleColor:String,tvRightColor:String,imgv_back_r:Int) {
        val lp = relay?.layoutParams as RelativeLayout.LayoutParams
        lp.height = AutoUtils.getPercentHeightSize(150)
        relay.layoutParams = lp
        var imgv_back = relay.findViewById<ImageView>(R.id.imgv_back)
        var tv_title = relay.findViewById<TextView>(R.id.tv_title)
        var tv_right = relay.findViewById<TextView>(R.id.tv_right)

        if (imgv_back_r!=0){
            imgv_back.setImageResource(imgv_back_r)
        }
        if (!TextUtils.isEmpty(tvTitleColor)){
            tv_title.setTextColor(Color.parseColor(tvTitleColor))
        }
        if (!TextUtils.isEmpty(tvRightColor)){
            tv_right.setTextColor(Color.parseColor(tvRightColor))
        }
        if (!TextUtils.isEmpty(bgColor)){
            relay.setBackgroundColor(Color.parseColor(bgColor))
        }
    }

    fun initIm(isRegister:Boolean = true){
        var myApp = application  as MyApp
        mChatManager = myApp.getChatManager()
        mChatManager?.enableOfflineMessage(true)
        mChatManager?.enableHistoricalMessage(true)
        mRtmClient = mChatManager?.rtmClient
        if (isRegister){
            mChatManager?.registerListener(this)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        info_vip_level = BaseApp.instance?.getOneMapData("info_vip_level").toString()
    }

    override fun onDestroy() {
        super.onDestroy()
        mBaseCommonDialog?.dismiss()
        (application  as MyApp).getChatManager().unregisterListener(this)
    }

    fun setLoginStatus(isLogin:Boolean){
        PreferencesUtils.putBoolean(this,"isLogin",isLogin)
    }

    fun isLogin():Boolean{
         var isLogin =PreferencesUtils.getBoolean(this,"isLogin",false)
         return isLogin
    }

    fun isPattern():Boolean{
        var isPattern =PreferencesUtils.getBoolean(this,"isPattern",false)
        return isPattern
    }

    fun setPattern(isPattern:Boolean){
        var isPattern =PreferencesUtils.putBoolean(this,"isPattern",isPattern)
    }

    fun exitLogin(){
         setLoginStatus(false)
    }

//    fun createChannel( channelName:String?, token:String){
//        var mRtcEngine: RtcEngine
//        var rtcChannel: RtcChannel
//        RtcEngine.destroy()
//        var appId = PreferencesUtils.getString(mContext, "rtm_app_id")
//
//        try {
//            mRtcEngine = RtcEngine.create(baseContext, appId, object : IRtcEngineEventHandler() {
//
//            })
//
//        } catch (e: Exception) {
//            throw RuntimeException("NEED TO check rtc sdk init fatal error ${Log.getStackTraceString(e)}")
//        }
////        mRtcEngine!!.setChannelProfile(Constants.CHANNEL_PROFILE_COMMUNICATION)
//        mRtcEngine!!.setChannelProfile(Constants.CHANNEL_PROFILE_COMMUNICATION)
////        mRtcEngine!!.joinChannel(token, channelName, "Extra Optional Data", optionalUid)
//        rtcChannel = mRtcEngine!!.createRtcChannel(channelName)
//        var channelMediaOptions = ChannelMediaOptions()
//        channelMediaOptions.autoSubscribeAudio = false
//        channelMediaOptions.autoSubscribeVideo = false
//        channelMediaOptions.publishLocalAudio = false
//        channelMediaOptions.publishLocalVideo = false
//        rtcChannel?.joinChannel(token,"Extra Optional Data", 0,channelMediaOptions)
//        rtcChannel?.setRtcChannelEventHandler(object : IRtcChannelEventHandler(){
//
//        })
//    }

    override fun onConnectionStateChanged(p0: Int, p1: Int) {
    }

    override fun onMessageReceived(p0: RtmMessage?, p1: String?) {
    }

    override fun onImageMessageReceivedFromPeer(p0: RtmImageMessage?, p1: String?) {
    }

    override fun onFileMessageReceivedFromPeer(p0: RtmFileMessage?, p1: String?) {
    }

    override fun onMediaUploadingProgress(p0: RtmMediaOperationProgress?, p1: Long) {
    }

    override fun onMediaDownloadingProgress(p0: RtmMediaOperationProgress?, p1: Long) {
    }

    override fun onTokenExpired() {
    }

    override fun onPeersOnlineStatusChanged(p0: MutableMap<String, Int>?) {
    }

    @SuppressLint("MissingSuperCall")
    override fun onResume() {
        super.onResume()
    }

     fun startService() {
        val intent = Intent(this, SocketService::class.java)
        isBind = bindService(intent, conn, Context.BIND_AUTO_CREATE)
        startService(intent)
    }

    private var conn: ServiceConnection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName, service: IBinder) {
            socketService = (service as SocketService.StepBinder).getService()
        }
        override fun onServiceDisconnected(name: ComponentName) {}
    }

    override fun onComplete(var2: String?, type: String?) {
        super.onComplete(var2, type)

        var map = JSONUtils.parseKeyAndValueToMap(var2)

        if (type == "ping") {
            return
        }

        if (!map.containsKey("code")){
            return
        }

        when(map["code"]){

            //不是创作者
            "1005"->{
                showCommonDialog("1005",true,map["message"],"取消","去开通")
            }

            //发帖次数已用完
            "1006"->{
                showCommonDialog("1006",true,map["message"],"取消","去开通")
            }
        }
    }

    fun showCommonDialog(type:String,isCanceled:Boolean,info:String?,str_01:String,str_02: String,mBaseCommonDialogListen:BaseCommonDialogListen?=null){

        //1005 不是创作者  1006 开通vip 1007创建私密團    1008聊天鉴权 未关注TA

        if(mBaseCommonDialog == null){
            mBaseCommonDialog = CommonDialog(this)
        }

        when(type){
            "1005"->{
                mBaseCommonDialog?.setCommonDialogListen(object : CommonDialog.CommonDialogListen{
                    override fun onclik01() {
                        mBaseCommonDialog?.dismiss()
                    }
                    override fun onclik02() {
                        mBaseCommonDialog?.dismiss()
                        startActivity(DarenSquareAty::class.java)
                    }
                })
            }
            "1006"->{
                mBaseCommonDialog?.setCommonDialogListen(object : CommonDialog.CommonDialogListen{
                    override fun onclik01() {
                        mBaseCommonDialog?.dismiss()
                    }
                    override fun onclik02() {
                        mBaseCommonDialog?.dismiss()

                        var bundle = Bundle()
                        bundle.putString("page_type","pay")
                        startActivity(MainWalletAty::class.java,bundle)
                    }
                })
            }
            "1007"->{
                mBaseCommonDialog?.setCommonDialogListen(object : CommonDialog.CommonDialogListen{
                    override fun onclik01() {
                        mBaseCommonDialog?.dismiss()
                    }
                    override fun onclik02() {
                        var info_code = BaseApp.instance?.getOneMapData("info_code")
                        var info_nick = BaseApp.instance?.getOneMapData("info_nick")
                        var bundle = Bundle()
                        bundle.putString("user_id",info_code)
                        bundle.putString("user_name",info_nick)
                        bundle.putString("type","no_create")
                        startActivity(FansGroupDetailsAty::class.java,bundle)
                        mBaseCommonDialog?.dismiss()
                    }
                })
            }
            "1008"->{
                mBaseCommonDialog?.setCommonDialogListen(object : CommonDialog.CommonDialogListen{
                    override fun onclik01() {
                        mBaseCommonDialog?.dismiss()
                    }
                    override fun onclik02() {
                        mBaseCommonDialogListen?.onclick02()
                        mBaseCommonDialog?.dismiss()
                    }
                })
            }
            "1009"->{
                mBaseCommonDialog?.setCommonDialogListen(object : CommonDialog.CommonDialogListen{
                    override fun onclik01() {
                    }
                    override fun onclik02() {
                        mBaseCommonDialog?.dismiss()
                        finish()
                    }
                })
            }

            "1010" ->{
                mBaseCommonDialog?.setCommonDialogListen(object : CommonDialog.CommonDialogListen{
                    override fun onclik01() {
                        mBaseCommonDialog?.dismiss()
                    }
                    override fun onclik02() {
                        mBaseCommonDialogListen?.onclick02()
                        mBaseCommonDialog?.dismiss()
                    }
                })
            }

            "1011" ->{
                mBaseCommonDialog?.setCommonDialogListen(object : CommonDialog.CommonDialogListen{
                    override fun onclik01() {
                        mBaseCommonDialogListen?.onclick01()
                        mBaseCommonDialog?.dismiss()
                    }
                    override fun onclik02() {
                        mBaseCommonDialogListen?.onclick02()
                        mBaseCommonDialog?.dismiss()
                    }
                })
            }

            "1012" ->{
                mBaseCommonDialog?.setCommonDialogListen(object : CommonDialog.CommonDialogListen{
                    override fun onclik01() {
                        mBaseCommonDialog?.dismiss()
                    }
                    override fun onclik02() {
                        mBaseCommonDialog?.dismiss()
                    }
                })
            }
        }

        mBaseCommonDialog?.show()
        mBaseCommonDialog?.setCancelViewVisibility(isCanceled)
        mBaseCommonDialog?.setCommCanceled(isCanceled)
        mBaseCommonDialog?.setData(info.toString(),str_01,str_02)
    }

    interface  BaseCommonDialogListen{
        fun  onclick01()
        fun  onclick02()
    }

}
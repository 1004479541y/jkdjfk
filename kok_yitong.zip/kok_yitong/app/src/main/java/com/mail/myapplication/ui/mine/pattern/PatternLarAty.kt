package com.mail.myapplication.ui.mine.pattern

import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.RelativeLayout
import com.andrognito.patternlockview.PatternLockView
import com.andrognito.patternlockview.PatternLockView.Dot
import com.andrognito.patternlockview.listener.PatternLockViewListener
import com.andrognito.patternlockview.utils.PatternLockUtils
import com.mail.comm.utils.MyUtils
import com.mail.comm.utils.MyUtils2
import com.mail.comm.utils.PreferencesUtils
import com.mail.myapplication.BaseXAty
import com.mail.myapplication.R
import com.mail.myapplication.databinding.AtyPatternLarBinding
import com.mail.myapplication.ui.SplashAty
import com.yhz.adaptivelayout.utils.AutoUtils

class PatternLarAty:BaseXAty() {

    lateinit var mBinding: AtyPatternLarBinding

    var pass = ""
    override fun getLayoutId(): Int = 0

    override fun getLayoutView(): View {
        mBinding = AtyPatternLarBinding.inflate(layoutInflater)
        return mBinding.root
    }

    override fun initView() {
        pass =PreferencesUtils.getString(this,"pattern_pass")
    }


    override fun onResume() {
        super.onResume()
        pass =PreferencesUtils.getString(this,"pattern_pass")

    }
    override fun requestData() {
    }

    fun mainClick(v: View) {
        when (v.id) {
            R.id.relay_back -> {
                finish()
            }
            R.id.tv_forget -> {

                startActivity(PatterPhoneAty::class.java)
            }
        }
    }

    fun initLayout() {
        var params = mBinding.relayBack.layoutParams as RelativeLayout.LayoutParams
        var StatusBarHeight = MyUtils2.getStateBar(this@PatternLarAty)
        if (StatusBarHeight <= 0) {
            StatusBarHeight = MyUtils2.dip2px(this@PatternLarAty, 20F)
        }
        params.topMargin = StatusBarHeight+AutoUtils.getPercentHeightSizeBigger(50)
        mBinding.relayBack.layoutParams = params
    }

    private val mPatternLockViewListener: PatternLockViewListener =
        object : PatternLockViewListener {

            override fun onStarted() {
                Log.d(javaClass.name, "Pattern drawing started")
            }

            override fun onProgress(progressPattern: List<Dot>) {
                Log.d(javaClass.name, "Pattern progress: " + MyUtils.patternToString(mBinding.patterLockView, progressPattern))
            }

            override fun onComplete(pattern: List<Dot>) {
                Log.d(javaClass.name, "Pattern complete: " + MyUtils.patternToString(mBinding.patterLockView, pattern))

                var pass2 =  MyUtils.patternToString(mBinding.patterLockView, pattern)

//                showToastS(pass2)
                if (pass2!=pass){
                    showToastS("密码错误")
                    mBinding.patterLockView.clearPattern()
                }else{
                    var bundle = Bundle()
                    bundle.putString("isPattern_login","1")
                    startActivity(SplashAty::class.java,bundle)
                    finish()
                }
            }

            override fun onCleared() {
                Log.d(javaClass.name, "Pattern has been cleared")
            }

        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setTranslanteBar()
//        initTopview2(mBinding.include.relayTopBg,"#00000000")
//        window.navigationBarColor = Color.parseColor("#00010D13")
//        mBinding.include.tvTitle.text = ""
        initLayout()
        with(mBinding) {

            patterLockView.setAspectRatioEnabled(true)
            patterLockView.setAspectRatio(PatternLockView.AspectRatio.ASPECT_RATIO_HEIGHT_BIAS)
            patterLockView.setViewMode(PatternLockView.PatternViewMode.CORRECT)
            patterLockView.setDotAnimationDuration(150)
            patterLockView.setPathEndAnimationDuration(100)
            patterLockView.setInStealthMode(false)
            patterLockView.setTactileFeedbackEnabled(true)
            patterLockView.setInputEnabled(true)
            patterLockView.addPatternLockListener(mPatternLockViewListener)

//            RxPatternLockView.patternComplete(patterLockView)
//                .subscribe(object : Consumer<PatternLockCompleteEvent> {
//                    @Throws(Exception::class)
//                    override fun accept(patternLockCompleteEvent: PatternLockCompleteEvent) {
//                        Log.d(
//                            javaClass.name,
//                            "Complete: " + patternLockCompleteEvent.pattern.toString()
//                        )
//                    }
//                })
//
//            RxPatternLockView.patternChanges(patterLockView)
//                .subscribe(object : Consumer<PatternLockCompoundEvent> {
//                    @Throws(Exception::class)
//                    override fun accept(event: PatternLockCompoundEvent) {
//                        if (event.eventType == PatternLockCompoundEvent.EventType.PATTERN_STARTED) {
//                            Log.d(javaClass.name, "Pattern drawing started")
//                        } else if (event.eventType == PatternLockCompoundEvent.EventType.PATTERN_PROGRESS) {
//                            Log.d(javaClass.name, "Pattern progress: " + PatternLockUtils.patternToString(patterLockView, event.pattern))
//                        } else if (event.eventType == PatternLockCompoundEvent.EventType.PATTERN_COMPLETE) {
//                            Log.d(
//                                javaClass.name, "Pattern complete: " +
//                                        PatternLockUtils.patternToString(
//                                            patterLockView,
//                                            event.pattern
//                                        )
//                            )
//                        } else if (event.eventType == PatternLockCompoundEvent.EventType.PATTERN_CLEARED) {
//                            Log.d(javaClass.name, "Pattern has been cleared")
//                        }
//                    }
//                })
        }


    }
}
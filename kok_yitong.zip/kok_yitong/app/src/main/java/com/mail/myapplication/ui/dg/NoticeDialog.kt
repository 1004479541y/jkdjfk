package com.mail.myapplication.ui.dg

import android.app.Dialog
import android.os.Bundle
import android.view.Gravity
import com.mail.comm.base.BaseAty
import com.mail.myapplication.R
import com.mail.myapplication.databinding.DlgNoticeBinding


class NoticeDialog(context: BaseAty) : Dialog(context) {

    var baseAty = context
    lateinit var mBinding: DlgNoticeBinding
    var info = ""
    var mNoticeDialogListen:NoticeDialogListen?=null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        mBinding = DlgNoticeBinding.inflate(layoutInflater);
        setContentView(mBinding.root)
//      setContentView(R.layout.dg_recharge)
        window?.setWindowAnimations(R.style.dialogFullscreen2)
        window!!.setBackgroundDrawable(null)
        window!!.setGravity(Gravity.CENTER)
        setCanceledOnTouchOutside(false)
        setCancelable(false)
        val m = baseAty.windowManager
        val d = m.defaultDisplay// 获取屏幕宽、高
        val p = window!!.attributes
        window?.getDecorView()?.setPadding(0, 0, 0, 0)
//      p.height =  (d.height * 1) // 高度设置为屏幕的0.6
        p.width = (d.width * 1) // 宽度设置为屏幕的0.85
        window!!.attributes = p

        mBinding.imgvCancel.setOnClickListener {
            mNoticeDialogListen?.cancel()
            dismiss()
        }

        mBinding.tv02.setOnClickListener {
            mNoticeDialogListen?.cancel()
            dismiss()
        }

    //2441436550 1426210756 2052489457

    }

    fun setData(info: String) {

        if (isShowing){
            mBinding.tvContent.text = info
        }
    }

    interface NoticeDialogListen {
        fun cancel()
    }

    fun setNoticeDialogListen(mNoticeDialogListen:NoticeDialogListen){
        this.mNoticeDialogListen = mNoticeDialogListen
    }


}
package com.mail.myapplication.ui.find

import android.annotation.SuppressLint
import android.os.Bundle
import android.text.TextUtils
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.lifecycle.lifecycleScope
import com.mail.comm.app.BaseApp
import com.mail.comm.image.ImageLoader
import com.mail.comm.net.AESCBCCrypt
import com.mail.comm.utils.JSONUtils
import com.mail.comm.utils.PreferencesUtils
import com.mail.comm.utils.TimeUtils
import com.mail.myapplication.BaseXAty
import com.mail.myapplication.ui.app.MyApp
import com.mail.myapplication.R
import com.mail.myapplication.databinding.AtyMatchVoiceBinding
import com.mail.myapplication.interfaces.Home
import com.mail.myapplication.ui.MainWalletAty
import com.mail.myapplication.ui.dg.AttenDialog
import com.mail.myapplication.ui.dg.CommonDialog
import com.mail.myapplication.ui.dg.gift.GiftDialog
import com.mail.myapplication.ui.dg.VoiceRenewDialog
import com.mail.myapplication.ui.mine.person.cp.PersonCpAty
import com.mail.myapplication.ui.msg.chat.ChatReportAty
import com.mail.myapplication.ui.utils.SvgaUtils
import com.mail.myapplication.ui.msg.database.ChatUtils
import com.mail.myapplication.ui.utils.MyUtils3
import com.opensource.svgaplayer.SVGACallback
import com.yhz.adaptivelayout.utils.AutoUtils
import io.agora.rtc.*
import io.agora.rtc.models.ChannelMediaOptions
import io.agora.rtm.ErrorInfo
import io.agora.rtm.ResultCallback
import io.agora.rtm.RtmMessage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.xutils.common.util.LogUtil
import org.xutils.x
import java.util.*

class MatchVoiceAty:BaseXAty() {

    lateinit var mBinding: AtyMatchVoiceBinding
    var appId = ""
    var token = ""
    var channelName = "001"
    var optionalUid = 0
    var enable_speker = true
    var enable_voice = false
    var time_end:Double?=null
    var mRtcEngine: RtcEngine? = null
    var rtcChannel: RtcChannel? = null
    var isJoin = false

    var json = ""
    var user_type = "" //to from
    var home = Home()

    var to_user_code = ""
    var to_avatar = ""
    var to_nick = ""
    var to_year= ""
    var user_code = ""
    var avatar = ""
    var nick_my = ""

    var cp_value = 0
    var min_cp_value = 0
    var min_unfollow_coins = ""
    var is_follow = ""
    var nick_to=""
    var years_my=""
    var start_time_join = 0L

    var svgUtils: SvgaUtils?=null
    var giftDialog: GiftDialog?=null
    var mAttenDialog: AttenDialog?=null
    var mCommonDialog: CommonDialog?=null
    var mMatchVoiceCpDg:MatchVoiceCpDg?=null
    var mVoiceRenewDialog: VoiceRenewDialog?=null
    var mMatchVoiceLockDg:MatchVoiceLockDg? = null
    var mMatchVoiceCpRuleDg:MatchVoiceCpRuleDg?=null
    var map_json:MutableMap<String,String>?=null

    var cp_rule_content = ""
    var cp_detail_content = ""

    var timerT: Timer? = null
    var timerTaskT: TimerTask? = null

    override fun getLayoutId(): Int =0

    override fun initView() {
        appId = PreferencesUtils.getString(mContext, "rtm_app_id")
        channelName = intent.getStringExtra("match_id").toString()
        json = intent.getStringExtra("json").toString()
        user_type = intent.getStringExtra("user_type").toString()
        map_json =JSONUtils.parseKeyAndValueToMap(json)

        cp_rule_content = map_json!!["cp_rule_content"].toString()

        cp_detail_content = map_json!!["cp_detail_content"].toString()

        user_code = BaseApp.instance?.getOneMapData("info_code").toString()
        avatar = BaseApp.instance?.getOneMapData("info_avatar").toString()
        nick_my = BaseApp.instance?.getOneMapData("info_nick").toString()
        years_my = BaseApp.instance?.getOneMapData("info_years").toString()

        initViewLayout()

        BaseApp.instance?.saveOneMapData("is_chat","1")

        svgUtils = SvgaUtils()
        svgUtils?.loopAnimation(this,mBinding.mSVGAKninghtood2)
        mBinding.mSVGAKninghtood2.loops =1
        mBinding.mSVGAKninghtood2!!.callback = object : SVGACallback {

            override fun onPause() {
                //动画暂停黄瓜.svga
            }

            override fun onFinished() {
                LogUtil.e("lifecycleScope5 ====")
                svgUtils?.setIsPlay(false)
                //动画结束
            }

            override fun onRepeat() {
                //重复播放
                LogUtil.e("lifecycleScope6 ====")
            }

            override fun onStep(i: Int, v: Double) {
                //动画步骤
//           LogUtil.e("lifecycleScope7 ====")

            }


        }

        svgUtils?.setSvgUtilsListen(object : SvgaUtils.SvgUtilsListen{

            override fun receiveGift(msg: String?) {

                lifecycleScope.launch {
                    withContext(Dispatchers.Main) {
                        mBinding.relayGift.visibility = View.VISIBLE
                        var map_msg = JSONUtils.parseKeyAndValueToMap(msg)
                        var maxW_head = AutoUtils.getPercentWidthSizeBigger(400)
                        ImageLoader.loadImageAes(this@MatchVoiceAty, map_msg["cover"], mBinding.imgvGift, maxW_head, maxW_head)
                        mBinding.tvNickGift.text = nick_to
                    }
                }

            }
        })
    }

    fun initViewLayout(){
        cp_value = map_json!!["cp_value"]!!.toInt()
        min_cp_value = map_json!!["min_cp_value"]!!.toInt()
        min_unfollow_coins = map_json!!["min_unfollow_coins"].toString()

        mBinding.tvQmd.text = "亲密度：${cp_value}"

        var map_from_user = JSONUtils.parseKeyAndValueToMap(map_json!!["from_user"])
        var map_to_user = JSONUtils.parseKeyAndValueToMap(map_json!!["to_user"])

        if (user_type == "from"){
            to_user_code = map_to_user["user_code"]!!
            to_avatar = map_to_user["avatar"]!!
            to_nick = map_to_user["nick"]!!
            to_year = map_to_user["years"]!!

        }else{
            to_user_code = map_from_user["user_code"]!!
            to_avatar = map_from_user["avatar"]!!
            to_nick = map_from_user["nick"]!!
            to_year = map_from_user["years"]!!
        }

        var head_url = ""
        var nick = ""
        var intro =""
        var habit =""
        var gender =""
        var job =""
        var city =""
        var years =""

        if (user_type != "from"){
            head_url = map_from_user["avatar"]!!
            nick = map_from_user["nick"]!!
            intro = map_from_user["intro"]!!
            habit = map_from_user["habit"]!!
            gender = map_from_user["gender"]!!
            job = map_from_user["job"]!!
            city = map_from_user["city"]!!
            years = map_from_user["years"]!!
            nick_to = map_from_user["nick"]!!
//            is_follow = map_from_user["is_follow"]!!

        }else{
            head_url = map_to_user["avatar"]!!
            nick = map_to_user["nick"]!!
            intro = map_to_user["intro"]!!
            habit = map_to_user["habit"]!!
            gender = map_to_user["gender"]!!
            job = map_to_user["job"]!!
            city = map_to_user["city"]!!
            years = map_to_user["years"]!!
            nick_to = map_to_user["nick"]!!
//          is_follow = map_to_user["is_follow"]!!
        }

        if (is_follow != "1"){
            if (user_type == "from"){
                is_follow = map_from_user["is_follow"]!!
            }else{
                is_follow = map_to_user["is_follow"]!!
            }
        }

        if (TextUtils.isEmpty(intro)){
            intro ="对方比较懒,没有设置个性签名"
        }

        var maxW_head = AutoUtils.getPercentWidthSizeBigger(400)

        if (is_follow == "0") {

            MyUtils3.setTextMaskFilterSpan(mBinding.tvSex, gender, 0)
            MyUtils3.setTextMaskFilterSpan(mBinding.tvJob, job, 0)
            MyUtils3.setTextMaskFilterSpan(mBinding.tvCity, city, 0)
            MyUtils3.setTextMaskFilterSpan(mBinding.tvLike, habit.replace(",", " "), 0)
            MyUtils3.setTextMaskFilterSpan(mBinding.tvSign, intro, 0)
            mBinding.imgvLock.visibility = View.VISIBLE

        } else {
            mBinding.tvSex.text = gender
            mBinding.tvJob.text = job
            mBinding.tvCity.text = city
            mBinding.tvLike.text = habit.replace(",", " ")
            mBinding.tvSign.text = intro
            mBinding.imgvLock.visibility = View.GONE
            ImageLoader.loadImageAes(this,head_url,mBinding.imgvHead,maxW_head,maxW_head)
            ImageLoader.loadImageAes(this,head_url,mBinding.ivHead,maxW_head,maxW_head)
            mBinding.tvNickGift.text = nick
            mBinding.tvNickTo.text = nick
//            mBinding.tvDesTo.visibility = View.GONE
            mBinding.tvYearTo.text = years+"岁"
        }

        ImageLoader.loadImageAes(this,avatar,mBinding.ivHeadMy,maxW_head,maxW_head)
        mBinding.tvNickMy.text = nick_my
        mBinding.tvYearMy.text = years_my+"岁"

    }

    override fun getLayoutView(): View {
        mBinding = AtyMatchVoiceBinding.inflate(layoutInflater);
        return mBinding.root
    }

    override fun requestData() {}

    fun startLoop(){
        var voice_time =map_json!!["voice_time"]!!.toInt()
//        voice_time = 10
        if (time_end==null){
            var c_time =TimeUtils.getBeijinTime().toDouble()
            LogUtil.e("startLoop"+TimeUtils.getBeijinTime())
            time_end = c_time +1000*voice_time
        }
        startTime()
    }

    @SuppressLint("MissingSuperCall")
    override fun onResume() {
        super.onResume()
        if (isJoin){
            startLoop()
        }
    }

    override fun onPause() {
        super.onPause()
//        cancelTimerT()
    }

    override fun onComplete(var2: String?, type: String?) {
        super.onComplete(var2, type)

        if (type == "unlock/follow"){
            stopProgressDialog()
            var map = JSONUtils.parseKeyAndValueToMap(var2)
            if (map["code"] == "200") {
//                finish()
                is_follow = "1"
                initViewLayout()
            }else{
                showToastS(map["message"])
//                Toast.makeText(this,map["message"], Toast.LENGTH_SHORT).show()
            }
        }


        if (type == "match/cancel"){
            var map = JSONUtils.parseKeyAndValueToMap(var2)
            if (map["code"] == "200") {
                var bundle = Bundle()
                bundle.putString("to_avatar",to_avatar)
                bundle.putString("to_nick",to_nick)
                bundle.putString("is_follow",is_follow)
                bundle.putString("start_time_join",start_time_join.toString())
                bundle.putString("to_year",to_year)
                bundle.putString("to_user_code",to_user_code)
                bundle.putString("min_unfollow_coins",min_unfollow_coins)
                startActivity(MatchVoiceFinishAty::class.java,bundle)
                finish()
            }else{
                finish()
                Toast.makeText(this,map["message"], Toast.LENGTH_SHORT).show()
            }
        }

        if (type == "message/create/gift"){
            stopProgressDialog()
            var map = JSONUtils.parseKeyAndValueToMap(var2)
            if (map["code"] == "200") {
                showToastS(map["message"])
                sendPeerMessage(message_gift!!)
            }else{
                showToastS(map["message"])
            }
        }

        if (type == "buy/time"){
            stopProgressDialog()
            var map = JSONUtils.parseKeyAndValueToMap(var2)
            if (map["code"] == "200") {

                var str = AESCBCCrypt.aesDecrypt(map["data"])
                var map_data = JSONUtils.parseKeyAndValueToMap(str)

//                var time =TimeUtils.getTime(map_data["end_at"]!!).toDouble()
                var time =map_data["end_at"]!!.toDouble()*1000

                if (time<time_end!!){
                    return
                }

                time_end = time
                startLoop()

            }else{
                showToastS(map["message"])
            }
        }
    }

    override fun onExceptionType(type: String?) {
        super.onExceptionType(type)
        stopProgressDialog()
        if (type == "match/cancel"){
            finish()
        }
    }

    fun sendPeerMessage(message: RtmMessage) {
        mRtmClient?.sendMessageToPeer(to_user_code, message, mChatManager?.getSendMessageOptions(),
            object : ResultCallback<Void?> {
                override fun onSuccess(aVoid: Void?) {
                    ChatUtils.saveChatpannel(message.text)
                }

                override fun onFailure(p0: ErrorInfo?) {
                }
            })
    }


    fun mainClick(v: View) {
        when (v.id) {

            R.id.imgv_lock ->{

                if (mAttenDialog == null){
                    mAttenDialog = AttenDialog(this)
                }
                mAttenDialog?.setAttenDialogListen(object : AttenDialog.AttenDialogListen{
                    override fun onclik01() {
                    }

                    override fun onclik02() {
                        startProgressDialog()
                        home.a93(min_unfollow_coins,to_user_code,this@MatchVoiceAty)
                    }
                })
                mAttenDialog?.show()
                mAttenDialog?.requestData(min_unfollow_coins)


            }

            R.id.linlay_report ->{
                var bundle = Bundle()
                bundle.putString("to_user_code",to_user_code)
                startActivity(ChatReportAty::class.java,bundle)
            }

            R.id.relay_cp,R.id.tv_qmd ->{

                if (cp_value>=min_cp_value){
                    var bundle = Bundle()
                    bundle.putString("user_code",to_user_code)
                    startActivity(PersonCpAty::class.java,bundle)
                    return
                }

                if(mMatchVoiceCpDg == null){
                    mMatchVoiceCpDg = MatchVoiceCpDg(this)
                }

                mMatchVoiceCpDg?.setMatchVoiceCpDgListen(object :
                    MatchVoiceCpDg.MatchVoiceCpDgListen{
                    override fun onclik01() {
                        if (mMatchVoiceCpRuleDg == null){
                            mMatchVoiceCpRuleDg = MatchVoiceCpRuleDg(this@MatchVoiceAty)
                        }
                        mMatchVoiceCpRuleDg?.show()
                        mMatchVoiceCpRuleDg?.setData(cp_rule_content,avatar,to_avatar,is_follow)
                    }

                    override fun sendGift() {
                        mBinding.linlayGift.performClick()
                    }

                    override fun addTime() {
                        mBinding.imgvRecharge.performClick()
                    }
                })

                mMatchVoiceCpDg?.show()
                mMatchVoiceCpDg?.setData(cp_detail_content,avatar,to_avatar,is_follow)

            }


            R.id.imgv_lock ->{

                if (mMatchVoiceLockDg == null){
                    mMatchVoiceLockDg = MatchVoiceLockDg(this)
                }
                mMatchVoiceLockDg?.show()

            }

            //是否静音
            R.id.relay_speak -> {
                enable_speker = !enable_speker
                rtcChannel?.muteLocalAudioStream(enable_speker)
                if (! enable_speker){
                    mBinding.relaySpeak.setBackgroundResource(R.drawable.shape_56)
                }else{
                    mBinding.relaySpeak.setBackgroundResource(R.drawable.shape_66)
                }
//              rtcChannel.muteLocalVideoStream()
            }


            //是否免提
            R.id.relay_voice->{
                Log.e("mainClick===","relay_voice")
                enable_voice = !enable_voice
                mRtcEngine?.setEnableSpeakerphone(enable_voice)
            }

            R.id.linlay_finsh->{
                startProgressDialog()
                home.a54(channelName,this)
            }

//            R.id.linlay_sign_1 ->{
//
//                if (mBinding.linlaySign.visibility == View.VISIBLE){
//                    mBinding.linlaySign.visibility = View.GONE
//                }else{
//                    mBinding.linlaySign.visibility = View.VISIBLE
//                }
//            }

            R.id.linlay_gift->{
                if (giftDialog == null){
                    giftDialog = GiftDialog(this)
                    giftDialog?.setDataType("1")
                    giftDialog?.setGiftDialogListen(object : GiftDialog.GiftDialogListen{
                        override fun recharge() {
                            var bundle = Bundle()
                            bundle.putString("page_type", "pay")
                            startActivity(MainWalletAty::class.java, bundle)
                        }

                        override fun sendGift(gift_cover: String, gift_svga: String,
                                              gift_title: String, gift_id: String) {
                            this@MatchVoiceAty.sendGift(gift_cover,gift_svga,gift_title,gift_id)
                        }
                    })
                }

                giftDialog?.show()
                giftDialog?.requestData()
            }
            R.id.imgv_recharge->{

                if (time_every <10){
                    return
                }

                if (mVoiceRenewDialog == null){
                    mVoiceRenewDialog = VoiceRenewDialog(this)
                }
                mVoiceRenewDialog?.setVoiceRenewDialogListen(object : VoiceRenewDialog.VoiceRenewDialogListen{
                    override fun recharge() {
                        var bundle = Bundle()
                        bundle.putString("page_type", "pay")
                        startActivity(MainWalletAty::class.java, bundle)
                    }

                    override fun buyTime(time_id: String?) {
                        startProgressDialog()
                        home.a60(channelName,time_id.toString(),this@MatchVoiceAty)
                    }

                })
                mVoiceRenewDialog?.show()
                mVoiceRenewDialog?.requestData()
            }
        }
    }

    var message_gift:RtmMessage?=null
    var map_gift = HashMap<String,String>()

    fun sendGift(gift_cover:String,gift_svga:String,gift_title:String,gift_id:String){
        var time = TimeUtils.getBeijinTime()
        var message_id = MyUtils3.getMD5Str(time+user_code)

        var json = MyUtils3.getGiftMsg(
            to_user_code,to_avatar,to_nick,
            user_code,avatar,nick_my,
            gift_cover,gift_svga,gift_title,gift_id,
            time,message_id
        )
        message_gift = mRtmClient?.createMessage()
        message_gift?.text = json
        LogUtil.e(" message.serverReceivedTs="+json)
//                val messageBean = MessageBean(user_code, message, true)
        map_gift = HashMap<String,String>()
        map_gift["user_code"] = user_code
        map_gift["to_user_code"] = to_user_code
        map_gift["time"] = time
        map_gift["msg"] = json
        map_gift["message_id"] = message_id

        home.a432(to_user_code,user_code,json,time,message_id,channelName,this)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setStatusColor("#000000")
        setAndroidNativeLightStatusBar(false)

//        RtcEngine.destroy()
        try {
            mRtcEngine = RtcEngine.create(baseContext, appId, mRtcEventHandler)
        } catch (e: Exception) {
            throw RuntimeException("NEED TO check rtc sdk init fatal error ${Log.getStackTraceString(e)}")
        }

        mRtcEngine!!.setChannelProfile(Constants.CHANNEL_PROFILE_COMMUNICATION)
//        mRtcEngine!!.joinChannel(token, channelName, "Extra Optional Data", optionalUid)
        rtcChannel = mRtcEngine?.createRtcChannel(channelName)
        var channelMediaOptions = ChannelMediaOptions()
        rtcChannel?.joinChannel(token,"Extra Optional Data", optionalUid,channelMediaOptions)
        rtcChannel?.setRtcChannelEventHandler(iRtcChannelEventHandler)

        initIm()

    }

     var time_every =0L

    private fun startTime() {
        cancelTimerT()
        timerT = Timer()
        timerTaskT = object : TimerTask() {
            override fun run() {
                var c_time =TimeUtils.getBeijinTime().toDouble()
                var t = (time_end!!  - c_time)/1000
                time_every = ((time_end!!  - c_time)/1000).toLong()
                var text = TimeUtils.formatSecond2(t)

                lifecycleScope.launch {
                    withContext(Dispatchers.Main) {
                        if (t<=0){
                            showExitTime()
                            cancelTimerT()
                        }
                        if (t<61){
                            mBinding.relayTime.visibility = View.VISIBLE
                            mBinding.tvTime2.text = "  "+text+"  "
                        }else{
                            mBinding.relayTime.visibility = View.GONE
                        }
//                      mBinding.relayTime.visibility = View.VISIBLE

                        mBinding.tvTime.text = text
                    }
                }
            }
        }
        timerT?.schedule(timerTaskT, 0, 500)
    }

    fun cancelTimerT() {
        timerT?.cancel()
        timerT = null
        timerTaskT?.cancel()
        timerTaskT = null
    }

    fun showExitTime(){
        rtcChannel?.leaveChannel()
        if (mCommonDialog == null){
            mCommonDialog = CommonDialog(this)
        }
        mCommonDialog?.setCommonDialogListen(object : CommonDialog.CommonDialogListen{

            override fun onclik01() {
            }

            override fun onclik02() {
                mBinding.linlayFinsh.performClick()
            }
        })
        mCommonDialog?.show()
        mCommonDialog?.setCancelViewVisibility(false)
        mCommonDialog?.setCommCanceled(false)
        mCommonDialog?.setData("聊天时间已到, 请退出聊天","","确定")
    }

    fun showExit(){
        rtcChannel?.leaveChannel()
        if (mCommonDialog == null){
            mCommonDialog = CommonDialog(this)
        }
        mCommonDialog?.setCommonDialogListen(object : CommonDialog.CommonDialogListen{

            override fun onclik01() {}

            override fun onclik02() {
                mBinding.linlayFinsh.performClick()
            }

        })

        mCommonDialog?.show()
        mCommonDialog?.setCancelViewVisibility(false)
        mCommonDialog?.setCommCanceled(false)
        mCommonDialog?.setData("对方已挂断, 请退出聊天","","确定")
    }

    private val iRtcChannelEventHandler: IRtcChannelEventHandler = object :IRtcChannelEventHandler(){
        override fun onUserJoined(rtcChannel: RtcChannel?, uid: Int, elapsed: Int) {
            super.onUserJoined(rtcChannel, uid, elapsed)
            runOnUiThread {
                isJoin = true
                startLoop()
                start_time_join = System.currentTimeMillis()
//                mBinding.tvStatus.text = "用户${uid}加入频道"
                mBinding.tvStatus.text = ""
            }
        }

        override fun onUserOffline(rtcChannel: RtcChannel?, uid: Int, reason: Int) {
            super.onUserOffline(rtcChannel, uid, reason)
            runOnUiThread {
                showExit()
            }
        }

        override fun onJoinChannelSuccess(rtcChannel: RtcChannel?, uid: Int, elapsed: Int) {
            super.onJoinChannelSuccess(rtcChannel, uid, elapsed)
            runOnUiThread {
                mBinding.tvStatus.text = "等待对方加入.."
            }
        }

        override fun onConnectionStateChanged(rtcChannel: RtcChannel?, state: Int, reason: Int) {
            super.onConnectionStateChanged(rtcChannel, state, reason)
//            当前的网络连接状态：
//            CONNECTION_STATE_DISCONNECTED(1)：网络连接断开
//            CONNECTION_STATE_CONNECTING(2)：建立网络连接中
//            CONNECTION_STATE_CONNECTED(3)：网络已连接
//            CONNECTION_STATE_RECONNECTING(4)：重新建立网络连接中
//            CONNECTION_STATE_FAILED(5)：网络连接失败
            runOnUiThread {
                when(state){

                    Constants.CONNECTION_STATE_DISCONNECTED -> {
                        mBinding.tvStatus.text = "网络连接断开"
                    }
                    Constants.CONNECTION_STATE_CONNECTING -> {
                        mBinding.tvStatus.text = "网络连接中.."
                    }
                    Constants.CONNECTION_STATE_CONNECTED -> {
                        mBinding.tvStatus.text = "网络已连接"
                    }
                    Constants.CONNECTION_STATE_RECONNECTING -> {
                        mBinding.tvStatus.text = "重新网络连接中.."
                    }
                    Constants.CONNECTION_STATE_FAILED -> {
                        mBinding.tvStatus.text = "网络连接失败"
                    }

                }
            }
        }

    }


    private val mRtcEventHandler: IRtcEngineEventHandler = object : IRtcEngineEventHandler() {

        override fun onUserJoined(uid: Int, elapsed: Int) {
            super.onUserJoined(uid, elapsed)

        }

        override fun onUserOffline(uid: Int, reason: Int) { // Tutorial Step 4

        }

        override fun onError(err: Int) {
            super.onError(err)
            runOnUiThread {
                showToastS("启动通话失败")
                finish()
            }
        }

        override fun onJoinChannelSuccess(channel: String?, uid: Int, elapsed: Int) {
            super.onJoinChannelSuccess(channel, uid, elapsed)
        }

        //onConnectionStateChanged
        override fun onConnectionStateChanged(state: Int, reason: Int) {
            super.onConnectionStateChanged(state, reason)

//            当前的网络连接状态：
//            CONNECTION_STATE_DISCONNECTED(1)：网络连接断开
//            CONNECTION_STATE_CONNECTING(2)：建立网络连接中
//            CONNECTION_STATE_CONNECTED(3)：网络已连接
//            CONNECTION_STATE_RECONNECTING(4)：重新建立网络连接中
//            CONNECTION_STATE_FAILED(5)：网络连接失败
//            runOnUiThread {
//                when(state){
//
//                    Constants.CONNECTION_STATE_DISCONNECTED -> {
//                        mBinding.tvStatus.text = "网络连接断开"
//                    }
//                    Constants.CONNECTION_STATE_CONNECTING -> {
//                        mBinding.tvStatus.text = "网络连接中.."
//                    }
//                    Constants.CONNECTION_STATE_CONNECTED -> {
//                        mBinding.tvStatus.text = "网络已连接"
//                    }
//                    Constants.CONNECTION_STATE_RECONNECTING -> {
//                        mBinding.tvStatus.text = "重新网络连接中.."
//                    }
//                    Constants.CONNECTION_STATE_FAILED -> {
//                        mBinding.tvStatus.text = "网络连接失败"
//                    }
//
//                }
//            }
        }

        override fun onAudioRouteChanged(routing: Int) {
            super.onAudioRouteChanged(routing)

//            AUDIO_ROUTE_DEFAULT(-1)：使用默认的音频路由。
//            AUDIO_ROUTE_HEADSET(0)：音频路由为带麦克风的耳机。
//            AUDIO_ROUTE_EARPIECE(1)：音频路由为听筒。
//            AUDIO_ROUTE_HEADSETNOMIC(2)：音频路由为不带麦克风的耳机。
//            AUDIO_ROUTE_SPEAKERPHONE(3)：音频路由为设备自带的扬声器。
//            AUDIO_ROUTE_LOUDSPEAKER(4)：(暂不支持)音频路由为外接的扬声器。
//            AUDIO_ROUTE_HEADSETBLUETOOTH(5)：音频路由为蓝牙耳机

            runOnUiThread {
                LogUtil.e("onAudioRouteChanged=="+"${routing}")
                when(routing){
                    //使用默认的音频路由。
                    Constants.AUDIO_ROUTE_DEFAULT -> {
                        mBinding.relayVoice.setBackgroundResource(R.drawable.shape_56)
                    }
                    //音频路由为带麦克风的耳机。
                    Constants.AUDIO_ROUTE_HEADSET -> {
                        mBinding.relayVoice.setBackgroundResource(R.drawable.shape_56)
                    }
                    //音频路由为听筒
                    Constants.AUDIO_ROUTE_EARPIECE -> {
                        mBinding.relayVoice.setBackgroundResource(R.drawable.shape_56)
                    }
                    //音频路由为不带麦克风的耳机。
                    Constants.AUDIO_ROUTE_HEADSETNOMIC -> {
                        mBinding.relayVoice.setBackgroundResource(R.drawable.shape_56)
                    }
                    //音频路由为设备自带的扬声器
                    Constants.AUDIO_ROUTE_SPEAKERPHONE -> {
                        mBinding.relayVoice.setBackgroundResource(R.drawable.shape_66)
                    }
                    //(暂不支持)音频路由为外接的扬声器。
                    Constants.AUDIO_ROUTE_LOUDSPEAKER -> {
                        mBinding.relayVoice.setBackgroundResource(R.drawable.shape_66)
                    }
                   // 音频路由为蓝牙耳机
                    Constants.AUDIO_ROUTE_HEADSETBLUETOOTH -> {
                        mBinding.relayVoice.setBackgroundResource(R.drawable.shape_56)
                    }
                }
            }
        }

        override fun onUserMuteAudio(uid: Int, muted: Boolean) { // Tutorial Step 6

        }
    }

    override fun onDestroy() {
        super.onDestroy()
        rtcChannel?.leaveChannel()
        rtcChannel?.destroy()
        cancelTimerT()
        svgUtils?.onDestroy()
//       mRtcEngine?.leaveChannel()
//        RtcEngine.destroy()
        mRtcEngine = null
        (application  as MyApp).getChatManager().unregisterListener(this)
    }


    override fun onBackPressed() {
    }

    override fun onMessageReceived(message: RtmMessage?, peerId: String?) {

        LogUtil.e("AESCBCCrypt=="+to_user_code+",,,"+peerId)

        if (message != null) {
            LogUtil.e("AESCBCCrypt-chataty="+message.text)
        }

        var str = AESCBCCrypt.aesDecrypt(message!!.text)
        var map_str = JSONUtils.parseKeyAndValueToMap(str)

        LogUtil.e("AESCBCCrypt=="+str)

        if (peerId == to_user_code) {

            ChatUtils.saveChatpannel(message!!.text,true)

            runOnUiThread {
                when(map_str["type"]){
                    "4"->{
                        var url_svga = map_str["svaga"]
                        if (!url_svga!!.startsWith("http")){
                            var resource_cdn =PreferencesUtils.getString(x.app(),"resource_cdn")
                            url_svga = resource_cdn +url_svga
                        }
                        var map1 =HashMap<String,String>()
                        map1["url_svga"] = url_svga
                        map1["msg"] = str
                        svgUtils?.addAnimation(map1)

//                        mBinding.linlaySign.visibility = View.GONE

                    }
                    "20"->{

                        when(map_str["notice_type"]){

                            "205"->{
//                                var time =TimeUtils.getTime(map_str["end_at"]!!).toDouble()
                                var time =map_str["end_at"]!!.toDouble()*1000
                                LogUtil.e("p======"+time.toString()+"<"+time_end.toString())
                                //2147483647
                                if (time<time_end!!){
                                    LogUtil.e("p=====2=")
                                    return@runOnUiThread
                                }
                                time_end = time
                                startLoop()
                            }
                        }
                    }
                }
            }
        } else {
            ChatUtils.saveChatpannel(message!!.text,false)
        }
    }



}
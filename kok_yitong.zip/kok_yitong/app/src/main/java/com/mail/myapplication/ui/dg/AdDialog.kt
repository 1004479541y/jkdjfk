package com.mail.myapplication.ui.dg

import android.graphics.Color
import android.os.Bundle
import android.text.TextUtils
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.mail.comm.base.BaseAty
import com.mail.comm.base.BaseDialog
import com.mail.comm.image.ImageLoader
import com.mail.comm.net.AESCBCCrypt
import com.mail.comm.utils.JSONUtils
import com.mail.comm.utils.TimeUtils
import com.mail.comm.view.load.XLoadTip
import com.mail.myapplication.BaseXAty
import com.mail.myapplication.R
import com.mail.myapplication.databinding.DgGiftBinding
import com.mail.myapplication.databinding.DialogAdBinding
import com.mail.myapplication.databinding.ItemGiftBinding
import com.mail.myapplication.interfaces.Home
import com.mail.myapplication.interfaces.Lar
import com.mail.myapplication.ui.utils.MyUtils3
import com.mail.myapplication.ui.wallet.ImageAdapter
import com.mail.myapplication.ui.wallet.RechargeAty
import com.yhz.adaptivelayout.config.AutoLayoutConifg
import com.yhz.adaptivelayout.utils.AutoUtils
import org.xutils.common.util.LogUtil
import org.xutils.x

class AdDialog(context: BaseAty) : BaseDialog(context) {

    lateinit var mBinding: DialogAdBinding
    var mAdDialogListen: AdDialogListen? = null
    var home = Home()
    var link =""
    var cover =""
    var id =""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        mBinding = DialogAdBinding.inflate(layoutInflater);
        setContentView(mBinding.root)
        window?.setWindowAnimations(R.style.dialogFullscreen2)
        val dialogWindow = window

        dialogWindow!!.setBackgroundDrawable(null)
        dialogWindow.setGravity(Gravity.CENTER)
        setCanceledOnTouchOutside(false)
        setCancelable(false)
        val m = baseAty.windowManager
        val d = m.defaultDisplay// 获取屏幕宽、高
        val p = dialogWindow.attributes
        window?.getDecorView()?.setPadding(0, 0, 0, 0)
//        p.height =  (d.height * 1) // 高度设置为屏幕的0.6
        p.width = (d.width * 1) // 宽度设置为屏幕的0.85
        dialogWindow.attributes = p

        with(mBinding) {

            imgvCancel.setOnClickListener {
                dismiss()
                mAdDialogListen?.cancel()
            }

            ivCover.setOnClickListener {
//                if (link.startsWith("url")) {
//                    var index = link.indexOf("//")
//                    MyUtils3.openBrowser(x.app(), link.substring(index + 2))
//                }

                if (TextUtils.isEmpty(link)) {
                    return@setOnClickListener
                }

                if (baseAty is BaseXAty){
                    (baseAty as BaseXAty).requestAdCount(id)
                    MyUtils3.openTowPage(baseAty as BaseAty,link)
                }

            }

        }


    }

    fun setData(link: String, cover: String,id:String) {
        if (isShowing) {
            this.link = link
            this.cover = cover
            this.id = id

            var maxW = AutoLayoutConifg.getInstance().screenWidth
            var maxH = AutoLayoutConifg.getInstance().screenHeight
            ImageLoader.loadImageAes(baseAty, cover, mBinding.ivCover,maxW,maxH)
        }

    }

    interface AdDialogListen {
        fun cancel()
        fun toPage(ling: String)
    }

    fun setAdDialogListen(mAdDialogListen:AdDialogListen){
        this.mAdDialogListen = mAdDialogListen
    }



}
package com.mail.myapplication.ui.mine.shop

import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.util.TypedValue
import android.view.View
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.lifecycle.Lifecycle
import androidx.viewpager2.adapter.FragmentStateAdapter
import androidx.viewpager2.widget.ViewPager2
import com.mail.myapplication.BaseXAty
import com.mail.myapplication.R
import com.mail.myapplication.databinding.AtyGiftWallBinding
import com.mail.myapplication.databinding.AtyShopBinding
import com.mail.myapplication.ui.mine.person.giftwall.GiftWall01Frg
import com.mail.myapplication.ui.mine.person.giftwall.GiftWall02Frg
import com.yhz.adaptivelayout.utils.AutoUtils

class ShopAty : BaseXAty() {

    lateinit var mBinding: AtyShopBinding

    var list_frg = ArrayList<Fragment>()

    lateinit var list_tv: Array<TextView>
    lateinit var list_v: Array<View>

    override fun getLayoutView(): View {
        mBinding = AtyShopBinding.inflate(layoutInflater);
        return mBinding.root
    }

    override fun getLayoutId() = 0

    override fun initView() {
    }

    override fun requestData() {
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        with(mBinding) {
            initTopview2(include.relayTopBg, resources.getString(R.string.c_4))
            include.tvTitle.text = "掛件禮物商城"
            list_tv = arrayOf(tv00,tv01,tv02, tv03)
            list_v = arrayOf(v00,v01,v02, v03)
        }
        initFrg()
    }

    fun initFrg(){
        list_frg.add(ShopFrg.create("1"))
        list_frg.add(ShopFrg.create("2"))
        list_frg.add(ShopGiftFrg.create("3"))
        list_frg.add(ShopPackgeFrg.create("4"))
        mBinding.viewPager.adapter = PersonListAdataper(supportFragmentManager, this@ShopAty.lifecycle, list_frg)
        mBinding.viewPager.offscreenPageLimit = list_frg.size

        with(mBinding){
            linlay00.setOnClickListener {
                viewPager.setCurrentItem(0,true)
            }
            linlay01.setOnClickListener {
                viewPager.setCurrentItem(1,true)
            }
            linlay02.setOnClickListener {
                viewPager.setCurrentItem(2,true)
            }

            linlay03.setOnClickListener {
                viewPager.setCurrentItem(3,true)
            }

//            viewPager.offscreenPageLimit = list.size

            viewPager.registerOnPageChangeCallback(object: ViewPager2.OnPageChangeCallback() {
                override fun onPageSelected(position: Int) {
                    when(position){
                        0 -> {
                            setSelector(tv00)
                        }
                        1 -> {
                            setSelector(tv01)
                        }
                        2 -> {
                            setSelector(tv02)
                        }
                        3 -> {
                            setSelector(tv03)
                        }

                    }
                }
            })
        }

    }


    fun setSelector(tv: TextView) {
        for (i in list_tv.indices) {
            if (tv === list_tv[i]) {
                list_tv[i].setTextColor(Color.parseColor(getString(R.string.c_01)))
                list_tv[i].setTypeface(Typeface.defaultFromStyle(Typeface.BOLD));//加粗

                list_tv[i].setTextSize(TypedValue.COMPLEX_UNIT_PX, AutoUtils.getPercentWidthSizeBigger(55).toFloat())
                list_v[i].visibility = View.VISIBLE
            } else {
                list_tv[i].setTextColor(Color.parseColor(getString(R.string.c_02)))
                list_tv[i].setTypeface(Typeface.defaultFromStyle(Typeface.NORMAL));//加粗
                list_tv[i].setTextSize(TypedValue.COMPLEX_UNIT_PX, AutoUtils.getPercentWidthSizeBigger(45).toFloat())
                list_v[i].visibility = View.INVISIBLE
            }
        }
    }

    inner class PersonListAdataper(
        fa: FragmentManager,
        lifecycle: Lifecycle,
        val docs: ArrayList<Fragment>
    ) :

        FragmentStateAdapter(fa, lifecycle) {

        override fun getItemCount(): Int = docs.size

        override fun createFragment(position: Int): Fragment = docs[position]

    }

    fun mainClick(v: View) {

        when (v.id) {

            R.id.relay_back -> {
                finish()
            }


        }

    }

}
package com.mail.myapplication.ui.mine.person

import android.os.Bundle
import android.text.TextUtils
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.mail.comm.image.ImageLoader
import com.mail.comm.net.AESCBCCrypt
import com.mail.comm.utils.JSONUtils
import com.mail.comm.view.load.XLoadTip
import com.mail.myapplication.BaseXFrg
import com.mail.myapplication.databinding.FrgPersonDetailsBinding
import com.mail.myapplication.databinding.ItemPeisonDetailsGiftBinding
import com.mail.myapplication.databinding.ItemPersonDetails1Binding
import com.mail.myapplication.interfaces.Home
import com.yhz.adaptivelayout.utils.AutoUtils

class PersonOtherDetailsFrg:BaseXFrg() {

    lateinit var mBinding: FrgPersonDetailsBinding
    var home = Home()
    var user_code =""

    var mAdapter: GoldRecyclerAdapter? = null
    var mAdapter2: GoldRecyclerAdapter2? = null
    var list_habit = ArrayList<String>()
    var list_wall = ArrayList<MutableMap<String,String>>()

    override fun getLayoutId()=0

    override fun initView() {
        user_code = arguments?.getString("user_code").toString()
    }

    companion object {

        fun create(user_code: String): PersonOtherDetailsFrg {
            val fragment = PersonOtherDetailsFrg()
            val bundle = Bundle()
            bundle.putString("user_code", user_code)
            fragment.arguments = bundle
            return fragment
        }
    }

    override fun requestData() {
        mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.loading)
        home.a17(user_code, this)
    }

    fun requestDataGift(){
        home.a66(user_code, this)
    }

    override fun getLayoutView(): View {
        mBinding = FrgPersonDetailsBinding.inflate(layoutInflater);
        return mBinding.root
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        var mLayoutManager = LinearLayoutManager(requireContext())
        mLayoutManager.orientation = RecyclerView.HORIZONTAL
        mBinding.recyclerview.layoutManager = mLayoutManager
        mAdapter = GoldRecyclerAdapter()
        mBinding.recyclerview.adapter = mAdapter
        mBinding.recyclerview.isNestedScrollingEnabled = false
        mBinding.relayCreateFansGroup.visibility = View.GONE

        initGift()

        mBinding.loading.setLoadingTipXReloadCallback(object : XLoadTip.LoadingTipXReloadCallback {
            override fun reload() {
                requestData()
            }
        })
    }

    fun initGift(){
        var mLayoutManager = LinearLayoutManager(requireContext())
        mLayoutManager.orientation = RecyclerView.HORIZONTAL
        mBinding.recyclerview2.layoutManager = mLayoutManager
        mAdapter2 = GoldRecyclerAdapter2()
        mBinding.recyclerview2.adapter = mAdapter2
        mBinding.recyclerview2.isNestedScrollingEnabled = false
    }

    override fun onComplete(var2: String?, type: String?) {
        super.onComplete(var2, type)

        if (type == "gift/wall") {
            var map = JSONUtils.parseKeyAndValueToMap(var2)
            if (map["code"] == "200") {
                mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.finish)
                var str = AESCBCCrypt.aesDecrypt(map["data"])
                list_wall.clear()
                var mList = JSONUtils.parseKeyAndValueToMapList(str)
                if (mList != null && mList.size>0){
                    list_wall.addAll(mList)
                }
                mBinding.tvNum.text = "点亮${list_wall.size}"
                mAdapter2?.notifyDataSetChanged()
            }else{
                mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.error)
            }
        }
        if (type == "other/info") {
            var map = JSONUtils.parseKeyAndValueToMap(var2)
            if (map["code"] == "200") {
                requestDataGift()
//                mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.finish)

                var strs = AESCBCCrypt.aesDecrypt(map["data"])
                var map = JSONUtils.parseKeyAndValueToMap(strs)

                with(mBinding) {

                    var info_nick = map["nick"]
                    var info_flow = map["flow"]
                    var info_fans = map["fans"]
                    var info_avatar = map["avatar"]
                    var info_intro = map["intro"]
                    var info_city = map["city"]
                    var info_years = map["years"]
                    var info_job = map["job"]
                    var info_gender = map["gender"]
                    var info_is_creator = map["is_creator"]
                    var info_vip_level = map["vip_level"]
                    var has_fans_group = map["has_fans_group"]
                    var fans_count_num = map["fans_count_num"]
                    var jon_group_num = map["join_group_num"]
                    var info_habit = map["user_habit"]

                    var list_fans_group = JSONUtils.parseKeyAndValueToMapList(map["fans_group_list"])
                    var maxW = AutoUtils.getPercentWidthSizeBigger(300)

                    mBinding.tvIntro.text = "${info_intro}"
                    mBinding.tvCity.text = "地址：${info_city}"
                    mBinding.tvJob.text = "職業：${info_job}"
                    mBinding.tvBirth.text = "年龄：${info_years}"

                    if (TextUtils.isEmpty(info_intro)) {
                        mBinding.tvIntro.text = "暂无签名"
                    }

                    var str = info_habit!!.split(",")
                    list_habit.clear()

                    if (str != null && str.size > 0 && !TextUtils.isEmpty(info_habit)) {
                        for (str in str) {
                            list_habit.add(str)
                        }
                    }

                    if (list_habit.size == 0){
                        mBinding.tvSign.visibility = View.GONE
                        mBinding.recyclerview.visibility = View.GONE
                    }
                    mAdapter?.notifyDataSetChanged()
                }

            } else {
                mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.error)
            }
        }

    }

    override fun onExceptionType(type: String?) {
        super.onExceptionType(type)
        stopProgressDialog()
        if (type == "other/info"||type =="gift/wall"){
            mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.error)
        }
    }

    inner class GoldRecyclerAdapter : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
            return fGoldViewHolder(ItemPersonDetails1Binding.inflate(LayoutInflater.from(context)))
        }

        override fun getItemCount(): Int = list_habit.size

        override fun getItemViewType(position: Int): Int {
            return position
        }

        override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {

            if (holder is fGoldViewHolder) {
                with(holder) {
                    with(mBinding) {
                        tvName.text = list_habit[position]
                    }
                }
            }

        }

        inner class fGoldViewHolder(binding: ItemPersonDetails1Binding) :
            RecyclerView.ViewHolder(binding.root) {
            var mBinding: ItemPersonDetails1Binding = binding

            init {
                AutoUtils.autoSize(binding.root)

            }
        }

    }


    inner class GoldRecyclerAdapter2 : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
            return fGoldViewHolder(ItemPeisonDetailsGiftBinding.inflate(LayoutInflater.from(context)))
        }

        override fun getItemCount(): Int = list_wall.size

        override fun getItemViewType(position: Int): Int {
            return position
        }

        override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {

            if (holder is fGoldViewHolder) {

                with(holder) {
                    with(mBinding) {
                        var map = list_wall[position]
                        var maxW = AutoUtils.getPercentWidthSizeBigger(200)
                        ImageLoader.loadImageAes(requireActivity(), map["gift_cover"], imgv,maxW,maxW)
                        tvName.text = map["title"]
                        tvNum.text = "x"+map["num"]
                    }
                }

            }

        }

        inner class fGoldViewHolder(binding: ItemPeisonDetailsGiftBinding) :
            RecyclerView.ViewHolder(binding.root) {
            var mBinding: ItemPeisonDetailsGiftBinding = binding

            init {
                AutoUtils.autoSize(binding.root)

            }
        }

    }


}
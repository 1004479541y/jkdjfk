package com.mail.myapplication.ui.mine.apply

import android.os.Bundle
import android.view.View
import android.widget.RelativeLayout
import com.mail.comm.app.AppConfig
import com.mail.comm.net.AESCBCCrypt
import com.mail.comm.utils.JSONUtils
import com.mail.comm.utils.MyUtils2
import com.mail.comm.view.load.XLoadTip
import com.mail.comm.view.refresh.XRefreshInterface
import com.mail.myapplication.BaseXAty
import com.mail.myapplication.R
import com.mail.myapplication.databinding.*
import com.mail.myapplication.interfaces.Home
import com.mail.myapplication.ui.mine.post.PostSendAty
import com.mail.myapplication.ui.utils.MyUtils3
import com.yhz.adaptivelayout.utils.AutoUtils

class AuthAty : BaseXAty() {


    var home = Home()
    var str =""
    var tg_url =""
    var potato_url =""
    var creator_status = ""


    lateinit var mBinding: AtyAuthBinding

    override fun getLayoutId(): Int = 0

    override fun getLayoutView(): View {
        mBinding = AtyAuthBinding.inflate(layoutInflater);
        return mBinding.root
    }

    override fun initView() {
        creator_status = intent.getStringExtra("creator_status").toString()
    }

    override fun requestData() {
        mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.loading)
        requestData2()
    }

    fun requestData2() {
        home.a32(this)
    }

    override fun onResume() {
        super.onResume()
        requestData2()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setTranslanteBar()
        if (AppConfig.model == "wanou"){
            setAndroidNativeLightStatusBar(false)
        }else{
            setAndroidNativeLightStatusBar(true)
        }
        mBinding.include.tvTitle.text = ""
//        mBinding.include.tvTitle.setTextColor(Color.parseColor("#ffffff"))
        initLayout()

        with(mBinding) {

            swipeRefreshLayout.setEnableLoadmore(false)
            swipeRefreshLayout.setEnableRefresh(true)
            swipeRefreshLayout.setIsPinContentView(true)
            swipeRefreshLayout.setXRefreshAndLoadListen(object : XRefreshInterface {
                override fun refreshStart() {
                    requestData2()
                }

                override fun loadMoreStart() {
                }

            })

            loading.setLoadingTipXReloadCallback(object : XLoadTip.LoadingTipXReloadCallback {
                override fun reload() {
                    requestData()
                }
            })


            refreshData()

        }

    }


    fun refreshData(){
        when(creator_status){

            "1"->{
                mBinding.tvStatus.text = "已認證"
            }

            "2"->{
                mBinding.tvStatus.text = "認證中"
            }

            "0"->{
                mBinding.tvStatus.text = "重新認證"
            }

            "10"->{
                mBinding.tvStatus.text = "去認證"
            }

            else ->{
                mBinding.tvStatus.text = "去認證"
            }

        }
    }

    override fun onComplete(var2: String?, type: String?) {
        super.onComplete(var2, type)
        mBinding.swipeRefreshLayout.finishLoadmore()
        mBinding.swipeRefreshLayout.finishRefreshing()
        stopProgressDialog()
        if (type == "creator/info") {
            var map = JSONUtils.parseKeyAndValueToMap(var2)
            if (map["code"] == "200") {
                mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.finish)
                str = AESCBCCrypt.aesDecrypt(map["data"])
                var maps = JSONUtils.parseKeyAndValueToMap(str)
                potato_url = maps!!["potato_url"]!!
                tg_url = maps["tg_url"]!!
                creator_status = maps["status"]!!
                refreshData()
                var refuse_content = maps["refuse_content"]!!

                if (creator_status == "0"){
                    mBinding.relayAuthInfo.visibility = View.VISIBLE
                    mBinding.tvAuthInfo.text = refuse_content
                }


            } else {
                mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.error)

            }
        }

    }

    override fun onExceptionType(type: String?) {
        super.onExceptionType(type)
        mBinding.swipeRefreshLayout.finishLoadmore()
        mBinding.swipeRefreshLayout.finishRefreshing()
        stopProgressDialog()
        if (type == "creator/info"){
            mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.error)
        }
    }


    fun initLayout() {
        var params = mBinding.include.relayTopBg.layoutParams as RelativeLayout.LayoutParams
        var StatusBarHeight = MyUtils2.getStateBar(this@AuthAty)
        if (StatusBarHeight <= 0) {
            StatusBarHeight = MyUtils2.dip2px(this@AuthAty, 20F)
        }
        params.topMargin = StatusBarHeight
        params.height = AutoUtils.getPercentHeightSizeBigger(150)
        mBinding.include.relayTopBg.layoutParams = params
    }

    fun mainClick(v: View) {

        when (v.id) {

            R.id.relay_back -> {
                finish()
            }
            R.id.relay_02 -> {
                startActivity(PostSendAty::class.java)
            }

            R.id.tv_status,R.id.relay_03 -> {
                var bundle = Bundle()
                bundle.putString("creator_status",creator_status)
                bundle.putString("data",str)
                startActivity(AuthImgVideoAty::class.java,bundle)
            }

            R.id.tv_potato -> {
                MyUtils3.openBrowser(this,potato_url)
            }

            R.id.tv_tg -> {
                MyUtils3.openBrowser(this,tg_url)
            }

        }
    }



}
package com.mail.myapplication.ui.mine.pattern

import android.os.Bundle
import android.view.View
import com.mail.myapplication.BaseXAty
import com.mail.myapplication.R
import com.mail.myapplication.databinding.*

class PatternSetAty : BaseXAty() {

    lateinit var mBinding: AtyPatternSetBinding

    override fun getLayoutId(): Int = 0

    override fun getLayoutView(): View {
        mBinding = AtyPatternSetBinding.inflate(layoutInflater);
        return mBinding.root
    }

    override fun initView() {}

    override fun requestData() {}

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        initTopview2(mBinding.include.relayTopBg, resources.getString(R.string.c_4))
        mBinding.include.tvTitle.text = "手势設置"
    }

    fun mainClick(v: View) {

        when (v.id) {

            R.id.relay_back -> {
                finish()
            }

            R.id.tv_ok ->{
                var bundle = Bundle()
                bundle.putString("type","set_pattern")
                startActivity(PatternAty::class.java,bundle)
                finish()
            }

        }
    }





}